import { query } from '../db/index.js';
import { nextNumber } from './serviceManager.js';
import { sendKci } from './kciService.js';
import { logEvent } from './journalService.js';
import { findArea } from './coverageService.js';
import { startSla, stopSla, slaView } from './slaService.js';
import { TEAMS } from './triageAgent.js';

// Incidents are raised ON THE ORDER when fulfilment hits a problem (e.g. the engineer cannot access the building).
// While an incident is open the order is On Hold and cannot move on. A major incident covers one fault in an area
// (by postcode) and links an incident on every affected open order.

// The teams that can own incidents and tasks
// States: New (raised) -> Open (being worked) -> Resolved (fixed, customer told) -> Closed
export const ASSIGNMENT_GROUPS = TEAMS;
const ACTIVE = ['New', 'Open'];
const PRIORITIES = ['P1', 'P2', 'P3', 'P4'];

// Runs fn over items, at most `limit` at the same time (AI calls in parallel, but not all at once)
async function mapLimit(items, limit, fn) {
  const results = [];
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      try { results[i] = await fn(items[i]); } catch (err) { results[i] = { error: err.message }; }
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

const countOpenTasks = async (incidentId) => (await query(
  `SELECT COUNT(*)::int AS n FROM incident_tasks WHERE incident_id = $1 AND state <> 'Done'`, [incidentId]
)).rows[0].n;

// ---------------- RAISE / RESOLVE (one order) ----------------

// Raise an incident on an order: the order goes On Hold, the incident SLA starts, a DELAY update is sent.
// notify = false: create the record only (a major incident sends the updates itself, in parallel)
export async function raiseIncident(orderId, description,
  { testLeak = false, priority = 'P3', assignment_group = 'Field Engineering', parentId = null, notify = true } = {}) {
  if (!description?.trim()) throw new Error('Incident description is empty');
  if (!PRIORITIES.includes(priority)) throw new Error('Priority must be P1, P2, P3 or P4');
  if (!ASSIGNMENT_GROUPS.includes(assignment_group)) throw new Error('Choose a team for the incident');
  const o = (await query(`SELECT * FROM orders WHERE id = $1`, [orderId])).rows[0];
  if (!o) throw new Error('Order not found');
  if (!['In Progress', 'On Hold'].includes(o.status)) throw new Error(`This order is ${o.status.toLowerCase()}`);
  const open = await query(`SELECT 1 FROM incidents WHERE order_id = $1 AND state IN ('New', 'Open')`, [o.id]);
  if (open.rowCount) throw new Error('This order already has an open incident');

  const incident = (await query(
    `INSERT INTO incidents (incident_number, order_id, case_id, stage, description, priority, assignment_group, parent_id, state)
     VALUES ($1, $2, NULL, $3, $4, $5, $6, $7, 'New') RETURNING *`,
    [await nextNumber('incidents', 'INC'), o.id, o.current_stage, description.trim(), priority, assignment_group, parentId]
  )).rows[0];

  await query(`UPDATE orders SET status = 'On Hold', updated_at = now() WHERE id = $1`, [o.id]);
  await startSla('incident', incident.id, `INC_${priority}`, o.id);
  await logEvent({ orderId: o.id, incidentId: incident.id },
    `Incident ${incident.incident_number} raised (${priority}, ${assignment_group}): ${incident.description}. Order on hold.`);

  if (!notify) return { incident, kci: null };
  const kci = await sendKci({ orderId: o.id, incidentId: incident.id }, 'INCIDENT_RAISED', { incident, testLeak });
  return { incident, kci };
}

// Resolve an incident: the order is In Progress again (stage clock restarts) and a RESOLVED update is sent
export async function resolveIncident(incidentId, resolution) {
  // Rule: an incident cannot be resolved while any of its tasks is still open
  const openTasks = await countOpenTasks(incidentId);
  if (openTasks) throw new Error(`Complete the ${openTasks} open task${openTasks > 1 ? 's' : ''} before resolving this incident`);

  const incident = (await query(
    `UPDATE incidents SET state = 'Resolved', resolution = $2, resolved_at = now()
      WHERE id = $1 AND state IN ('New', 'Open') RETURNING *`, [incidentId, resolution || 'Resolved']
  )).rows[0];
  if (!incident) throw new Error('Open incident not found');
  await stopSla('incident', incident.id, 'Completed');

  await query(
    `UPDATE orders SET status = 'In Progress', stage_entered_at = now(), updated_at = now() WHERE id = $1 AND status = 'On Hold'`,
    [incident.order_id]
  );
  await logEvent({ orderId: incident.order_id, incidentId: incident.id },
    `Incident ${incident.incident_number} resolved: ${incident.resolution}. Order back in progress.`);
  // Fallout scenario 1: the ticket held an engineer visit -> the visit continues and the customer gets ONE
  // "fixed, your engineer is confirmed" update (instead of the generic resolved update)
  const { resumeFallout } = await import('./orderService.js');
  const kci = (await resumeFallout(incident))
    || await sendKci({ orderId: incident.order_id, incidentId: incident.id }, 'INCIDENT_RESOLVED', { incident });
  return { incident, kci };
}

// ---------------- READ ----------------

// All incidents for the service desk (major incidents and normal ones)
export async function listIncidents() {
  return (await query(
    `SELECT i.*, o.customer_name, o.order_number, m.incident_number AS parent_number,
            (SELECT COUNT(*) FROM incident_tasks t WHERE t.incident_id = i.id)::int                    AS tasks_total,
            (SELECT COUNT(*) FROM incident_tasks t WHERE t.incident_id = i.id AND t.state <> 'Done')::int AS tasks_open,
            (SELECT COUNT(*) FROM incidents ch WHERE ch.parent_id = i.id)::int                         AS affected
       FROM incidents i
       LEFT JOIN orders o    ON o.id = i.order_id
       LEFT JOIN incidents m ON m.id = i.parent_id
      ORDER BY (i.state IN ('New', 'Open')) DESC, i.priority, i.id DESC`
  )).rows;
}

// One incident with its tasks, its SLA, and (for a major incident) every affected customer
export async function getIncident(id) {
  const inc = (await query(
    `SELECT i.*, o.customer_name, o.order_number, m.incident_number AS parent_number
       FROM incidents i
       LEFT JOIN orders o    ON o.id = i.order_id
       LEFT JOIN incidents m ON m.id = i.parent_id
      WHERE i.id = $1`, [id]
  )).rows[0];
  if (!inc) throw new Error('Incident not found');
  inc.tasks = (await query(`SELECT * FROM incident_tasks WHERE incident_id = $1 ORDER BY id`, [id])).rows;
  inc.slas = (await query(`SELECT * FROM slas WHERE record_type = 'incident' AND record_id = $1 ORDER BY id`, [id])).rows.map(slaView);
  inc.children = (await query(
    `SELECT ch.id, ch.incident_number, ch.state, ch.order_id, o.customer_name, o.order_number, p.name AS product_name,
            (SELECT k.status FROM kci_communications k WHERE k.incident_id = ch.id ORDER BY k.id DESC LIMIT 1) AS last_kci_status,
            (SELECT k.review_verdict FROM kci_communications k WHERE k.incident_id = ch.id ORDER BY k.id DESC LIMIT 1) AS last_verdict
       FROM incidents ch
       JOIN orders o   ON o.id = ch.order_id
       JOIN products p ON p.id = o.product_id
      WHERE ch.parent_id = $1 ORDER BY ch.id`, [id]
  )).rows;
  return inc;
}

// ---------------- TASKS ----------------

export async function addTask(incidentId, { short_description, customer_note, assignment_group, assigned_to } = {}) {
  if (!short_description?.trim()) throw new Error('Describe the task first');
  if (!ASSIGNMENT_GROUPS.includes(assignment_group)) throw new Error('Choose a team for the task');
  const inc = (await query(`SELECT * FROM incidents WHERE id = $1`, [incidentId])).rows[0];
  if (!inc) throw new Error('Incident not found');
  if (!ACTIVE.includes(inc.state)) throw new Error(`This incident is already ${inc.state.toLowerCase()}`);

  if (inc.state === 'New') await query(`UPDATE incidents SET state = 'Open' WHERE id = $1`, [inc.id]); // work has started
  const task = (await query(
    `INSERT INTO incident_tasks (task_number, incident_id, short_description, customer_note, assignment_group, assigned_to)
     VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
    [await nextNumber('incident_tasks', 'TSK'), incidentId, short_description.trim(), customer_note?.trim() || null,
     assignment_group, assigned_to?.trim() || null]
  )).rows[0];
  await logEvent({ orderId: inc.order_id, incidentId: inc.id }, `Task ${task.task_number} added to ${inc.incident_number}: ${task.short_description}`);
  return task;
}

// Open -> In Progress -> Done. When a task is Done, every affected customer is told about the progress.
export async function setTaskState(taskId, state) {
  if (!['In Progress', 'Done'].includes(state)) throw new Error('State must be In Progress or Done');
  const task = (await query(
    `UPDATE incident_tasks SET state = $2, completed_at = CASE WHEN $2 = 'Done' THEN now() END
      WHERE id = $1 AND state <> 'Done' RETURNING *`, [taskId, state]
  )).rows[0];
  if (!task) throw new Error('Open task not found');
  const inc = (await query(`SELECT * FROM incidents WHERE id = $1`, [task.incident_id])).rows[0];
  await logEvent({ orderId: inc.order_id, incidentId: inc.id }, `Task ${task.task_number} ${state === 'Done' ? 'done' : 'started'}.`);
  if (state !== 'Done') return { task, notified: 0 };
  const openTasks = await countOpenTasks(inc.id);

  // Who must hear about it: the incident's own order, or every affected order of a major incident
  const targets = inc.is_major
    ? (await query(`SELECT * FROM incidents WHERE parent_id = $1 AND state IN ('New', 'Open')`, [inc.id])).rows
    : [inc];
  const kcis = await mapLimit(targets, 3, (child) =>
    sendKci({ orderId: child.order_id, incidentId: child.id }, 'TASK_COMPLETED', { incident: child, task, openTasks }));

  return { task, open_tasks: openTasks, notified: kcis.filter((k) => k?.status === 'Sent').length,
           held: kcis.filter((k) => k?.status === 'Held').length };
}

// ---------------- MAJOR INCIDENT ----------------

// One fault in an area (e.g. a fiber cut at postcode M14 5RG) -> every open order there is linked and told
export async function raiseMajorIncident({ pincode, description, priority = 'P1', assignment_group = 'Network Operations' } = {}) {
  const area = await findArea(pincode);
  if (!area) throw new Error('Choose a postcode from our coverage list');
  if (!description?.trim()) throw new Error('Describe the fault first');

  // Affected = orders in progress at this postcode with no open incident yet
  const orders = (await query(
    `SELECT o.id FROM orders o
      WHERE o.pincode = $1 AND o.status = 'In Progress'
        AND NOT EXISTS (SELECT 1 FROM incidents i WHERE i.order_id = o.id AND i.state IN ('New', 'Open'))
      ORDER BY o.id`, [area.pincode]
  )).rows;
  if (!orders.length) throw new Error(`No open orders at postcode ${area.pincode} to link`);

  const major = (await query(
    `INSERT INTO incidents (incident_number, order_id, case_id, stage, description, priority, assignment_group, is_major, pincode, state)
     VALUES ($1, NULL, NULL, 'Network', $2, $3, $4, true, $5, 'New') RETURNING *`,
    [await nextNumber('incidents', 'INC'), description.trim(), priority, assignment_group, area.pincode]
  )).rows[0];
  await startSla('incident', major.id, `INC_${priority}`);

  // Child incidents are created one by one (each gets the next number), then all customers are told in parallel
  const children = [];
  for (const { id } of orders) {
    const { incident } = await raiseIncident(id, description, { priority, assignment_group, parentId: major.id, notify: false });
    children.push(incident);
  }
  const kcis = await mapLimit(children, 3, (child) =>
    sendKci({ orderId: child.order_id, incidentId: child.id }, 'INCIDENT_RAISED', { incident: child }));
  const sent = kcis.filter((k) => k?.status === 'Sent').length;
  await logEvent({ incidentId: major.id }, `Major incident raised at ${area.pincode} (${priority}, ${assignment_group}): ${major.description}. ` +
    `${children.length} orders linked: ${children.map((c) => c.incident_number).join(', ')}. ${sent} customers informed.`);

  return { incident: major, affected: children.length,
           notified: kcis.filter((k) => k?.status === 'Sent').length, held: kcis.filter((k) => k?.status === 'Held').length };
}

// Resolving a major incident resolves every linked incident; each customer gets a RESOLVED update
async function resolveMajorIncident(major, resolution) {
  const open = await countOpenTasks(major.id);
  if (open) throw new Error(`Complete the ${open} open task${open > 1 ? 's' : ''} before resolving this major incident`);

  const children = (await query(`SELECT * FROM incidents WHERE parent_id = $1 AND state IN ('New', 'Open')`, [major.id])).rows;
  const results = await mapLimit(children, 3, (child) => resolveIncident(child.id, resolution));
  const incident = (await query(
    `UPDATE incidents SET state = 'Resolved', resolution = $2, resolved_at = now() WHERE id = $1 RETURNING *`,
    [major.id, resolution || 'Resolved']
  )).rows[0];
  await stopSla('incident', major.id, 'Completed');
  const notified = results.filter((r) => r?.kci?.status === 'Sent').length;
  await logEvent({ incidentId: major.id }, `Major incident resolved: ${incident.resolution}. ${children.length} linked incidents resolved, ${notified} customers informed.`);
  return { incident, resolved: children.length, notified };
}

// Agent workspace: one incident with its activity, customer updates, stage and SLA
const INC_STAGES = ['New', 'Open', 'Resolved', 'Closed'];
export async function getIncidentDetail(id) {
  const { getActivities } = await import('./journalService.js');
  const inc = await getIncident(id);
  const openTasks = inc.tasks.filter((t) => t.state !== 'Done').length;
  const block = inc.state === 'Closed' ? 'This incident is closed'
    : inc.state === 'Open' && openTasks ? `Complete the ${openTasks} open task${openTasks > 1 ? 's' : ''} first` : null;
  return {
    ...inc,
    stages: INC_STAGES,
    activities: await getActivities({ incidentId: inc.id }, { publicOnly: false }),
    kcis: (await query(
      `SELECT k.*, o.customer_name, o.order_number FROM kci_communications k LEFT JOIN orders o ON o.id = k.order_id
        WHERE k.incident_id = $1 OR k.incident_id IN (SELECT id FROM incidents WHERE parent_id = $1) ORDER BY k.id DESC`, [inc.id]
    )).rows,
    incident_sla: inc.slas[0] || null,
    can_advance: !block,
    advance_block: block,
    next_stage: inc.state === 'Closed' ? null : INC_STAGES[INC_STAGES.indexOf(inc.state) + 1],
  };
}

// One entry point for the Resolve button: a major incident or a normal one
export async function resolveAnyIncident(id, resolution) {
  const inc = (await query(`SELECT * FROM incidents WHERE id = $1`, [id])).rows[0];
  if (!inc) throw new Error('Incident not found');
  if (!ACTIVE.includes(inc.state)) throw new Error(`This incident is already ${inc.state.toLowerCase()}`);
  return inc.is_major ? resolveMajorIncident(inc, resolution) : resolveIncident(id, resolution);
}

// New -> Open: an agent starts working on it
export async function startIncident(id, agent_name) {
  const inc = (await query(
    `UPDATE incidents SET state = 'Open', assigned_to = COALESCE(assigned_to, $2) WHERE id = $1 AND state = 'New' RETURNING *`,
    [id, agent_name || null]
  )).rows[0];
  if (!inc) throw new Error('Only a new incident can be started');
  await logEvent({ orderId: inc.order_id, incidentId: inc.id }, `Incident ${inc.incident_number} work started.`);
  return inc;
}

// Resolved -> Closed (a major incident closes its linked incidents too)
export async function closeIncident(id) {
  const inc = (await query(
    `UPDATE incidents SET state = 'Closed', closed_at = now() WHERE id = $1 AND state = 'Resolved' RETURNING *`, [id]
  )).rows[0];
  if (!inc) throw new Error('Only a resolved incident can be closed');
  if (inc.is_major) {
    await query(`UPDATE incidents SET state = 'Closed', closed_at = now() WHERE parent_id = $1 AND state = 'Resolved'`, [inc.id]);
  }
  await logEvent({ orderId: inc.order_id, incidentId: inc.id }, `Incident ${inc.incident_number} closed.`);
  return inc;
}
