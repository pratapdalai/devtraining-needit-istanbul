import { query } from '../db/index.js';
import { slaView } from './slaService.js';
import { getActivities } from './journalService.js';
import { firstName } from './format.js';

// Data for the agent workspace: left-menu counts, list tables, the landing page, and one "dossier" per record
// (everything the AI summary / copilot / email draft may read about an order, case or incident).

// "all" is used by the Ctrl+K search
const ORDER_VIEWS = { open: ['In Progress', 'On Hold'], completed: ['Completed'], closed: ['Closed'], cancelled: ['Cancelled'],
  all: ['In Progress', 'On Hold', 'Completed', 'Closed', 'Cancelled'] };
const CASE_VIEWS = { new: ['New'], open: ['Open'], resolved: ['Resolved'], closed: ['Closed'], cancelled: ['Cancelled'], active: ['New', 'Open'],
  all: ['New', 'Open', 'Resolved', 'Closed', 'Cancelled'] };
const INCIDENT_VIEWS = { new: ['New'], open: ['Open'], resolved: ['Resolved'], closed: ['Resolved', 'Closed'], active: ['New', 'Open'],
  all: ['New', 'Open', 'Resolved', 'Closed'] };
const RANK = { breached: 3, at_risk: 2, on_track: 1, paused: 1, met: 0 };

// The SLA to show for a record: the running one closest to breaching, else the latest one
function headline(slas) {
  if (!slas.length) return null;
  const running = slas.filter((s) => s.state === 'In Progress');
  const pool = running.length ? running : slas;
  // worst health first, then the most time used, then the one due soonest
  const worse = (a, b) => RANK[b.health] - RANK[a.health] || b.pct_used - a.pct_used || new Date(a.due_at) - new Date(b.due_at);
  return pool.reduce((a, b) => (worse(a, b) > 0 ? b : a));
}
async function slasBy(sql, args, keyOf) {
  const map = new Map();
  for (const s of (await query(sql, args)).rows) {
    const k = keyOf(s);
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(slaView(s));
  }
  return map;
}
// Open lists: most urgent first
const byRisk = (a, b) => (RANK[b.sla?.health] ?? -1) - (RANK[a.sla?.health] ?? -1) || (b.sla?.pct_used ?? 0) - (a.sla?.pct_used ?? 0)
  || new Date(a.sla?.due_at || 8.64e15) - new Date(b.sla?.due_at || 8.64e15) || b.id - a.id;
const like = (q) => `%${String(q).trim()}%`;

// ---------------- LEFT MENU COUNTS ----------------
export async function navCounts() {
  const one = async (sql) => (await query(sql)).rows[0];
  const orders = await one(`SELECT
      COUNT(*) FILTER (WHERE status IN ('In Progress', 'On Hold'))::int AS open,
      COUNT(*) FILTER (WHERE status = 'Completed')::int AS completed,
      COUNT(*) FILTER (WHERE status = 'Closed')::int AS closed,
      COUNT(*) FILTER (WHERE status = 'Cancelled')::int AS cancelled,
      COUNT(*) FILTER (WHERE needs_attention AND status IN ('In Progress', 'On Hold'))::int AS attention FROM orders`);
  const caseCounts = (type) => one(`SELECT
      COUNT(*) FILTER (WHERE state = 'New')::int AS new, COUNT(*) FILTER (WHERE state = 'Open')::int AS open,
      COUNT(*) FILTER (WHERE state = 'Resolved')::int AS resolved, COUNT(*) FILTER (WHERE state = 'Closed')::int AS closed,
      COUNT(*) FILTER (WHERE state = 'Cancelled')::int AS cancelled FROM cases WHERE type = '${type}'`);
  const incidents = await one(`SELECT
      COUNT(*) FILTER (WHERE state = 'New')::int AS new, COUNT(*) FILTER (WHERE state = 'Open')::int AS open,
      COUNT(*) FILTER (WHERE state = 'Resolved')::int AS resolved, COUNT(*) FILTER (WHERE state = 'Closed')::int AS closed,
      COUNT(*) FILTER (WHERE is_major AND state IN ('New', 'Open'))::int AS major FROM incidents`);
  const tasks = await one(`SELECT
      (SELECT COUNT(*) FROM order_tasks WHERE state IN ('Open', 'In Progress'))
    + (SELECT COUNT(*) FROM case_tasks WHERE state IN ('Open', 'In Progress'))
    + (SELECT COUNT(*) FROM incident_tasks WHERE state <> 'Done') AS open,
      (SELECT COUNT(*) FROM order_tasks WHERE state IN ('Closed', 'Cancelled'))
    + (SELECT COUNT(*) FROM case_tasks WHERE state IN ('Closed', 'Cancelled'))
    + (SELECT COUNT(*) FROM incident_tasks WHERE state = 'Done') AS closed`);
  const held = await one(`SELECT COUNT(*)::int AS n FROM kci_communications WHERE status = 'Held'`);
  const enquiries = await one(`SELECT COUNT(*) FILTER (WHERE status = 'New')::int AS new,
      COUNT(*) FILTER (WHERE status = 'Contacted')::int AS contacted, COUNT(*) FILTER (WHERE status = 'Closed')::int AS closed FROM enquiries`);
  return {
    orders, cases: await caseCounts('Case'), requests: await caseCounts('Service Request'), incidents, enquiries,
    tasks: { open: Number(tasks.open), closed: Number(tasks.closed) }, held_updates: held.n,
  };
}

// ---------------- LISTS ----------------
export async function listRecords(kind, { view, q, stage } = {}) {
  if (kind === 'orders') return listOrders(view || 'open', q, stage);
  if (kind === 'cases') return listCaseRows('Case', view || 'active', q);
  if (kind === 'requests') return listCaseRows('Service Request', view || 'active', q);
  if (kind === 'incidents') return listIncidentRows(view || 'active', q);
  if (kind === 'tasks') return listTasks(view || 'open', q);
  if (kind === 'enquiries') return listEnquiryRows(view || 'new', q);
  throw new Error('Unknown list');
}

// Website enquiries: callback requests and "notify me when you reach my area"
async function listEnquiryRows(view, q) {
  const state = { new: 'New', contacted: 'Contacted', closed: 'Closed' }[view];
  if (!state) throw new Error('Unknown enquiry view');
  const args = [state]; let where = 'e.status = $1';
  if (q) { args.push(like(q)); where += ` AND (e.name ILIKE $2 OR e.enquiry_number ILIKE $2 OR e.pincode ILIKE $2 OR e.message ILIKE $2)`; }
  return (await query(
    `SELECT e.*, c.area, c.city, c.country, c.broadband, c.mobile, c.tv, c.coming_soon
       FROM enquiries e LEFT JOIN coverage_areas c ON upper(replace(c.pincode, ' ', '')) = upper(replace(e.pincode, ' ', ''))
      WHERE ${where} ORDER BY e.id DESC`, args
  )).rows;
}

async function listOrders(view, q, stage) {
  const states = ORDER_VIEWS[view];
  if (!states) throw new Error('Unknown order view');
  const args = [states]; const where = ['o.status = ANY($1)'];
  if (q) { args.push(like(q)); where.push(`(o.order_number ILIKE $${args.length} OR o.customer_name ILIKE $${args.length} OR o.pincode ILIKE $${args.length})`); }
  if (stage) { args.push(stage); where.push(`o.current_stage = $${args.length}`); }
  const rows = (await query(
    `SELECT o.id, o.order_number, o.customer_name, o.customer_email, o.pincode, o.current_stage, o.status, o.needs_attention,
            o.addons, o.monthly_total_gbp, o.created_at, o.updated_at, p.name AS product_name, p.category, ca.area, ca.city,
            (SELECT name FROM order_tasks t WHERE t.order_id = o.id AND t.state IN ('Open', 'In Progress') ORDER BY seq LIMIT 1) AS current_task,
            (SELECT row_to_json(k) FROM (SELECT event, status, subject, review_verdict, created_at FROM kci_communications
               WHERE order_id = o.id ORDER BY id DESC LIMIT 1) k) AS last_update,
            (SELECT COUNT(*) FROM kci_communications WHERE order_id = o.id AND status = 'Held')::int AS held_updates,
            (SELECT incident_number FROM incidents i WHERE i.order_id = o.id AND i.state IN ('New', 'Open') LIMIT 1) AS open_incident
       FROM orders o JOIN products p ON p.id = o.product_id LEFT JOIN coverage_areas ca ON ca.pincode = o.pincode
      WHERE ${where.join(' AND ')} ORDER BY o.id DESC`, args
  )).rows;
  const slas = await slasBy(`SELECT * FROM slas WHERE order_id = ANY($1) AND record_type IN ('order', 'order_task')`,
    [rows.map((r) => r.id)], (s) => s.order_id);
  const NEXT = { Validation: 'Fulfilment', Fulfilment: 'Activation', Activation: 'Completed' };
  for (const r of rows) {
    r.sla = headline(slas.get(r.id) || []);
    // no open task while in progress = the stage's work is done and an agent can move the order on
    if (!r.current_task && r.status === 'In Progress' && NEXT[r.current_stage]) r.ready_to_move = NEXT[r.current_stage];
  }
  return view === 'open' ? rows.sort(byRisk) : rows;
}

async function listCaseRows(type, view, q) {
  const states = CASE_VIEWS[view];
  if (!states) throw new Error('Unknown case view');
  const args = [type, states]; const where = ['c.type = $1', 'c.state = ANY($2)'];
  if (q) { args.push(like(q)); where.push(`(c.case_number ILIKE $3 OR c.customer_name ILIKE $3 OR c.short_description ILIKE $3)`); }
  const rows = (await query(
    `SELECT c.id, c.case_number, c.type, c.customer_name, c.short_description, c.category, c.priority, c.state,
            c.assignment_group, c.assigned_to, c.origin, c.order_id, c.created_at, o.order_number,
            (SELECT COUNT(*) FROM case_tasks t WHERE t.case_id = c.id AND t.state IN ('Open', 'In Progress'))::int AS open_tasks,
            (SELECT row_to_json(k) FROM (SELECT event, status, subject, review_verdict, created_at FROM kci_communications
               WHERE case_id = c.id ORDER BY id DESC LIMIT 1) k) AS last_update,
            (SELECT COUNT(*) FROM kci_communications WHERE case_id = c.id AND status = 'Held')::int AS held_updates
       FROM cases c LEFT JOIN orders o ON o.id = c.order_id
      WHERE ${where.join(' AND ')} ORDER BY c.id DESC`, args
  )).rows;
  const slas = await slasBy(`SELECT * FROM slas WHERE record_type = 'case' AND record_id = ANY($1)`,
    [rows.map((r) => r.id)], (s) => s.record_id);
  for (const r of rows) r.sla = headline(slas.get(r.id) || []);
  return ['new', 'open', 'active'].includes(view) ? rows.sort(byRisk) : rows;
}

async function listIncidentRows(view, q) {
  const states = INCIDENT_VIEWS[view];
  if (!states) throw new Error('Unknown incident view');
  const args = [states]; const where = ['i.state = ANY($1)'];
  if (q) { args.push(like(q)); where.push(`(i.incident_number ILIKE $2 OR i.description ILIKE $2 OR o.customer_name ILIKE $2 OR i.pincode ILIKE $2)`); }
  const rows = (await query(
    `SELECT i.id, i.incident_number, i.is_major, i.pincode, i.description, i.priority, i.state, i.assignment_group,
            i.order_id, i.parent_id, i.created_at, i.resolved_at, o.order_number, o.customer_name, m.incident_number AS parent_number,
            (SELECT COUNT(*) FROM incidents ch WHERE ch.parent_id = i.id)::int AS affected,
            (SELECT COUNT(*) FROM incident_tasks t WHERE t.incident_id = i.id AND t.state <> 'Done')::int AS open_tasks
       FROM incidents i LEFT JOIN orders o ON o.id = i.order_id LEFT JOIN incidents m ON m.id = i.parent_id
      WHERE ${where.join(' AND ')} ORDER BY i.is_major DESC, i.priority, i.id DESC`, args
  )).rows;
  const slas = await slasBy(`SELECT * FROM slas WHERE record_type = 'incident' AND record_id = ANY($1)`,
    [rows.map((r) => r.id)], (s) => s.record_id);
  for (const r of rows) r.sla = headline(slas.get(r.id) || []);
  return rows;
}

// Every task in one list: order tasks, case tasks and incident tasks
async function listTasks(view, q) {
  const open = view === 'open';
  if (!['open', 'closed'].includes(view)) throw new Error('Unknown task view');
  const match = (r) => !q || [r.number, r.name, r.parent_number, r.customer_name, r.team].some((v) => String(v || '').toLowerCase().includes(String(q).toLowerCase()));

  const orderTasks = (await query(
    `SELECT t.id, t.task_number AS number, t.name, t.state, t.milestone, t.assignment_group AS team, t.assigned_to, t.created_at, t.closed_at,
            o.id AS parent_id, o.order_number AS parent_number, o.customer_name
       FROM order_tasks t JOIN orders o ON o.id = t.order_id
      WHERE t.state = ANY($1)`, [open ? ['Open', 'In Progress'] : ['Closed', 'Cancelled']]
  )).rows.map((r) => ({ ...r, kind: 'order_task', parent_type: 'order' }));
  const caseTasks = (await query(
    `SELECT t.id, t.task_number AS number, t.short_description AS name, t.state, t.assignment_group AS team, t.assigned_to, t.created_at, t.closed_at,
            c.id AS parent_id, c.case_number AS parent_number, c.customer_name
       FROM case_tasks t JOIN cases c ON c.id = t.case_id
      WHERE t.state = ANY($1)`, [open ? ['Open', 'In Progress'] : ['Closed', 'Cancelled']]
  )).rows.map((r) => ({ ...r, kind: 'case_task', parent_type: 'case' }));
  const incTasks = (await query(
    `SELECT t.id, t.task_number AS number, t.short_description AS name, t.state, t.assignment_group AS team, t.assigned_to, t.created_at,
            t.completed_at AS closed_at, i.id AS parent_id, i.incident_number AS parent_number, o.customer_name
       FROM incident_tasks t JOIN incidents i ON i.id = t.incident_id LEFT JOIN orders o ON o.id = i.order_id
      WHERE ${open ? "t.state <> 'Done'" : "t.state = 'Done'"}`
  )).rows.map((r) => ({ ...r, kind: 'incident_task', parent_type: 'incident' }));

  const slas = await slasBy(
    `SELECT * FROM slas WHERE (record_type = 'order_task' AND record_id = ANY($1)) OR (record_type = 'case_task' AND record_id = ANY($2))`,
    [orderTasks.map((r) => r.id), caseTasks.map((r) => r.id)], (s) => `${s.record_type}:${s.record_id}`);
  const rows = [...orderTasks, ...caseTasks, ...incTasks].filter(match);
  for (const r of rows) r.sla = headline(slas.get(`${r.kind}:${r.id}`) || []);
  return open ? rows.sort(byRisk) : rows.sort((a, b) => new Date(b.closed_at || 0) - new Date(a.closed_at || 0));
}

// ---------------- LANDING PAGE ----------------
export async function homeData() {
  const one = async (sql) => (await query(sql)).rows[0];
  const nav = await navCounts();
  const running = (await query(`SELECT * FROM slas WHERE state = 'In Progress'`)).rows.map(slaView);
  const health = { on_track: 0, at_risk: 0, breached: 0 };
  for (const s of running) health[s.health] = (health[s.health] || 0) + 1;
  const orderRisk = (await query(
    `SELECT * FROM slas WHERE state = 'In Progress' AND record_type IN ('order', 'order_task')`
  )).rows.map(slaView).filter((s) => !['on_track', 'paused'].includes(s.health));
  const today = await one(`SELECT COUNT(*)::int AS n,
      COUNT(*) FILTER (WHERE ai_source = 'openai')::int AS by_openai,
      COUNT(*) FILTER (WHERE status = 'Held')::int AS held FROM kci_communications WHERE created_at >= date_trunc('day', now())`);
  const stages = (await query(
    `SELECT current_stage AS stage, COUNT(*)::int AS n FROM orders WHERE status IN ('In Progress', 'On Hold')
      GROUP BY current_stage ORDER BY MIN(array_position(ARRAY['Created','Validation','Fulfilment','Activation'], current_stage))`
  )).rows;
  const feed = (await query(
    `SELECT k.id, k.event, k.status, k.review_verdict, k.subject, k.created_at, k.ai_source, k.order_id, k.case_id,
            COALESCE(o.customer_name, c.customer_name) AS customer_name, COALESCE(o.order_number, c.case_number) AS reference
       FROM kci_communications k LEFT JOIN orders o ON o.id = k.order_id LEFT JOIN cases c ON c.id = k.case_id
      ORDER BY k.id DESC LIMIT 8`
  )).rows;
  return {
    nav,
    orders: { open: nav.orders.open, at_risk: new Set(orderRisk.map((s) => s.record_id)).size, updates_today: today.n, stages },
    service: {
      new_cases: nav.cases.new, open_cases: nav.cases.open, resolved_cases: nav.cases.resolved,
      requests: nav.requests.new + nav.requests.open, major_incidents: nav.incidents.major,
      open_incidents: nav.incidents.new + nav.incidents.open,
    },
    updates_today: today,
    sla_health: health,
    feed,
  };
}

// Facts for the AI briefing: what needs a human now (each item points at a record)
export async function briefingFacts() {
  const risky = (await query(`SELECT * FROM slas WHERE state = 'In Progress'`)).rows
    .map((s) => ({ raw: s, v: slaView(s) })).filter((x) => !['on_track', 'paused'].includes(x.v.health))
    .sort((a, b) => b.v.pct_used - a.v.pct_used).slice(0, 4);
  const slaItems = [];
  for (const { raw, v } of risky) {
    let rec = null;
    if (raw.record_type === 'order' || raw.record_type === 'order_task') {
      rec = (await query(`SELECT id, order_number AS number, customer_name FROM orders WHERE id = $1`, [raw.order_id])).rows[0];
      if (rec) rec.type = 'order';
    } else if (raw.record_type === 'case' || raw.record_type === 'case_task') {
      const caseId = raw.record_type === 'case' ? raw.record_id
        : (await query(`SELECT case_id FROM case_tasks WHERE id = $1`, [raw.record_id])).rows[0]?.case_id;
      rec = (await query(`SELECT id, case_number AS number, customer_name FROM cases WHERE id = $1`, [caseId])).rows[0];
      if (rec) rec.type = 'case';
    } else if (raw.record_type === 'incident') {
      rec = (await query(`SELECT id, incident_number AS number, NULL AS customer_name FROM incidents WHERE id = $1`, [raw.record_id])).rows[0];
      if (rec) rec.type = 'incident';
    }
    if (rec) slaItems.push({ record: rec, sla: v.name, pct_used: v.pct_used, health: v.health, time_left: v.time_left });
  }
  const held = (await query(
    `SELECT k.id, k.subject, k.review_notes, k.order_id, k.case_id, COALESCE(o.order_number, c.case_number) AS number,
            COALESCE(o.customer_name, c.customer_name) AS customer_name
       FROM kci_communications k LEFT JOIN orders o ON o.id = k.order_id LEFT JOIN cases c ON c.id = k.case_id
      WHERE k.status = 'Held' ORDER BY k.id DESC LIMIT 3`
  )).rows.map((k) => ({ record: { type: k.order_id ? 'order' : 'case', id: k.order_id || k.case_id, number: k.number, customer_name: k.customer_name },
    subject: k.subject, reviewer_issues: k.review_notes }));
  const handovers = (await query(
    `SELECT id, case_number AS number, type, customer_name, short_description, category, priority FROM cases
      WHERE origin = 'Order Assistant' AND state = 'New' ORDER BY id DESC LIMIT 3`
  )).rows.map((c) => ({ record: { type: 'case', id: c.id, number: c.number, customer_name: c.customer_name },
    case_type: c.type, title: c.short_description, category: c.category, priority: c.priority }));
  const majors = (await query(
    `SELECT i.id, i.incident_number AS number, i.pincode, i.description, i.priority,
            (SELECT COUNT(*) FROM incidents ch WHERE ch.parent_id = i.id)::int AS affected
       FROM incidents i WHERE i.is_major AND i.state IN ('New', 'Open') ORDER BY i.id DESC LIMIT 2`
  )).rows.map((i) => ({ record: { type: 'incident', id: i.id, number: i.number }, postcode: i.pincode, description: i.description, affected: i.affected }));
  const attention = (await query(
    `SELECT id, order_number AS number, customer_name, validation->>'verdict' AS verdict FROM orders
      WHERE needs_attention AND status IN ('In Progress', 'On Hold') ORDER BY id DESC LIMIT 3`
  )).rows.map((o) => ({ record: { type: 'order', id: o.id, number: o.number, customer_name: o.customer_name },
    reason: o.verdict === 'REVIEW' ? 'AI Order Agent asked for a human review' : 'Customer wrote to us or the assistant handed over' }));
  return { sla_risks: slaItems, held_updates: held, new_handover_cases: handovers, major_incidents: majors, orders_needing_attention: attention };
}

// ---------------- RECORD DOSSIER (for the AI) ----------------
// Everything about one record, in a compact shape. Internal notes are included for the AGENT's AI tools only.
const brief = (entries) => entries.filter((e) => !['email', 'sms'].includes(e.entry_type)).slice(0, 15)
  .map((e) => ({ when: e.created_at, who: e.author_name || e.author_type, kind: e.entry_type, visibility: e.visibility, text: e.message }));

export async function dossier(type, id) {
  if (type === 'order') {
    const { getOrderDetail } = await import('./orderService.js');
    const o = await getOrderDetail(id);
    return {
      record_type: 'order', reference: o.order_number,
      customer: { name: o.customer_name, first_name: firstName(o.customer_name), email: o.customer_email, phone: o.customer_phone },
      plan: o.product_name, addons: (o.addons || []).map((a) => a.name), monthly_total_gbp: Number(o.monthly_total_gbp),
      postcode: o.pincode, address: o.address, stage: o.current_stage, status: o.status, customer_needs: o.customer_needs,
      validation: o.validation ? { verdict: o.validation.verdict, summary: o.validation.summary, issues: o.validation.issues } : null,
      tasks: o.tasks.map((t) => ({ number: t.task_number, name: t.name, team: t.assignment_group, state: t.state, milestone: t.milestone,
        details: t.details, sla: t.sla && { pct_used: t.sla.pct_used, health: t.sla.health, time_left: t.sla.time_left } })),
      order_sla: o.order_sla && { name: o.order_sla.name, pct_used: o.order_sla.pct_used, health: o.order_sla.health, time_left: o.order_sla.time_left },
      move_to_next_stage: o.can_advance ? `allowed (to ${o.next_stage})` : `blocked: ${o.advance_block}`,
      incidents: o.incidents.map((i) => ({ number: i.incident_number, state: i.state, description: i.description })),
      cases: o.cases.map((c) => ({ number: c.case_number, type: c.type, state: c.state, title: c.short_description })),
      customer_updates: o.kcis.slice(0, 8).map((k) => ({ event: k.event, status: k.status, reviewer: k.review_verdict, subject: k.subject, when: k.created_at })),
      activity: brief(o.activities),
    };
  }
  if (type === 'case') {
    const { getCaseDetail } = await import('./caseService.js');
    const c = await getCaseDetail(id);
    return {
      record_type: c.type === 'Service Request' ? 'service request' : 'case', reference: c.case_number,
      customer: { name: c.customer_name, first_name: firstName(c.customer_name), email: c.customer_email, phone: c.customer_phone },
      title: c.short_description, description: c.description, category: c.category, priority: c.priority, state: c.state,
      team: c.assignment_group, assigned_to: c.assigned_to, origin: c.origin, resolution: c.resolution,
      order: c.order && { reference: c.order.order_number, plan: c.order.product_name, stage: c.order.current_stage, status: c.order.status },
      tasks: c.tasks.map((t) => ({ number: t.task_number, name: t.short_description, team: t.assignment_group, state: t.state,
        sla: t.sla && { pct_used: t.sla.pct_used, health: t.sla.health, time_left: t.sla.time_left } })),
      sla: c.case_sla && { name: c.case_sla.name, pct_used: c.case_sla.pct_used, health: c.case_sla.health, time_left: c.case_sla.time_left },
      move_to_next_stage: c.can_advance ? `allowed (to ${c.next_stage})` : `blocked: ${c.advance_block}`,
      customer_updates: c.kcis.slice(0, 8).map((k) => ({ event: k.event, status: k.status, subject: k.subject, when: k.created_at })),
      activity: brief(c.activities),
    };
  }
  if (type === 'incident') {
    const { getIncident } = await import('./incidentService.js');
    const i = await getIncident(id);
    const order = i.order_id ? (await query(`SELECT customer_email, customer_phone FROM orders WHERE id = $1`, [i.order_id])).rows[0] : null;
    return {
      record_type: i.is_major ? 'major incident' : 'incident', reference: i.incident_number,
      customer: i.customer_name ? { name: i.customer_name, first_name: firstName(i.customer_name), email: order?.customer_email, phone: order?.customer_phone } : null,
      order: i.order_number || null, postcode: i.pincode, description: i.description, priority: i.priority, state: i.state,
      team: i.assignment_group, parent: i.parent_number, affected_customers: i.children.length,
      tasks: i.tasks.map((t) => ({ number: t.task_number, name: t.short_description, team: t.assignment_group, state: t.state })),
      sla: i.slas[0] && { name: i.slas[0].name, pct_used: i.slas[0].pct_used, health: i.slas[0].health, time_left: i.slas[0].time_left },
      activity: brief(await getActivities({ incidentId: i.id }, { publicOnly: false })),
    };
  }
  throw new Error('Record type must be order, case or incident');
}

// Where an email or note for this record is filed, and who the customer is
export async function recordTarget(type, id) {
  if (type === 'order') {
    const o = (await query(`SELECT id, customer_email, customer_name FROM orders WHERE id = $1`, [id])).rows[0];
    if (!o) throw new Error('Order not found');
    return { target: { orderId: o.id }, email: o.customer_email, name: o.customer_name };
  }
  if (type === 'case') {
    const c = (await query(`SELECT id, customer_email, customer_name FROM cases WHERE id = $1`, [id])).rows[0];
    if (!c) throw new Error('Case not found');
    return { target: { caseId: c.id }, email: c.customer_email, name: c.customer_name };
  }
  if (type === 'incident') {
    const i = (await query(
      `SELECT i.id, i.order_id, o.customer_email, o.customer_name FROM incidents i LEFT JOIN orders o ON o.id = i.order_id WHERE i.id = $1`, [id]
    )).rows[0];
    if (!i) throw new Error('Incident not found');
    return { target: { orderId: i.order_id, incidentId: i.id }, email: i.customer_email, name: i.customer_name };
  }
  throw new Error('Record type must be order, case or incident');
}
