import { rules } from './settings.js';

// The working calendar: the ONLY place that knows the working days and hours (config/business-rules.json).
// working_calendar.enabled = false -> every day is a working day; the time windows still apply.

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const cal = () => rules().working_calendar;
const mins = (hhmm) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3));

export const isWorkingDay = (d) => !cal().enabled || cal().working_days.includes(DAY_NAMES[new Date(d).getDay()]);

// The next working day after a date (keeps the time of day)
export function nextWorkingDay(from = new Date()) {
  const d = new Date(from);
  do { d.setDate(d.getDate() + 1); } while (!isWorkingDay(d));
  return d;
}

// n working days after a date
export function addWorkingDays(from, n) {
  let d = new Date(from);
  for (let i = 0; i < Math.max(0, Math.round(n)); i++) d = nextWorkingDay(d);
  return d;
}

// The same calendar day at "HH:MM"
export function atTime(date, hhmm) {
  const d = new Date(date); const m = mins(hhmm);
  d.setHours(Math.floor(m / 60), m % 60, 0, 0);
  return d;
}

// "10:00" -> "10 AM", "14:30" -> "2:30 PM"
export function h12(hhmm) {
  const h = Number(hhmm.slice(0, 2)); const m = hhmm.slice(3);
  return `${h % 12 || 12}${m === '00' ? '' : `:${m}`} ${h < 12 ? 'AM' : 'PM'}`;
}

const hours = () => cal().working_hours.split('-');
export const dayStart = (d) => atTime(d, hours()[0]);                  // e.g. courier from 8 AM
export const dayEnd = (d) => atTime(d, hours()[1]);                    // e.g. courier until 6 PM; plans end here
export const readyBy = (d) => atTime(d, cal().activation_ready_by);    // activation done by noon
export const courierWindow = () => `between ${h12(hours()[0])} and ${h12(hours()[1])}`;
export const slotDaysAhead = () => cal().slot_booking_days_ahead;

// Engineer visit windows: [{ start: "10:00", end: "12:00", label: "10 AM-12 PM", minutes: 120 }]
export const slotWindows = () => cal().engineer_slots.map((w) => {
  const [start, end] = w.split('-');
  return { start, end, label: `${h12(start)}-${h12(end)}`, minutes: mins(end) - mins(start) };
});
