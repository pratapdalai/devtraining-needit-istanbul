import { client, MODEL, askWithTools } from './openaiClient.js';
import { getCatalog, priceQuote } from './pricingService.js';
import { checkCoverage } from './coverageService.js';

// What the advisor must answer with (Structured Outputs)
const ADVISOR_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    answer: { type: 'string' },              // the chat reply to the customer
    needs_summary: { type: 'string' },       // everything learned about the customer so far, in one line
    recommend: { type: 'boolean' },          // true = show a plan card with a "Choose this plan" button
    product_code: { type: 'string' },        // the recommended base plan code, or ""
    addon_codes: { type: 'array', items: { type: 'string' } },
    reason: { type: 'string' },              // why this plan fits THIS customer, or ""
  },
  required: ['answer', 'needs_summary', 'recommend', 'product_code', 'addon_codes', 'reason'],
};

// The functions the advisor may call (function calling)
const ADVISOR_TOOLS = [
  {
    type: 'function',
    name: 'get_catalog',
    description: 'Get all NovaTel plans, the add-ons available for each plan, and the price rules.',
    strict: true,
    parameters: { type: 'object', properties: {}, required: [], additionalProperties: false },
  },
  {
    type: 'function',
    name: 'check_coverage',
    description: 'Check which NovaTel services (broadband = fiber, mobile = 5G, tv = IPTV) are available at a ' +
      'postcode or a town / city / country name in the UK or Europe. Call it whenever the visitor mentions where they live.',
    strict: true,
    parameters: {
      type: 'object',
      properties: { place: { type: 'string', description: 'A postcode or a place name, e.g. "M14 5RG", "10115", "Leeds" or "Belfast"' } },
      required: ['place'],
      additionalProperties: false,
    },
  },
  {
    type: 'function',
    name: 'price_quote',
    description: 'Calculate the exact monthly price of one plan with optional add-ons, including any discount. ' +
      'Always call this before telling the customer a total price.',
    strict: true,
    parameters: {
      type: 'object',
      properties: {
        product_code: { type: 'string', description: 'Plan code from get_catalog, e.g. FIBER100' },
        addon_codes: { type: 'array', items: { type: 'string' }, description: 'Add-on codes from get_catalog, may be empty' },
      },
      required: ['product_code', 'addon_codes'],
      additionalProperties: false,
    },
  },
];

const INSTRUCTIONS = `
You are "NovaTel Plan Advisor", a friendly pre-sales advisor for NovaTel, a telecom operator in the UK and Europe.
All prices are monthly, in British pounds (£).
You chat with a visitor on the Plans page who has NOT bought anything yet. Your job: understand what they
need, answer their questions, and suggest the best plan - optionally customised with add-ons.

The JSON input has the visitor's latest "message", the "conversation_history" (oldest first), the
"needs_so_far" you summarised earlier, and "coverage_checked" if the visitor already checked their area on the page.

How to talk:
- Warm, natural, short: 1-3 sentences per reply, like a helpful shop assistant in a chat app.
- Always reply in English (British spelling), even if the visitor writes in another language.
- Understand informal messages and typos. Greetings get a friendly reply and one opening question.

How to advise:
- First understand needs. Useful things to learn: who will use it (how many people), home internet or
  mobile or TV, work from home / online classes / gaming / streaming / sports, size of the home, budget.
- Ask at most ONE question per reply, and at most 2 questions in total before you suggest something.
  If the visitor already gave enough detail, suggest straight away.
- Call get_catalog to know the plans and add-ons. There are 3 plans per service (broadband, mobile, tv),
  at different prices. Use ONLY those plans and add-ons. Never invent plans, speeds, features, offers or prices.
  Respect the visitor's budget: pick the tier that fits it.
- Coverage: if the visitor mentions a place or postcode, call check_coverage. Recommend ONLY services available
  there. If a service is not available, say so plainly, share the "coming_soon" date if there is one, and suggest
  the "Notify me" or "Request a callback" option on the page. Never say we serve an area without checking.
  If they have not said where they live and want broadband or TV, ask for their postcode (it counts as one question).
- Call price_quote for the exact plan + add-ons before you mention any total price, and use its numbers.
- Whenever you suggest a plan, do it fully in the SAME reply: call price_quote, set recommend=true, and say the
  monthly price. The visitor then sees a plan card they can choose. Never ask for permission first
  (no "Would you like me to check the price?").
- Recommend ONE base plan, plus only the add-ons that match a need the visitor actually mentioned
  (e.g. MESH for a big or multi-floor home, SPEED300 for heavy work-from-home or gaming, XSIM for family).
  Do not upsell add-ons they did not need. Explain the reason in the visitor's own terms.
- Each order is for one plan. If they need two different services (e.g. home broadband AND mobile),
  recommend the most important one now and mention they can order the other one after.
- If they ask something you cannot answer from the catalog (coverage at their address, contract terms,
  exact installation date), say so honestly and that our team will confirm after they order.
- You cannot place orders. If the visitor asks you to order for them, say so, and tell them to click
  'Choose this plan' on the card and fill in their details. Never say an order was placed.

Output fields:
- answer: your chat reply.
- needs_summary: one line with everything known about the visitor so far (update "needs_so_far").
- recommend: true only when you are suggesting a specific plan in this reply; then fill product_code,
  addon_codes (may be empty) and reason (one short sentence). Otherwise recommend=false,
  product_code="", addon_codes=[], reason="".
`.trim();

// Keep the public endpoint cheap and safe: limit message length and history size
const clip = (s, n) => String(s ?? '').slice(0, n);

export async function adviseVisitor({ message, history = [], needs_so_far = '', coverage_checked = null }) {
  if (!message?.trim()) throw new Error('Message is empty');
  if (!client) throw new Error('The AI advisor is not connected yet (OPENAI_API_KEY missing on the server).');

  const input = {
    message: clip(message.trim(), 1000),
    needs_so_far: clip(needs_so_far, 500),
    coverage_checked: coverage_checked && typeof coverage_checked === 'object' ? coverage_checked : null,
    conversation_history: (Array.isArray(history) ? history : []).slice(-10)
      .map((h) => `${h.role === 'visitor' ? 'Visitor' : 'Advisor'}: ${clip(h.text, 800)}`),
  };

  // Our real functions behind the tools
  const runTool = async (name, args) => {
    try {
      if (name === 'get_catalog') return await getCatalog();
      if (name === 'check_coverage') return await checkCoverage(args.place);
      if (name === 'price_quote') return await priceQuote(args.product_code, args.addon_codes);
      return { error: `Unknown tool ${name}` };
    } catch (err) {
      return { error: err.message }; // the AI sees the error and can correct itself
    }
  };

  let r;
  try {
    r = await askWithTools({ instructions: INSTRUCTIONS, input, name: 'plan_advice', schema: ADVISOR_SCHEMA, tools: ADVISOR_TOOLS, runTool });
  } catch (err) {
    console.error('OpenAI advisor call failed:', err.message);
    throw new Error('Our advisor could not reply just now. Please try again in a moment.');
  }
  const d = r.data;

  // Never trust a price from the AI: the plan card always uses OUR calculator.
  let quote = null;
  if (d.recommend && d.product_code) {
    try {
      // keep only add-ons that really exist for this plan (drops anything the AI got wrong)
      const plan = (await getCatalog()).plans.find((p) => p.code === d.product_code);
      const valid = (d.addon_codes || []).filter((c) => plan?.addons.some((a) => a.code === c));
      quote = plan ? await priceQuote(plan.code, valid) : null;
    } catch {
      quote = null;
    }
  }

  return {
    answer: d.answer,
    needs_summary: d.needs_summary,
    recommendation: quote ? { ...quote, reason: d.reason } : null,
    actions: r.actions.map((a) => a.tool),
    ai_source: 'openai',
    model: MODEL,
    latency_ms: r.latency_ms,
  };
}
