# Auto KCI — AI agents that keep telecom customers informed

> Working name (final candidate: **OrderAssure AI**). Built for the **Infosys Global OpenAI Hackathon** (submission
> deadline 30 Nov 2026, 23:59 UTC). The demo operator **NovaTel** and every customer in the demo data are fictional.

**KCI** means *Keep Customer Informed*. A telecom order passes through many teams (validation, equipment delivery,
engineer visit, activation) and the customer sees none of it, so they call to ask "where is my order?". Auto KCI is
an order and service management workspace in which **ten OpenAI-powered agents** plan the work, watch every task's
SLA, decide when the customer must hear something, write the update, check it before it is sent, and help the
service agent with summaries, replies and emails.

| | |
|---|---|
| **Problem** | Customers are left guessing; agents spend their day writing "your order is in progress" messages; delays are discovered when the customer complains. |
| **Solution** | Every milestone, risk and delay produces one short, personal update: decided by an AI agent, written by an AI agent, checked by a second AI agent, sent by email and SMS, and shown on the customer's tracking page. Code owns every fact (dates, prices, slots); AI owns judgement and language. |
| **Result in the demo** | A delivery slips by two days → the engineer visit that depends on it is rebooked automatically → the AI decides what the customer must know → **one** clear message with the new dates is sent, and the agent sees why in the activity log. |

> **AI status:** the app runs fully in **demo mode** without a key (every AI feature returns a clearly labelled
> rules/template answer). The hackathon OpenAI key is pending; `npm run test:ai` checks all agents on the real model
> in one command as soon as it is added. The screenshots below were taken in demo mode.

---

## Contents
1. [What you can see](#1-what-you-can-see)
2. [How it works](#2-how-it-works)
3. [Use of OpenAI](#3-use-of-openai)
4. [Architecture](#4-architecture)
5. [Setup and run](#5-setup-and-run)
6. [Demo script (5 minutes)](#6-demo-script-5-minutes)
7. [Testing](#7-testing)
8. [API reference](#8-api-reference)
9. [Security, privacy and safety](#9-security-privacy-and-safety)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. What you can see

| Page | URL | For | What it does |
|---|---|---|---|
| **Agent workspace** | `/workspace.html` | Service agents | Landing console with an **AI briefing**; Order management and Service management with live counts; lists for orders, cases, service requests, incidents, tasks and website enquiries; record pages with stage bar, activity, tasks, SLAs, **AI summary**, **Copilot** and **Draft email with AI**; Ctrl+K search |
| **Customer website** | `/` | Visitors | Coverage check by postcode (UK + Europe), 9 plans in £, **AI Plan Advisor**, checkout with add-ons and a postcode picker |
| **Tracking page** | `/track.html` | Customers | Find an order by number (e.g. `ORD-1001`), progress, "what's next", expected-ready date, every update, steps with planned dates, **Order Assistant** chat (rebook the engineer, send a router photo, hand over to a person) |
| **AI impact** | `/workspace.html#/impact` | Managers, judges | What each of the ten agents did: updates written, decisions taken, visits rebooked, messages fixed or stopped by the Reviewer, SLAs met, agent time saved, tokens |

| Landing console with AI briefing | Order record |
|---|---|
| ![Landing console](docs/screenshots/01-landing-console.png) | ![Order record](docs/screenshots/03-order-record.png) |
| **A delay: AI decision + engineer moved + one update** | **Customer tracking page** |
| ![Delay decision](docs/screenshots/04-delay-decision.png) | ![Tracking page](docs/screenshots/06-tracking-page.png) |
| **Open orders, most urgent first** | **Case record (service management)** |
| ![Open orders](docs/screenshots/02-open-orders.png) | ![Case record](docs/screenshots/05-case-record.png) |
| **AI impact: what the ten agents did** | **Customer website** |
| ![AI impact](docs/screenshots/08-ai-impact.png) | ![Website](docs/screenshots/07-website.png) |

---

## 2. How it works

### 2.1 Order journey (an order never creates a case)

```mermaid
flowchart LR
  A[Created<br/>customer submits] --> B[Validation<br/>AI Order Agent]
  B --> C[Fulfilment<br/>equipment delivery<br/>engineer visit]
  C --> D[Activation]
  D --> E[Completed<br/>final update]
```

1. **Created** — the customer places the order on the website. Coverage and price are checked by code. *No update is
   sent: the customer just submitted it.*
2. **Validation** — the **AI Order Agent** checks the order (code checks: coverage, price, contact details, address,
   duplicates; AI review: anything a human should look at) and writes notes for the teams (e.g. "two-floor house:
   confirm the mesh extender upstairs"). Code builds **the plan**: every task gets planned dates, a customer-impact
   flag and the task it depends on.
3. **Fulfilment / Activation** — an agent works the tasks; **Move to next stage** stays locked (with the reason shown)
   until the stage's tasks are closed and no incident is open.

**Order tasks** (one team each, each with its own SLA):

| Task | Depends on | Customer updates (AI-written) |
|---|---|---|
| Equipment delivery (router, mesh, SIM or set-top box) | — | **CPE Delivery Scheduled** (date, window, courier, tracking ref) · **CPE Delivered** |
| Engineer visit (broadband) | Equipment delivery | **Engineer Appointment Scheduled** (slot, duration, how to prepare) · **Engineer Visit Completed** (speed measured) |
| Service activation | Engineer visit (or delivery) | **Service Activated** · then **Order Completed** (monthly total, first bill date) |

The engineer can be **booked as soon as the delivery is scheduled**, but the visit can only be **completed once the
equipment has arrived**, and slots are only offered from the day after it is due.

### 2.2 The KCI Agent watches the SLA around every task

```mermaid
flowchart TD
  T[Order task with plan + SLA] -->|completed on time| H[Milestone update]
  T -->|75% of SLA used| R{AI KCI Decision Agent}
  R -->|helps the customer| P[Proactive update]
  R -->|customer already has a date| N[No update, reason logged]
  T -->|SLA breached or<br/>agent reports a delay| D[Code: revised ETA,<br/>move dependent tasks,<br/>rebook engineer]
  D --> R2{AI KCI Decision Agent<br/>what must be said}
  R2 --> W[KCI Writer: ONE update] --> V[AI Reviewer] --> S[Email + SMS + tracking page]
```

| Situation | What happens |
|---|---|
| Completed on the happy path | Completion update for that milestone |
| **At risk** (75% of the task SLA used) | The AI KCI Decision Agent decides: proactive update now, or wait (e.g. the customer already has a date and was told recently). Every decision and its reason is stored and shown in the **AI decisions** tab. |
| **Delayed** (SLA breached, or an agent clicks **Report delay**) | Code calculates the revised ETA, moves every dependent task, and rebooks a booked engineer visit to the first free slot after the new delivery date. The decision agent decides what the message must cover; the customer gets **one** update (new date, moved visit, new ready-by date, apology). The internal reason is never shared. |

Every task carries: planned start, planned end, original planned end (shows "was 21 Nov" after a delay), actual start,
actual completion, SLA, customer impact (yes/no) and the task it depends on.

### 2.3 Service management (cases, service requests, incidents)

- **Cases** (`CS…`) and **Service Requests** (`SR…`): opened by the **Order Assistant** when it hands a chat over to a
  person, or by an agent (**New case**). The **AI Triage Agent** fills type, category, priority, team and title.
  Stages New → Open → Resolved (a resolution is required and sent to the customer) → Closed. Case tasks block resolving.
- **Incidents** are raised **on the order** (the order goes On Hold until resolved). A **major incident** covers one
  fault at a postcode: every open order there is linked and each customer gets a personal update; incident tasks,
  when done, tell every affected customer about the progress.
- SLAs on cases (by priority), service requests, case tasks and incidents.

### 2.4 How one customer update is produced

```
event (milestone, risk, delay, case opened/resolved, incident…)
  → [AI KCI Decision Agent]   only for risk/delay: send or not, and what it must cover
  → context built by code     facts from the database: dates, slots, items, tracking ref, prices, customer needs
  → KCI Writer (AI)           subject + email message + SMS ≤ 160 chars, first name, British English
  → AI Reviewer (AI + rules)  PASS / FIXED (corrected) / HOLD (a human must approve)
  → Sent: email + SMS (simulated) + tracking page      Held: shown in the activity with "Approve and send"
```

---

## 3. Use of OpenAI

All agents call the **OpenAI Responses API** through one client (`services/openaiClient.js`):

| Technique | Where |
|---|---|
| **Structured Outputs** (`text.format` with a strict JSON schema) | Every agent: the app never parses free text |
| **Function calling** with a multi-round loop (`previous_response_id`, max 4 rounds) | Plan Advisor (`get_catalog`, `check_coverage`, `price_quote`), Order Assistant (`get_available_slots`, `reschedule_visit`) |
| **Vision** (image input) | Photo Diagnosis of router lights and installations |
| **Agent-to-agent pipeline** | Decision Agent → Writer → Reviewer; Order Assistant → Triage Agent → Writer |

The model is set by `OPENAI_MODEL` in `.env`. Azure OpenAI works by setting `OPENAI_BASE_URL` and using the
deployment name as the model.

### The ten agents

| # | Agent | File | What it decides or writes | Guardrail (code) |
|---|---|---|---|---|
| 1 | **Plan Advisor** | `advisorAgent.js` | Understands a visitor's needs, recommends a plan + add-ons (function calling) | Price always recalculated by `priceQuote()`; unknown add-ons dropped; coverage checked by a tool |
| 2 | **AI Order Agent** | `orderAgent.js` | Validates a new order (PASS / REVIEW), writes notes for the engineer and courier | Code runs the exact checks and decides which tasks exist; the AI can ask for a review but cannot pass a failed check |
| 3 | **AI KCI Decision Agent** | `kciDecisionAgent.js` | At risk: send a proactive update or wait. Delayed: what the update must cover | Code calculates every date; a delay is always told; internal tasks never are |
| 4 | **KCI Writer** | `kciAgent.js` | Every customer update: subject, email, SMS, next-update time | Only facts from the context; first name; no internal details |
| 5 | **AI Reviewer** | `reviewAgent.js` | Checks every update, agent reply and agent email: PASS / FIXED / HOLD | A rule check always runs too (incident numbers, internal-note phrases); HOLD waits for a human |
| 6 | **Order Assistant** | `botAgent.js` | Answers customers on the tracking page; offers and books engineer slots; hands over to a person | Only offered slots can be booked; only after the equipment is due; no silent canned answers |
| 7 | **AI Triage Agent** | `triageAgent.js` | Case or Service Request, category, priority, team, title | Categories and teams validated by code |
| 8 | **Photo Diagnosis** | `visionAgent.js` | Reads a photo, explains it, may raise an incident | Raises an incident for a human team; never "fixes" anything itself |
| 9 | **Insight Agent** | `insightAgent.js` | Sentiment and urgency of each customer message | — |
| 10 | **Agent Assist** | `assistAgent.js` | AI summary (next best action, risk), Copilot chat about a record, Write with AI email, landing-page briefing | Sees only the record's dossier; emails and replies must pass the AI Reviewer; briefing items are checked to point at real records |

### Context engineering
- **Instructions per agent** in each file: role, rules, tone, what it must never do.
- **Structured context, not dumps**: code builds a compact JSON "dossier" (order, tasks with plans and SLAs, updates,
  activity). Internal notes are passed **for understanding only**; the Reviewer and the rule check stop them reaching
  the customer.
- **Tools instead of data**: the advisor and the assistant fetch only what they need (coverage, catalogue, price, slots).
- **Code owns exact facts**: prices, coverage, dates, slots, tracking references, revised ETAs, business rules.

---

## 4. Architecture

```
 Customer website ─┐                 ┌────────────── Node.js 24 + Express 5 ──────────────┐
 Tracking page ────┤   HTTPS + JSON  │ routes/orders.js     website + tracking             │     ┌─────────────┐
 Agent workspace ──┼───────────────► │ routes/service.js    incidents, enquiries, metrics  │ SQL │ PostgreSQL  │
 AI impact ────────┘                 │ routes/workspace.js  agent workspace (/api/ws)      ├────►│ order_kci   │
                                     │ services/  orders, tasks, plans, cases, incidents,  │     └─────────────┘
                                     │            SLAs, KCIs, 10 AI agents, openaiClient   │     ┌─────────────┐
                                     │ SLA watcher (every 15 s)                            ├────►│ OpenAI      │
                                     └─────────────────────────────────────────────────────┘     │ Responses   │
                                                                                                 └─────────────┘
```
The AI never touches the database directly: it only sees what code gives it and can only use the tools code offers.

**Tech stack:** Node.js 24 (ES modules), Express 5, PostgreSQL 14+ with `pg`, the official `openai` SDK, `dotenv`.
Front end: plain HTML, CSS and JavaScript (no build step, no chart library: charts are plain HTML/CSS); fonts
(Inter, Bricolage Grotesque, JetBrains Mono) are served locally from `node_modules`, so the demo works offline.

**Folders**
```
server.js                    Express, static pages, local fonts, starts the SLA watcher
routes/                      orders.js (website + tracking), service.js (service desk), workspace.js (/api/ws)
services/                    business logic + the 10 agents + openaiClient.js
  orderService.js            order journey, plan, dependencies, task milestones, delays (reportDelay, cascade)
  kciService.js              every customer update: context → Writer → Reviewer → send or hold
  slaService.js              SLA timers and the watcher (at risk / breached)
  caseService.js             cases and service requests
  incidentService.js         incidents, incident tasks, major incidents
  workspaceService.js        lists, counts, landing page, record dossiers for the AI
db/schema.sql                base tables (npm run db:init drops and recreates everything)
db/migrations/002…010        additive changes, applied once each by db/migrate.js
public/                      index.html, track.html, workspace.html, dashboard.html, css/, js/, img/
scripts/                     smoke-test.mjs, ai-check.mjs, check-models.mjs
docs/screenshots/            README images
demo/  presentation/         demo video (or link) and solution deck
```

**Main tables:** `products`, `addons`, `price_rules`, `coverage_areas`, `orders`, `order_tasks` (plan, dependency,
customer impact), `slas`, `sla_definitions`, `kci_decisions`, `kci_communications` (every update with Reviewer verdict,
model, latency, tokens), `case_journal` (activity: `public` or `internal`), `cases`, `case_tasks`, `incidents`,
`incident_tasks`, `enquiries`.

---

## 5. Setup and run

### Prerequisites
- Node.js 24 or newer
- PostgreSQL 14 or newer, running locally
- An OpenAI API key (optional: without it the app runs in **demo mode**)

### Steps
```bash
# 1. Install dependencies
npm install

# 2. Settings
cp .env.example .env              # Windows cmd: copy .env.example .env
#    set DATABASE_URL (write @ in a password as %40) and, when you have it, OPENAI_API_KEY

# 3. Database (first time only)
createdb order_kci                # or create it in pgAdmin
npm run db:init                   # WARNING: drops and recreates all tables, then runs the migrations

# 4. Start
npm start                         # http://localhost:3000
```
Open `http://localhost:3000/workspace.html` and click **Reset demo data** (left menu, bottom) to load the demo set.
Updating an existing database without losing data: `npm run db:migrate`.

### Settings (`.env`)
| Variable | Meaning | Default |
|---|---|---|
| `PORT` | Web server port | 3000 |
| `DATABASE_URL` | `postgres://USER:PASSWORD@HOST:PORT/DATABASE` | — |
| `OPENAI_API_KEY` | OpenAI key; empty = demo mode | empty |
| `OPENAI_MODEL` | Model (or Azure deployment name) | `gpt-4.1-mini` |
| `OPENAI_BASE_URL` | Only for Azure OpenAI / compatible endpoints | — |
| `SLA_DEMO_SPEED` | SLA clock speed for demos: 120 = a 2-day SLA passes in 24 minutes; 1 = real time | 1 |
| `MANUAL_KCI_MINUTES` | Dashboard assumption: minutes to write one update by hand | 5 |
| `COST_PER_1K_TOKENS_GBP` | Optional: show AI cost (£) on the dashboard | — |
| `ALLOW_TEMPLATE_FALLBACK` | Let the Order Assistant use template replies as a safety net | false |

### Business rules (`config/business-rules.json`)
Business rules are configuration, not code: operations can change them without a developer. The file is
committed, so every laptop has the same rules; the server checks it at start-up and stops with a clear message
if a value is wrong. Edit, then restart. To change a rule on one laptop only, set its `.env` override (listed
in `.env.example`); the override wins over the file.

| Rule | Meaning | Default |
|---|---|---|
| `working_calendar.enabled` | On: plans follow the working days and hours. Off: every day is a working day (the time windows still apply) | on |
| `working_calendar.working_days` | Days deliveries, engineer visits and activations can happen | Mon–Sat |
| `working_calendar.working_hours` | Courier window and the end of a working day | 08:00–18:00 |
| `working_calendar.engineer_slots` | Engineer visit windows offered on each working day | 10:00–12:00, 14:00–16:00 |
| `working_calendar.activation_ready_by` | Activation is planned to be done by this time on the next working day | 12:00 |
| `delays.customer_reason` | Fallout 2: "Report delay" asks for a reason the customer may see | on |
| `delays.default_days` / `delays.auto_days` | Days pre-filled in the form / added when the system finds a late task by itself | 1 / 1 |
| `delays.reasons` | The reasons staff can pick, and the words the customer may be told | 6 reasons |
| `fallout.enabled` | Fallout 1: "Can't complete" on the engineer task (ticket, on hold, new dates, one update) | on |
| `fallout.fix_days` / `fallout.team` | Expected fix time pre-filled / team that gets the ticket | 2 / Network Operations |
| `fallout.pause_sla` | SLA clocks pause while the order is on hold for the fix | on |
| `sla.warn_at_percent` | Share of a task's SLA after which the AI decides whether to warn the customer early | 75 |
| `stage_agent.hold_below_speed_percent` | The Stage Agent holds the order if the measured speed is below this share of the plan | 80 |

SLA targets, prices, discounts and delivery days per area are business data: they stay in the database.

### When the OpenAI key arrives
```bash
# add OPENAI_API_KEY=... to .env, restart (npm start), then:
npm run check:models     # which models the key can use (change OPENAI_MODEL if needed)
npm run test:ai          # every agent once on the real model: PASS only if OpenAI answered AND a quality check holds
```
Then **Reset demo data** in the workspace: with a key, the demo updates are written by AI.

---

## 6. Demo script (5 minutes)

Demo data (after **Reset demo data**): James Carter (ORD-1001, Fallowfield, Manchester, M14 5RG) with equipment
delivered and the engineer booked; Charlotte Evans (5G, ready to activate); George Harris (TV); James's neighbours
at M14 5RG; Emily Clarke (ORD-1004) with delivery scheduled **and** the engineer booked; three service records.

Steps marked 🔑 need the OpenAI key (the chat agents do not pretend to answer without it).

1. **Website** `/` → check `M14 5RG` (fiber, 5G, TV) and `Belfast` (5G only). 🔑 Ask the **Plan Advisor**: "We are 4
   at home, I work from home, two floors" → plan + add-ons with a price from code. Place an order.
2. **Workspace** `/workspace.html` → the **AI briefing**; Ctrl+K → your new order → the plan (planned dates,
   dependencies) and the AI Order Agent's validation in the activity.
3. **Move to Fulfilment** → **Schedule delivery** → **Book engineer** → each milestone sends an AI-written, Reviewer-checked
   update (shown with its SMS).
4. **The key moment:** open **ORD-1004 (Emily)** → Equipment delivery → **Report delay** (2 days, "courier depot
   backlog") → the engineer visit moves automatically, the **AI decisions** tab shows why, and Emily gets one update
   with the new dates. Open her **tracking page**: "Expected ready by…", the moved visit, no internal reason.
5. **Reviewer:** More → **Raise incident** with *Reviewer test* ticked → the update is **held**; edit it → **Approve and send**.
6. **Service management:** **New case** → describe "charged twice and fed up" → **Triage with AI** → create; the
   customer is told the reference. Open **CS0001002** → close the refund task → **Resolve**.
7. **Major incident** at `M14 5RG` → five customers informed; add a task, mark it done → each customer told.
8. **Agent assist:** on any record, **AI summary**, **Copilot** ("why hasn't this moved?") and **Draft email → Write
   with AI → Check and send**.
9. 🔑 **Tracking page** `/track.html` → `ORD-1001` → chat: "can the engineer come in the afternoon?" → pick a slot →
   booked; "I want to add a SIM for my son, can a person help?" → a triaged Service Request is opened with a reference.

---

## 7. Testing

```bash
npm run test:smoke       # 29 end-to-end checks against the running server (resets the demo data)
npm run test:ai          # every AI agent once on the real model (needs the key); --allow-demo = dry run
npm run check:models     # which OpenAI models the key can use
```
The smoke test covers: catalogue, coverage, prices, the full order journey and its milestone updates, planning and
dependencies, a delivery delay that moves the engineer visit (one update, no internal reason leaked), incidents and
major incidents, cases and service requests with triage and tasks, internal-note privacy, workspace lists and counts,
AI summary, copilot, email drafting and the Reviewer holding a leaking email or reply. Without a key, the three
checks that need a real chat model are reported as skipped.

---

## 8. API reference

Website and tracking (`routes/orders.js`, prefix `/api`)
| Method | Path | Purpose |
|---|---|---|
| GET | `/catalog` | Plans, add-ons, price rules |
| POST | `/quote` | `{product_code, addon_codes}` → price calculated by code |
| GET | `/coverage?q=` · `/coverage/areas` | Coverage by postcode or place · all covered postcodes |
| POST | `/advisor/chat` | Plan Advisor |
| POST | `/orders` | Place an order (coverage and price checked by code) |
| GET | `/orders/find?number=` · `/orders/:id` | Find by order number · customer view (public data only) |
| POST | `/orders/:id/chat` · `/comments` · `/photo` | Order Assistant · message to the team · photo diagnosis |
| POST | `/enquiries` | Callback / notify-me request |

Agent workspace (`routes/workspace.js`, prefix `/api/ws`)
| Method | Path | Purpose |
|---|---|---|
| GET | `/nav` · `/home` · `/briefing` | Menu counts · landing page · AI briefing |
| GET | `/list/:kind?view=&q=&stage=` | Lists: `orders`, `cases`, `requests`, `incidents`, `tasks`, `enquiries` |
| GET/PATCH | `/orders/:id` | Order record (tasks, plan, SLAs, decisions, activity) · save details |
| POST | `/orders/:id/advance` · `/cancel` · `/close` · `/incidents` | Move to next stage · cancel · close · raise incident |
| POST | `/order-tasks/:id/action` | `schedule`, `deliver`, `complete`, `activate`, `approve`, **`delay`** `{days, reason}` |
| GET | `/slots?order_id=` | Engineer slots from the day after the equipment is due |
| POST/GET/PATCH | `/cases` · `/cases/:id` | New case (AI triage) · case record · save |
| POST | `/cases/:id/advance` · `/cancel` · `/tasks` · `/case-tasks/:id/state` | Case lifecycle and tasks |
| GET/POST | `/incidents/:id` · `/incidents/:id/start` · `/close` | Incident record and lifecycle |
| POST | `/records/:type/:id/summary` · `/copilot` · `/email/draft` · `/email/send` · `/reply` · `/note` | Agent assist (type = `order`, `case`, `incident`) |
| POST | `/triage` | AI Triage preview |

Service desk (`routes/service.js`, prefix `/api`): `/incidents/:id/tasks`, `/tasks/:id/state`, `/major-incidents`,
`/incidents/:id/resolve`, `/kcis/:id/approve`, `/metrics`, `/enquiries`, `/admin/reset-demo`.

---

## 9. Security, privacy and safety

- **Internal vs public**: every activity entry is `internal` or `public`; customer endpoints return public entries
  only (filtered in SQL) and only customer-safe task facts (never work notes, teams, staff or delay reasons).
- **Two checks on every customer message**: the AI Reviewer plus a rule check that always runs (incident numbers,
  phrases copied from internal notes). Held messages need a human.
- **Code owns facts**: prices, coverage, dates, revised ETAs, slots and tracking references never come from the AI.
- **No silent fake AI**: without a key, AI features are labelled "AI demo mode"; the customer chat says it is not
  connected unless `ALLOW_TEMPLATE_FALLBACK=true`.
- **Data**: all demo people are fictional; phone numbers use Ofcom's drama range (07700 900xxx). No real customer data.
- **Secrets**: `.env` is git-ignored; only `.env.example` is committed. Rotate any key that ever reached git history.
- **XSS**: every page escapes data with `esc()` before inserting HTML.

---

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| `password authentication failed` | Check user/password in `DATABASE_URL`; write `@` in a password as `%40` |
| Empty workspace | Click **Reset demo data** (left menu, bottom) |
| "AI demo mode · no key yet" | Add `OPENAI_API_KEY` to `.env` and restart |
| `404` model error in the server window | `OPENAI_MODEL` not available to your key: run `npm run check:models` |
| `429` | Rate limit or no credit on the account |
| SLAs breach very fast | `SLA_DEMO_SPEED` in `.env` (120 = 2 days in 24 minutes); set 1 for real time |
| Page shows an old layout | Hard refresh: Ctrl + F5 |
