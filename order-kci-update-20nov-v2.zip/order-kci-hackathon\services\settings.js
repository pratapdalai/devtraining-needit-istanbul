import fs from 'node:fs';

// Business rules: config/business-rules.json (committed, the same on every laptop), checked at start-up.
// Any rule can be overridden on one laptop in .env (names below). Restart the server after a change.

const FILE = new URL('../config/business-rules.json', import.meta.url);
const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const TIME = /^([01]\d|2[0-3]):[0-5]\d$/;

const env = (name) => String(process.env[name] ?? '').trim();
const envBool = (name, cur) => (env(name) === '' ? cur : ['on', 'true', 'yes', '1'].includes(env(name).toLowerCase()));
const envNum = (name, cur) => (env(name) === '' ? cur : Number(env(name)));
const envList = (name, cur) => (env(name) === '' ? cur : env(name).split(',').map((s) => s.trim()).filter(Boolean));
const envText = (name, cur) => env(name) || cur;
const minutes = (hhmm) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3));

function load() {
  let r;
  try { r = JSON.parse(fs.readFileSync(FILE, 'utf8')); }
  catch (err) { throw new Error(`config/business-rules.json could not be read: ${err.message}`); }
  const c = r.working_calendar ||= {}; const d = r.delays ||= {}; const f = r.fallout ||= {};
  const s = r.sla ||= {}; const g = r.stage_agent ||= {};
  d.auto_days ||= {};

  // .env overrides (one laptop only)
  c.enabled = envBool('WORKING_CALENDAR', c.enabled ?? true);
  c.working_days = envList('WORKING_DAYS', c.working_days);
  c.working_hours = envText('WORKING_HOURS', c.working_hours);
  c.engineer_slots = envList('ENGINEER_SLOTS', c.engineer_slots);
  d.customer_reason = envBool('DELAY_CUSTOMER_REASON', d.customer_reason ?? true);
  d.default_days = envNum('DELAY_DEFAULT_DAYS', d.default_days);
  d.auto_days.delivery = envNum('AUTO_DELAY_DAYS_DELIVERY', d.auto_days.delivery);
  d.auto_days.engineer = envNum('AUTO_DELAY_DAYS_ENGINEER', d.auto_days.engineer);
  d.auto_days.activation = envNum('AUTO_DELAY_DAYS_ACTIVATION', d.auto_days.activation);
  f.enabled = envBool('ENGINEER_FALLOUT', f.enabled ?? true);
  f.fix_days = envNum('FALLOUT_DEFAULT_FIX_DAYS', f.fix_days);
  f.team = envText('FALLOUT_TEAM', f.team);
  f.pause_sla = envBool('FALLOUT_PAUSE_SLA', f.pause_sla ?? true);
  s.warn_at_percent = envNum('SLA_WARN_AT_PERCENT', s.warn_at_percent);
  s.check_every_seconds = envNum('SLA_CHECK_EVERY_SECONDS', s.check_every_seconds);
  g.hold_below_speed_percent = envNum('STAGE_HOLD_BELOW_SPEED_PERCENT', g.hold_below_speed_percent);

  // Checks: a wrong value stops the server with a clear message, instead of odd dates later
  const bad = [];
  const need = (ok, msg) => { if (!ok) bad.push(msg); };
  const range = (v, lo, hi) => Number.isFinite(v) && v >= lo && v <= hi;
  const win = (w) => typeof w === 'string' && w.split('-').length === 2 && w.split('-').every((t) => TIME.test(t))
    && minutes(w.split('-')[0]) < minutes(w.split('-')[1]);
  need(Array.isArray(c.working_days) && c.working_days.length && c.working_days.every((x) => DAY_NAMES.includes(x)),
    'working_calendar.working_days: list of Mon, Tue, Wed, Thu, Fri, Sat, Sun (at least one)');
  need(win(c.working_hours), 'working_calendar.working_hours: "HH:MM-HH:MM", e.g. "08:00-18:00"');
  need(Array.isArray(c.engineer_slots) && c.engineer_slots.length && c.engineer_slots.every(win),
    'working_calendar.engineer_slots: list of "HH:MM-HH:MM", e.g. ["10:00-12:00", "14:00-16:00"]');
  need(TIME.test(c.activation_ready_by || ''), 'working_calendar.activation_ready_by: "HH:MM", e.g. "12:00"');
  need(range(c.slot_booking_days_ahead, 7, 365), 'working_calendar.slot_booking_days_ahead: 7 to 365');
  need(range(d.max_days, 1, 60), 'delays.max_days: 1 to 60');
  need(range(d.default_days, 1, d.max_days), 'delays.default_days: 1 to delays.max_days');
  for (const k of ['delivery', 'engineer', 'activation']) need(range(d.auto_days[k], 1, d.max_days), `delays.auto_days.${k}: 1 to delays.max_days`);
  need(Array.isArray(d.reasons) && d.reasons.length && d.reasons.every((x) => x.label), 'delays.reasons: list of { "label", "customer" }');
  need(range(f.fix_days, 1, 30), 'fallout.fix_days: 1 to 30');
  need(typeof f.team === 'string' && f.team.length > 0, 'fallout.team: a team name, e.g. "Network Operations"');
  need(['P1', 'P2', 'P3', 'P4'].includes(f.ticket_priority), 'fallout.ticket_priority: P1, P2, P3 or P4');
  need(Array.isArray(f.problems) && f.problems.length && f.problems.every((x) => x.label), 'fallout.problems: list of { "label", "customer" }');
  need(range(s.warn_at_percent, 10, 99), 'sla.warn_at_percent: 10 to 99');
  need(range(s.check_every_seconds, 5, 3600), 'sla.check_every_seconds: 5 to 3600');
  need(range(g.hold_below_speed_percent, 10, 100), 'stage_agent.hold_below_speed_percent: 10 to 100');
  need(range(g.demo_measured_speed_percent, 10, 100), 'stage_agent.demo_measured_speed_percent: 10 to 100');
  if (bad.length) throw new Error(`config/business-rules.json (or its .env override) has a wrong value:\n  - ${bad.join('\n  - ')}`);
  return r;
}

let cached = null;
// The rules, loaded once (the server reads them at start; restart after a change)
export const rules = () => (cached ||= load());

// Called by server.js at start-up: fails fast with a clear message, and prints the key rules
export function checkRules() {
  const r = rules(); const c = r.working_calendar;
  return `Business rules: ${c.enabled ? `working days ${c.working_days.join(' ')}, ${c.working_hours}` : 'working calendar OFF (7 days a week)'}` +
    ` | fallout ${r.fallout.enabled ? 'on' : 'off'} | SLA warning at ${r.sla.warn_at_percent}%`;
}

// Short names used by the services (kept so the callers stay simple)
export const settings = {
  get delayCustomerReason() { return rules().delays.customer_reason; },
  get delayDefaultDays() { return Math.round(rules().delays.default_days); },
  get delayMaxDays() { return Math.round(rules().delays.max_days); },
  get autoDelayDays() {
    const a = rules().delays.auto_days;
    return { CPE_DELIVERY: Math.round(a.delivery), ENGINEER_VISIT: Math.round(a.engineer), ACTIVATION: Math.round(a.activation) };
  },
  get engineerFallout() { return rules().fallout.enabled; },
  get falloutFixDays() { return Math.round(rules().fallout.fix_days); },
  get falloutTeam() { return rules().fallout.team; },
  get falloutPriority() { return rules().fallout.ticket_priority; },
  get falloutPauseSla() { return rules().fallout.pause_sla; },
  get slaWarnAt() { return rules().sla.warn_at_percent / 100; },
  get slaCheckMs() { return Math.round(rules().sla.check_every_seconds * 1000); },
  get holdBelowSpeed() { return rules().stage_agent.hold_below_speed_percent / 100; },
  get demoSpeedShare() { return rules().stage_agent.demo_measured_speed_percent / 100; },
};

// The customer-safe reason for a delay: a listed reason, or the text staff typed for "Other". null = no reason given.
export function customerReason(label, text) {
  if (!settings.delayCustomerReason) return null;
  const typed = String(text || '').trim().slice(0, 200);
  const r = rules().delays.reasons.find((x) => x.label === label);
  if (r?.customer) return typed ? `${r.customer} (${typed})` : r.customer;
  return typed || null;
}

// The customer-safe words for an engineer fallout (always given: the customer must know why the visit stopped)
export function falloutReason(problem, text) {
  const typed = String(text || '').trim().slice(0, 200);
  const p = rules().fallout.problems.find((x) => x.label === problem);
  if (p?.customer) return typed ? `${p.customer} (${typed})` : p.customer;
  return typed || 'we found a problem we need to fix before we can finish connecting you';
}

// What the workspace forms need
export const formSettings = () => {
  const r = rules();
  return {
    delay_customer_reason: r.delays.customer_reason,
    delay_default_days: settings.delayDefaultDays,
    delay_reasons: r.delays.reasons.map((x) => x.label),
    engineer_fallout: r.fallout.enabled,
    fallout_fix_days: settings.falloutFixDays,
    fallout_team: r.fallout.team,
    fallout_problems: r.fallout.problems.map((x) => x.label),
    calendar_enabled: r.working_calendar.enabled,
    working_days: r.working_calendar.working_days,
  };
};
