import { query } from '../db/index.js';
import { settings } from './settings.js';

// SLA = a time promise on a record (e.g. "equipment delivered within 2 days").
// Demo mode: SLA_DEMO_SPEED=120 in .env makes time run 120x faster (2 days pass in 24 minutes).
// Targets and "time left" are always SHOWN in promise time, so the screens look real.
const SPEED = Math.max(1, Number(process.env.SLA_DEMO_SPEED || 1));
// proactive customer update when this share of the time is used (sla.warn_at_percent in config/business-rules.json)
const warnAt = () => settings.slaWarnAt;

// Start an SLA timer on a record, using a definition from sla_definitions
export async function startSla(recordType, recordId, code, orderId = null) {
  const def = (await query(`SELECT * FROM sla_definitions WHERE code = $1`, [code])).rows[0];
  if (!def) return null;
  return (await query(
    `INSERT INTO slas (definition_code, name, record_type, record_id, order_id, target_minutes, due_at)
     VALUES ($1, $2, $3, $4, $5, $6, now() + make_interval(secs => $7)) RETURNING *`,
    [def.code, def.name, recordType, recordId, orderId, def.target_minutes, (def.target_minutes * 60) / SPEED]
  )).rows[0];
}

// Stop every running SLA on a record: Completed (work done) or Cancelled (work no longer needed)
export async function stopSla(recordType, recordId, state = 'Completed') {
  await query(
    `UPDATE slas SET state = $3, stopped_at = now() WHERE record_type = $1 AND record_id = $2 AND state = 'In Progress'`,
    [recordType, recordId, state]
  );
}

// Pause every running SLA on a record (e.g. the order is on hold for a network fix): it cannot breach while paused
export async function pauseSla(recordType, recordId) {
  await query(
    `UPDATE slas SET paused_at = now() WHERE record_type = $1 AND record_id = $2 AND state = 'In Progress' AND paused_at IS NULL`,
    [recordType, recordId]
  );
}

// Resume: the time spent paused is added to the due time, so the clock continues where it stopped
export async function resumeSla(recordType, recordId) {
  await query(
    `UPDATE slas SET due_at = due_at + (now() - paused_at), paused_at = NULL
      WHERE record_type = $1 AND record_id = $2 AND state = 'In Progress' AND paused_at IS NOT NULL`,
    [recordType, recordId]
  );
}

// "2d 4h", "35m" - a duration written in promise time
function human(ms) {
  const min = Math.max(0, Math.round((ms * SPEED) / 60000));
  if (min >= 1440) return `${Math.floor(min / 1440)}d ${Math.floor((min % 1440) / 60)}h`;
  if (min >= 60) return `${Math.floor(min / 60)}h ${min % 60}m`;
  return `${min}m`;
}

// What the screens show for one SLA: % used, time left, and a health colour
export function slaView(s) {
  const start = new Date(s.started_at).getTime();
  const due = new Date(s.due_at).getTime();
  const paused = s.state === 'In Progress' && !!s.paused_at;
  const end = s.stopped_at ? new Date(s.stopped_at).getTime() : paused ? new Date(s.paused_at).getTime() : Date.now();
  const pct = Math.round((100 * (end - start)) / Math.max(1, due - start));
  const breached = s.breached || (s.state === 'In Progress' && end > due);
  const health = breached ? 'breached' : s.state !== 'In Progress' ? 'met' : paused ? 'paused' : pct >= warnAt() * 100 ? 'at_risk' : 'on_track';
  return {
    id: s.id, name: s.name, record_type: s.record_type, record_id: s.record_id, state: s.state,
    target: human((s.target_minutes * 60000) / SPEED), started_at: s.started_at, due_at: s.due_at, stopped_at: s.stopped_at,
    pct_used: Math.min(pct, 999), breached, health, paused,
    time_left: s.state === 'In Progress' ? (breached ? `${human(end - due)} over` : `${human(due - end)} left${paused ? ' (paused)' : ''}`) : null,
    took: s.state !== 'In Progress' ? human(end - start) : null,
  };
}

export async function slasFor(recordType, recordId) {
  return (await query(`SELECT * FROM slas WHERE record_type = $1 AND record_id = $2 ORDER BY id`, [recordType, recordId]))
    .rows.map(slaView);
}

// ---------------- SLA watcher (runs every 15 s) ----------------
// The KCI Agent "monitors the SLA around every task" (Ankit's design):
//   completed on the happy path -> the milestone update is sent by the task itself (orderService)
//   AT RISK (75% of the SLA used) -> the AI KCI Decision Agent decides: proactive update now, or wait
//   DELAYED (SLA breached)       -> code calculates a revised ETA, moves dependent tasks, and a delay update is sent
// Only tasks with customer impact are considered.
// revised-ETA rule per task type (working days): AUTO_DELAY_DAYS_* in .env (settings.js)

async function checkSlas() {
  const { logEvent } = await import('./journalService.js');
  const { sendKci } = await import('./kciService.js');
  const { decide, linkKci } = await import('./kciDecisionAgent.js');
  const { reportDelay } = await import('./orderService.js');

  const breached = (await query(
    `UPDATE slas SET breached = true
      WHERE state = 'In Progress' AND NOT breached AND paused_at IS NULL AND due_at < now() RETURNING *`
  )).rows;
  for (const s of breached) {
    if (s.order_id) await logEvent({ orderId: s.order_id }, `SLA breached: ${s.name}`);
    if (s.record_type !== 'order_task') continue;
    const t = (await query(
      `SELECT t.*, o.status AS order_status FROM order_tasks t JOIN orders o ON o.id = t.order_id WHERE t.id = $1`, [s.record_id]
    )).rows[0];
    if (!t || !t.customer_impact || t.order_status !== 'In Progress' || !['Open', 'In Progress'].includes(t.state)) continue;
    // A delay was already reported and the customer has a new date that has not passed: no second delay update
    if (t.delayed_at && t.planned_end && new Date(t.planned_end) > new Date()) {
      await logEvent({ orderId: s.order_id }, `${t.name}: the customer already has the revised date (${t.planned_end.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}), so no second delay update.`);
      continue;
    }
    try {
      await reportDelay(t.id, { days: settings.autoDelayDays[t.task_type] || 1, reason: `SLA breached: ${s.name}`, trigger: 'sla_watcher', by: 'SLA watcher' });
      console.log(`SLA breached on ${t.task_number}: revised ETA calculated and delay update sent`);
    } catch (err) { console.error(`Delay handling failed for ${t.task_number}:`, err.message); }
  }

  const atRisk = (await query(
    `SELECT s.*, t.id AS task_id
       FROM slas s
       JOIN order_tasks t ON s.record_type = 'order_task' AND t.id = s.record_id
       JOIN orders o      ON o.id = t.order_id
      WHERE s.state = 'In Progress' AND s.warned_at IS NULL AND NOT s.breached AND s.paused_at IS NULL
        AND now() >= s.started_at + (s.due_at - s.started_at) * $1
        AND t.customer_impact AND o.status = 'In Progress'`, [warnAt()]
  )).rows;
  for (const r of atRisk) {
    // mark first, so a slow AI call never decides twice for the same SLA
    await query(`UPDATE slas SET warned_at = now() WHERE id = $1`, [r.id]);
    const task = (await query(`SELECT * FROM order_tasks WHERE id = $1`, [r.task_id])).rows[0];
    const order = (await query(
      `SELECT o.*, p.name AS product_name FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = $1`, [task.order_id]
    )).rows[0];
    const d = await decide({ situation: 'AT_RISK', trigger: 'sla_watcher', order, task: { ...task, sla_pct_used: slaView(r).pct_used } });
    await logEvent({ orderId: order.id }, `${task.name} is at ${slaView(r).pct_used}% of its SLA. Decided: ${d.action}${d.update_type ? ` (${d.update_type})` : ''}. ${d.reason}`, 'AI KCI Decision Agent');
    if (d.action !== 'SEND_UPDATE') continue;
    const kci = await sendKci({ orderId: order.id }, 'JEOPARDY', { orderTask: task, trigger: 'proactive', decision: d });
    await linkKci(d.id, kci.id);
    console.log(`Proactive KCI sent for order ${order.id} (${task.name} at ${warnAt() * 100}% of its SLA)`);
  }
}

export function startSlaWatcher() {
  console.log(`SLA watcher on (demo speed x${SPEED}): AI decision at ${warnAt() * 100}% of a task SLA, revised ETA + delay update on breach`);
  setInterval(() => checkSlas().catch((err) => console.error('SLA check failed:', err.message)), settings.slaCheckMs);
}
