/* =====================================================================
   Auto KCI – agent workspace (landing console, left menu, lists, search, dialogs)
   Routes (hash):  #/home   #/list/<kind>/<view>   #/order/<id>   #/case/<id>   #/incident/<id>
   All data is escaped with esc() before it goes into HTML.
   ===================================================================== */
(() => {
  'use strict';

  // ---------------- helpers ----------------
  const AGENT = { name: 'Pratap Dalai', first: 'Pratap', initials: 'PD' };
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  async function api(url, body, method) {
    const res = await fetch(url, body !== undefined ? { method: method || 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
    return data;
  }
  function toast(text, bad = false) {
    const t = $('toast'); t.textContent = text; t.className = 'toast show' + (bad ? ' bad' : '');
    clearTimeout(toast.t); toast.t = setTimeout(() => (t.className = 'toast'), 4200);
  }
  const initials = (name) => String(name || '?').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  const colour = (name) => 'c' + ([...String(name || '')].reduce((a, c) => a + c.charCodeAt(0), 0) % 6);
  const avatar = (name, size = 30) => `<span class="av ${colour(name)}" style="width:${size}px;height:${size}px;font-size:${size < 32 ? 11.5 : 13}px">${esc(initials(name))}</span>`;
  function ago(ts) {
    if (!ts) return '';
    const s = Math.max(0, (Date.now() - new Date(ts)) / 1000);
    if (s < 60) return 'just now';
    if (s < 3600) return `${Math.floor(s / 60)}m ago`;
    if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
    return `${Math.floor(s / 86400)}d ago`;
  }
  const day = (ts) => new Date(ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  const money = (n) => '£' + Number(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  const SPARK = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.2 6.3L20.5 10l-6.3 2.2L12 18.5l-2.2-6.3L3.5 10l6.3-1.7z"/></svg>';
  const ICON = {
    order: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/></svg>',
    case: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>',
    request: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16v12H8l-4 4z"/></svg>',
    incident: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l10 18H2z"/><path d="M12 10v4M12 17.5v.5"/></svg>',
    clock: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="#FFB4A6" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    shield: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="#D9D1FF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>',
    arrow: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 11a8 8 0 10-2.3 5.7M20 4v7h-7"/></svg>',
    search: '<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>',
    inbox: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 13l3-8h12l3 8v6H3z"/><path d="M3 13h5l1 2h6l1-2h5"/></svg>',
  };

  // Customer-update events in plain words
  const EVENT = {
    CPE_DELIVERY_SCHEDULED: 'Delivery scheduled', CPE_DELIVERED: 'Equipment delivered', ENGINEER_APPOINTMENT_SCHEDULED: 'Engineer booked',
    VISIT_RESCHEDULED: 'Visit moved', ENGINEER_FALLOUT: 'Visit on hold + new dates', FALLOUT_CLEARED: 'Fix done, visit confirmed',ENGINEER_VISIT_COMPLETED: 'Visit completed', SERVICE_ACTIVATED: 'Service activated',
    ORDER_COMPLETED: 'Order completed', JEOPARDY: 'Proactive update (at risk)', TASK_DELAYED: 'Delay + new date', INCIDENT_RAISED: 'Delay notice', INCIDENT_RESOLVED: 'Issue resolved',
    TASK_COMPLETED: 'Fix progress', CASE_OPENED: 'Case opened', CASE_TASK_COMPLETED: 'Case progress', CASE_RESOLVED: 'Resolved',
  };
  const eventName = (e) => EVENT[e] || String(e || 'Update').replace(/_/g, ' ').toLowerCase();

  const statePill = (s) => {
    const cls = { New: 'warn', Open: 'blue', 'In Progress': 'blue', Resolved: 'ok', Closed: 'grey', Cancelled: 'grey', Completed: 'ok', 'On Hold': 'bad', Done: 'ok', Pending: 'grey' }[s] || 'grey';
    return `<span class="pill ${cls}">${esc(s)}</span>`;
  };
  const stagePill = (stage, status) => status === 'On Hold' ? '<span class="pill bad">On hold</span>'
    : `<span class="pill ${{ Validation: 'grey', Fulfilment: 'blue', Activation: 'ai', Completed: 'ok' }[stage] || 'grey'}">${esc(stage)}</span>`;
  const priPill = (p) => `<span class="pill ${{ P1: 'bad', P2: 'warn', P3: 'blue', P4: 'grey' }[p] || 'grey'}">${esc(p)}</span>`;
  function slaCell(s) {
    if (!s) return '<span class="muted">—</span>';
    const w = Math.min(100, s.pct_used);
    const label = s.time_left || (s.breached ? 'Breached' : s.state === 'Completed' ? 'Met' : s.state);
    return `<div class="sla ${esc(s.health)}"><div class="bar"><i class="g-${esc(s.health)}" style="width:${s.state === 'In Progress' ? w : 100}%"></i></div><small>${esc(label)}</small></div>`;
  }
  const lastUpdate = (u) => !u ? '<span class="muted">No update yet</span>'
    : `${u.status === 'Held' ? '<span class="pill bad" style="margin-right:4px">Held</span>' : '<span class="ai-tag">AI</span> '}${esc(eventName(u.event))} · <span class="muted">${esc(ago(u.created_at))}</span>`;

  // ---------------- state ----------------
  let NAV = null; let HEALTH = null; let route = { name: 'home' }; let refreshing = false;
  const listState = {};              // search text and stage filter per list
  let OPTIONS = null;                // case form options

  // ---------------- menu counts ----------------
  const get = (obj, path) => path.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
  async function loadNav() {
    try { NAV = await api('/api/ws/nav'); } catch { return; }
    NAV.incidents.done = NAV.incidents.resolved + NAV.incidents.closed;
    document.querySelectorAll('[data-count]').forEach((el) => {
      const v = get(NAV, el.dataset.count);
      el.textContent = v ? v : '';
    });
    $('bellDot').hidden = !(NAV.cases.new + NAV.requests.new + NAV.held_updates);
  }
  function markNav() {
    const h = location.hash || '#/home';
    document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('on', a.getAttribute('href') === h));
  }
  async function loadHealth() {
    try { HEALTH = await api('/api/health'); } catch { HEALTH = null; }
    const el = $('aiStatus');
    if (HEALTH?.ai === 'openai') { el.className = 'ai-status'; el.innerHTML = `<i></i>OpenAI connected · ${esc(HEALTH.model)}`; }
    else { el.className = 'ai-status off'; el.innerHTML = '<i></i>AI demo mode · no key yet'; el.title = 'Add OPENAI_API_KEY to .env to switch on the real AI'; }
  }

  // ---------------- router ----------------
  function parse() {
    const parts = (location.hash || '#/home').slice(2).split('/');
    if (parts[0] === 'list' && LISTS[parts[1]]) return { name: 'list', kind: parts[1], view: LISTS[parts[1]].views.some((v) => v[0] === parts[2]) ? parts[2] : LISTS[parts[1]].views[0][0] };
    if (['order', 'case', 'incident'].includes(parts[0]) && Number(parts[1])) return { name: 'record', type: parts[0], id: Number(parts[1]) };
    if (parts[0] === 'impact') return { name: 'impact' };
    return { name: 'home' };
  }
  async function render(quiet = false) {
    route = parse(); markNav();
    const page = $('page');
    if (!quiet) { page.innerHTML = ''; window.scrollTo({ top: 0 }); }
    try {
      if (route.name === 'home') await renderHome(page, quiet);
      else if (route.name === 'list') await renderList(page, route.kind, route.view, quiet);
      else if (route.name === 'impact') await renderImpact(page, quiet);
      else await renderRecord(page, route.type, route.id);
    } catch (e) {
      if (!quiet) page.innerHTML = `<div class="card empty">${ICON.inbox}<b>Could not load this page</b>${esc(e.message)}</div>`;
    }
  }
  const go = (hash) => { if (location.hash === hash) render(); else location.hash = hash; };
  const recordHash = (type, id) => `#/${type}/${id}`;

  // =====================================================================
  // HOME (landing console)
  // =====================================================================
  function greeting() {
    const h = new Date().getHours();
    return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  }
  async function renderHome(page, quiet) {
    if (!quiet) {
      page.innerHTML = `<section class="view">
        <div class="hello">
          <div><h1>${greeting()}, ${esc(AGENT.first)}</h1><p>${esc(new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' }))} · Here's what needs you today.</p></div>
          <div class="acts"><button class="btn" type="button" data-act="new-case">${ICON.plus}New case</button><button class="btn" type="button" data-act="major">${ICON.plus}Raise major incident</button><a class="btn primary" href="#/list/orders/open">Go to open orders</a></div>
        </div>
        <div class="brief" id="brief"><div class="brief-h"><h2>${SPARK}Your AI briefing</h2></div>
          <ul>${'<li><span class="skel" style="height:20px;flex:1"></span></li>'.repeat(3)}</ul></div>
        <div id="homeBody"><div class="modules"><div class="card skel" style="height:260px"></div><div class="card skel" style="height:260px"></div></div></div>
      </section>`;
      loadBriefing(false);
    }
    const h = await api('/api/ws/home');
    $('homeBody').innerHTML = homeBody(h);
  }

  async function loadBriefing(refresh) {
    const box = $('brief'); if (!box) return;
    try {
      const b = await api(`/api/ws/briefing${refresh ? '?refresh=1' : ''}`);
      const items = b.items.map((i) => `<li><span class="ic">${i.record_type === 'incident' ? ICON.clock : i.record_type === 'case' ? ICON.shield : ICON.clock}</span>
        <span>${esc(i.text)}</span><a href="${recordHash(i.record_type, i.record_id)}">${esc(i.action || 'Open')}</a></li>`).join('');
      const by = b.ai_source === 'openai' ? `Written by OpenAI (${esc(b.model)}) from live order, SLA and case data`
        : 'AI demo mode: picked by rules from live order, SLA and case data (add the OpenAI key for AI-written briefings)';
      box.innerHTML = `<div class="brief-h"><h2>${SPARK}Your AI briefing</h2><button class="refresh" type="button" id="briefRefresh">${ICON.refresh}Refresh</button></div>
        ${items ? `<ul>${items}</ul>` : '<p class="calm">Nothing urgent right now: every SLA is on track and no customer update is waiting for approval.</p>'}
        <div class="meta">${by} · ${esc(ago(b.generated_at))}</div>`;
      $('briefRefresh').onclick = () => { box.querySelector('ul, .calm')?.replaceWith(Object.assign(document.createElement('ul'), { innerHTML: '<li><span class="skel" style="height:20px;flex:1"></span></li>'.repeat(3) })); loadBriefing(true); };
    } catch (e) {
      box.innerHTML = `<div class="brief-h"><h2>${SPARK}Your AI briefing</h2></div><p class="calm">The briefing could not load: ${esc(e.message)}</p>`;
    }
  }

  function bar(parts) {
    const total = parts.reduce((a, p) => a + p.n, 0) || 1;
    return `<div class="stagebar">${parts.filter((p) => p.n).map((p) => `<i style="flex:${p.n};background:${p.c}"></i>`).join('')}</div>
      <div class="legend">${parts.map((p) => `<span><i style="background:${p.c}"></i>${esc(p.label)} ${p.n}</span>`).join('')}</div>`;
  }
  function donut(h) {
    const total = h.on_track + h.at_risk + h.breached;
    const pct = (n) => (total ? (100 * n) / total : 0);
    const seg = (n, colour, offset) => n ? `<circle cx="21" cy="21" r="15.9" fill="none" stroke="${colour}" stroke-width="5" pathLength="100" stroke-dasharray="${pct(n)} ${100 - pct(n)}" stroke-dashoffset="${-offset}" transform="rotate(-90 21 21)"/>` : '';
    return `<svg viewBox="0 0 42 42" role="img" aria-label="SLA health"><circle cx="21" cy="21" r="15.9" fill="none" stroke="#EEF1F6" stroke-width="5"/>
      ${seg(h.on_track, '#12804A', 0)}${seg(h.at_risk, '#E39200', pct(h.on_track))}${seg(h.breached, '#C2352B', pct(h.on_track) + pct(h.at_risk))}
      <text x="21" y="23.5" text-anchor="middle" font-family="Bricolage Grotesque Variable, sans-serif" font-size="8" font-weight="700" fill="#0B1736">${total ? Math.round(pct(h.on_track)) : 100}%</text></svg>`;
  }
  function homeBody(h) {
    const st = Object.fromEntries(h.orders.stages.map((s) => [s.stage, s.n]));
    const feed = h.feed.map((k) => `<li data-href="${k.order_id ? recordHash('order', k.order_id) : recordHash('case', k.case_id)}">${avatar(k.customer_name, 34)}
        <span class="t"><b>${esc(eventName(k.event))}</b><span>${esc(k.customer_name)} · ${esc(k.reference)} · ${esc(ago(k.created_at))}</span></span>
        ${k.status === 'Held' ? '<span class="pill bad">Held</span>' : k.review_verdict === 'FIXED' ? '<span class="pill ai">Fixed by Reviewer</span>' : '<span class="pill ok">Sent</span>'}</li>`).join('');
    return `<div class="modules">
        <a class="card module" href="#/list/orders/open">
          <div class="head"><span class="ico" style="background:var(--brand-soft);color:var(--brand)">${ICON.order}</span>
            <div><h3>Order management</h3><p>Order capture, AI validation, fulfilment tasks and an AI-written update at every milestone.</p></div></div>
          <div class="kpis"><div class="kpi"><b>${h.orders.open}</b><span>Open orders</span></div>
            <div class="kpi ${h.orders.at_risk ? 'bad' : ''}"><b>${h.orders.at_risk}</b><span>SLA at risk</span></div>
            <div class="kpi ai"><b>${h.updates_today.n}</b><span>Customer updates today</span></div></div>
          <div>${bar([{ label: 'Validation', n: st.Validation || 0, c: '#9DB8F2' }, { label: 'Fulfilment', n: st.Fulfilment || 0, c: 'var(--brand)' }, { label: 'Activation', n: st.Activation || 0, c: 'var(--ai)' }])}</div>
          <div class="go">Open order management ${ICON.arrow}</div>
        </a>
        <a class="card module" href="#/list/cases/new">
          <div class="head"><span class="ico" style="background:var(--ai-soft);color:var(--ai)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/><path d="M9 12l2 2 4-4"/></svg></span>
            <div><h3>Service management</h3><p>Cases, service requests and incidents, triaged by AI, with AI-written customer updates and SLAs.</p></div></div>
          <div class="kpis"><div class="kpi ${h.service.new_cases ? 'bad' : ''}"><b>${h.service.new_cases}</b><span>New cases</span></div>
            <div class="kpi"><b>${h.service.requests}</b><span>Service requests</span></div>
            <div class="kpi ${h.service.major_incidents ? 'bad' : ''}"><b>${h.service.major_incidents}</b><span>Major incidents</span></div></div>
          <div>${bar([{ label: 'New', n: h.service.new_cases, c: '#F0A33A' }, { label: 'Open', n: h.service.open_cases, c: 'var(--brand)' }, { label: 'Resolved', n: h.service.resolved_cases, c: 'var(--ok)' }])}</div>
          <div class="go">Open service management ${ICON.arrow}</div>
        </a>
      </div>
      <div class="row2">
        <section class="card"><div class="card-h"><h3>Latest customer updates</h3><span class="ai-tag">${SPARK}Writer → Reviewer</span></div>
          ${feed ? `<ul class="feed">${feed}</ul>` : `<div class="empty">${ICON.inbox}<b>No updates yet</b>They appear here as orders and cases move.</div>`}</section>
        <section class="card"><div class="card-h"><h3>SLA health</h3><span class="pill grey">All running SLAs</span></div>
          <div class="health"><div class="donut">${donut(h.sla_health)}
            <ul><li><i style="background:var(--ok)"></i>On track<b>${h.sla_health.on_track}</b></li><li><i style="background:#E39200"></i>At risk<b>${h.sla_health.at_risk}</b></li><li><i style="background:var(--bad)"></i>Breached<b>${h.sla_health.breached}</b></li></ul>
          </div></div></section>
      </div>`;
  }

  // =====================================================================
  // LISTS
  // =====================================================================
  const LISTS = {
    orders: {
      label: 'orders', area: 'Order management', type: 'order',
      views: [['open', 'Open orders', 'orders.open'], ['completed', 'Completed orders', 'orders.completed'], ['closed', 'Closed orders', 'orders.closed'], ['cancelled', 'Cancelled orders', 'orders.cancelled']],
      head: ['Order', 'Customer', 'Plan', 'Stage', 'Current task', 'SLA', 'Last customer update'],
      row: (r) => `<td class="mono num">${esc(r.order_number)}</td>
        <td><div class="who">${avatar(r.customer_name)}<div><b>${esc(r.customer_name)}</b><span>${esc(r.pincode || '')}${r.city ? ' · ' + esc(r.city) : ''}</span></div></div></td>
        <td>${esc(r.product_name)}${(r.addons || []).length ? `<span class="sub2">+ ${esc(r.addons.map((a) => a.name.replace(/^(Speed upgrade to|Mesh Wi-Fi)\s*/, (m) => m.startsWith('Speed') ? 'Speed ' : 'Mesh ')).join(', '))}</span>` : ''}</td>
        <td>${stagePill(r.current_stage, r.status)}${r.open_incident ? `<span class="sub2">${esc(r.open_incident)}</span>` : ''}</td>
        <td>${r.current_task ? esc(r.current_task) : r.ready_to_move ? `<span class="ready">Ready for ${esc(r.ready_to_move)}</span>` : '<span class="muted">—</span>'}${r.needs_attention ? '<span class="sub2" style="color:var(--warn)">Needs attention</span>' : ''}</td>
        <td>${slaCell(r.sla)}</td><td class="last">${lastUpdate(r.last_update)}</td>`,
      stageChips: true,
    },
    cases: {
      label: 'cases', area: 'Service management · Cases', type: 'case',
      views: [['new', 'New cases', 'cases.new'], ['open', 'Open cases', 'cases.open'], ['resolved', 'Resolved cases', 'cases.resolved'], ['closed', 'Closed cases', 'cases.closed'], ['cancelled', 'Cancelled cases', 'cases.cancelled']],
      head: ['Case', 'Customer', 'Title', 'Priority', 'State', 'Team', 'SLA', 'Last update'],
      row: (r) => caseRow(r),
    },
    requests: {
      label: 'service requests', area: 'Service management · Service requests', type: 'case',
      views: [['new', 'New service requests', 'requests.new'], ['open', 'Open service requests', 'requests.open'], ['resolved', 'Resolved service requests', 'requests.resolved'], ['closed', 'Closed service requests', 'requests.closed']],
      head: ['Request', 'Customer', 'Title', 'Priority', 'State', 'Team', 'SLA', 'Last update'],
      row: (r) => caseRow(r),
    },
    incidents: {
      label: 'incidents', area: 'Service management · Incidents', type: 'incident', major: true,
      views: [['new', 'New incidents', 'incidents.new'], ['open', 'Open incidents', 'incidents.open'], ['closed', 'Resolved and closed incidents', 'incidents.done']],
      head: ['Incident', 'Description', 'Affects', 'Priority', 'State', 'Team', 'Open tasks', 'SLA'],
      row: (r) => `<td class="mono num">${esc(r.incident_number)}${r.is_major ? ' <span class="tag">MAJOR</span>' : ''}</td>
        <td style="max-width:320px">${esc(r.description)}${r.parent_number ? `<span class="sub2">Part of ${esc(r.parent_number)}</span>` : ''}</td>
        <td>${r.is_major ? `<b>${r.affected}</b> customers<span class="sub2">${esc(r.pincode)}</span>` : `<div class="who">${avatar(r.customer_name)}<div><b>${esc(r.customer_name || '—')}</b><span>${esc(r.order_number || '')}</span></div></div>`}</td>
        <td>${priPill(r.priority)}</td><td>${statePill(r.state)}</td><td>${esc(r.assignment_group || '—')}</td>
        <td>${r.open_tasks || '<span class="muted">0</span>'}</td><td>${slaCell(r.sla)}</td>`,
    },
    tasks: {
      label: 'tasks', area: 'Service management · Tasks', type: null,
      views: [['open', 'Open tasks', 'tasks.open'], ['closed', 'Closed tasks', 'tasks.closed']],
      head: ['Task', 'What', 'Type', 'For', 'Team', 'State', 'SLA'],
      row: (r) => `<td class="mono num">${esc(r.number)}</td><td style="max-width:320px">${esc(r.name)}${r.milestone ? `<span class="sub2">${esc(r.milestone)}</span>` : ''}</td>
        <td>${{ order_task: '<span class="pill blue">Order task</span>', case_task: '<span class="pill ai">Case task</span>', incident_task: '<span class="pill bad">Incident task</span>' }[r.kind]}</td>
        <td><span class="mono">${esc(r.parent_number)}</span><span class="sub2">${esc(r.customer_name || '')}</span></td>
        <td>${esc(r.team)}${r.assigned_to ? `<span class="sub2">${esc(r.assigned_to)}</span>` : ''}</td><td>${statePill(r.state)}</td><td>${slaCell(r.sla)}</td>`,
    },
  };
  // Website enquiries (callback and "notify me") are worked straight from the list
  LISTS.enquiries = {
    label: 'enquiries', area: 'Service management · Website enquiries', type: null,
    views: [['new', 'New enquiries', 'enquiries.new'], ['contacted', 'Contacted enquiries', 'enquiries.contacted'], ['closed', 'Closed enquiries', 'enquiries.closed']],
    head: ['Enquiry', 'Who', 'Asked for', 'Message', 'Coverage at the postcode', 'Received', ''],
    row: (r) => {
      const cov = r.area ? ['broadband', 'mobile', 'tv'].map((k) => `<span class="pill ${r[k] ? 'ok' : 'grey'}">${{ broadband: 'Fiber', mobile: '5G', tv: 'TV' }[k]}</span>`).join(' ')
        + (r.coming_soon ? `<span class="sub2">${esc(r.coming_soon)}</span>` : '') : '<span class="muted">Not in our coverage list</span>';
      const next = r.status === 'New' ? `<button class="btn sm primary" type="button" data-enq="${r.id}:Contacted">Mark contacted</button>` : '';
      const close = r.status !== 'Closed' ? `<button class="btn sm" type="button" data-enq="${r.id}:Closed">Close</button>` : '';
      return `<td class="mono num">${esc(r.enquiry_number)}</td>
        <td><div class="who">${avatar(r.name)}<div><b>${esc(r.name)}</b><span>${esc(r.phone)}</span></div></div></td>
        <td>${{ notify: '<span class="pill warn">Notify me</span>', callback: '<span class="pill blue">Callback</span>', advisor: '<span class="pill ai">From AI advisor</span>' }[r.source] || esc(r.source)}<span class="sub2">${esc(r.interest || 'not sure')}</span></td>
        <td style="max-width:280px">${esc(r.message || '—')}</td>
        <td><span class="mono">${esc(r.pincode || '—')}</span>${r.area ? ` · ${esc(r.area)}, ${esc(r.city)}` : ''}<div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:4px">${cov}</div></td>
        <td>${esc(ago(r.created_at))}</td><td><div class="acts">${next}${close}</div></td>`;
    },
  };

  function caseRow(r) {
    return `<td class="mono num">${esc(r.case_number)}</td>
      <td><div class="who">${avatar(r.customer_name)}<div><b>${esc(r.customer_name)}</b><span>${esc(r.order_number || 'No order')}</span></div></div></td>
      <td style="max-width:300px">${esc(r.short_description)}<span class="sub2">${esc(r.category)}${r.origin === 'Order Assistant' ? ' · <span class="ai-tag">AI</span> from Order Assistant' : ''}</span></td>
      <td>${priPill(r.priority)}</td><td>${statePill(r.state)}</td>
      <td>${esc(r.assignment_group || '—')}${r.open_tasks ? `<span class="sub2">${r.open_tasks} open task${r.open_tasks > 1 ? 's' : ''}</span>` : ''}</td>
      <td>${slaCell(r.sla)}</td><td class="last">${lastUpdate(r.last_update)}</td>`;
  }
  const rowHref = (kind, r) => kind === 'tasks' ? recordHash(r.parent_type, r.parent_id) : LISTS[kind].type ? recordHash(LISTS[kind].type, r.id) : '';

  async function renderList(page, kind, view, quiet) {
    const L = LISTS[kind];
    const key = `${kind}/${view}`;
    const st = (listState[key] ||= { q: '', stage: '' });
    const title = L.views.find((v) => v[0] === view)[1];
    if (!quiet) {
      if (!NAV) await loadNav();
      page.innerHTML = `<section class="view">
        <div class="crumbs"><a href="#/home">Home</a><span>/</span><span>${esc(L.area)}</span></div>
        <div class="list-h"><h1>${esc(title)} <small id="listCount"></small></h1>
          <div class="acts">${kind === 'cases' || kind === 'requests' ? `<button class="btn primary" type="button" data-act="new-case">${ICON.plus}New ${kind === 'requests' ? 'request' : 'case'}</button>` : ''}
            ${L.major ? `<button class="btn primary" type="button" data-act="major">${ICON.plus}Raise major incident</button>` : ''}</div></div>
        <section class="card">
          <div class="toolbar">
            ${L.views.map(([v, label, c]) => `<a class="chip ${v === view ? 'on' : ''}" href="#/list/${kind}/${v}">${esc(label.replace(/ (orders|cases|service requests|incidents|tasks|enquiries)$/, ''))}<em>${get(NAV, c) ?? ''}</em></a>`).join('')}
            ${L.stageChips && view === 'open' ? `<span style="width:1px;height:22px;background:var(--line);margin:0 4px"></span>${['', 'Validation', 'Fulfilment', 'Activation'].map((s) => `<button class="chip ${st.stage === s ? 'on' : ''}" type="button" data-stage="${s}">${s || 'All stages'}</button>`).join('')}` : ''}
            <label class="find">${ICON.search}<input id="listQ" placeholder="Search ${esc(L.label)}" value="${esc(st.q)}" autocomplete="off"></label>
          </div>
          <div class="tbl-wrap" id="tbl"><table><thead><tr>${L.head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>
            ${`<tr><td colspan="${L.head.length}"><div class="skel" style="height:18px"></div></td></tr>`.repeat(5)}</tbody></table></div>
          <div class="pager" id="pager"></div>
        </section></section>`;
      const q = $('listQ');
      q.addEventListener('input', debounce(() => { st.q = q.value; fillList(kind, view, st); }, 250));
      page.querySelectorAll('[data-stage]').forEach((b) => (b.onclick = () => {
        st.stage = b.dataset.stage;
        page.querySelectorAll('[data-stage]').forEach((x) => x.classList.toggle('on', x === b));
        fillList(kind, view, st);
      }));
    }
    await fillList(kind, view, st);
  }

  async function fillList(kind, view, st) {
    const L = LISTS[kind];
    const params = new URLSearchParams({ view });
    if (st.q.trim()) params.set('q', st.q.trim());
    if (st.stage) params.set('stage', st.stage);
    const rows = await api(`/api/ws/list/${kind}?${params}`);
    if (parse().name !== 'list' || parse().kind !== kind || parse().view !== view) return; // the agent moved on
    $('listCount').textContent = `${rows.length} ${rows.length === 1 ? L.label.replace(/s$/, '') : L.label}`;
    const body = rows.length ? rows.map((r) => { const h = rowHref(kind, r); return h ? `<tr data-href="${h}" tabindex="0">${L.row(r)}</tr>` : `<tr style="cursor:default">${L.row(r)}</tr>`; }).join('')
      : `<tr><td colspan="${L.head.length}" style="cursor:default"><div class="empty">${ICON.inbox}<b>${st.q || st.stage ? 'Nothing matches' : 'Nothing here'}</b>${st.q || st.stage ? 'Try a different search or filter.' : 'Records appear here as they reach this state.'}</div></td></tr>`;
    $('tbl').innerHTML = `<table><thead><tr>${L.head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table>`;
    $('pager').innerHTML = `<span>${rows.length} shown</span><span>${['open', 'new'].includes(view) && kind !== 'enquiries' ? 'Most urgent first (by SLA)' : 'Newest first'} · updates every 15 s</span>`;
  }

  // =====================================================================
  // AI IMPACT: what the ten agents did (live from the database)
  // =====================================================================
  async function renderImpact(page, quiet) {
    if (!quiet) page.innerHTML = `<section class="view"><div class="hero-kpis">${'<div class="card skel" style="height:118px"></div>'.repeat(4)}</div><div class="card skel" style="height:300px"></div></section>`;
    const m = await api('/api/metrics');
    if (parse().name !== 'impact') return;
    const n = (x) => Number(x || 0).toLocaleString('en-GB');
    const pct = (a, b) => (b ? Math.round((100 * a) / b) : 0);
    const plural = (k, word) => `${k} ${word}${k === 1 ? '' : 's'}`;
    const caught = m.kci.fixed + m.kci.held + m.agent_checks.stopped;
    const upset = m.sentiment.filter((s) => ['angry', 'negative'].includes(s.sentiment)).reduce((a, s) => a + s.n, 0);
    const reviewed = m.kci.total + m.agent_checks.passed + m.agent_checks.stopped;
    const live = HEALTH?.ai === 'openai';
    const src = (openai, total) => !total ? '' : `<span class="src ${openai ? 'on' : 'off'}">${openai ? `${pct(openai, total)}% by OpenAI` : 'demo mode (rules)'}</span>`;
    const agent = (name, value, label, sub, source = '') =>
      `<div class="card agent"><span class="n">${SPARK}${esc(name)}</span><span class="v ${typeof value === 'string' ? 'txt' : ''}">${typeof value === 'string' ? esc(value) : n(value)}</span>
        <span class="l">${esc(label)}</span><span class="s">${esc(sub)}</span>${source}</div>`;

    // Chart 1: customer updates by milestone (one series: magnitude, one hue, direct labels)
    const max = Math.max(1, ...m.by_event.map((e) => e.n));
    const bars = m.by_event.length ? `<div class="hbars">${m.by_event.map((e) => `
        <div class="hbar" data-tip="${esc(eventName(e.event))}: ${e.n} sent (${pct(e.n, m.kci.sent)}% of all updates)">
          <span class="lab">${esc(eventName(e.event))}</span><span class="track"><span class="fill" style="width:${(100 * e.n) / max}%"></span></span><span class="num">${e.n}</span></div>`).join('')}</div>`
      : `<div class="empty">${ICON.inbox}<b>No updates yet</b></div>`;

    // Chart 2: quality (status colours, always with a text label + count)
    const seg = (parts) => {
      const total = parts.reduce((a, p) => a + p.n, 0);
      return `<div class="segbar" role="img" aria-label="${esc(parts.map((p) => `${p.label} ${p.n}`).join(', '))}">${total ? parts.filter((p) => p.n).map((p) => `<i style="flex:${p.n};background:${p.c}" data-tip="${esc(p.label)}: ${p.n} (${pct(p.n, total)}%)"></i>`).join('') : ''}</div>
        <div class="seglegend">${parts.map((p) => `<span><i style="background:${p.c}"></i>${esc(p.label)} <b>${p.n}</b></span>`).join('')}</div>`;
    };

    page.innerHTML = `<section class="view">
      <div class="crumbs"><a href="#/home">Home</a><span>/</span><span>AI impact</span></div>
      <div class="list-h"><h1>AI impact <small>live from the database · updates every 15 s</small></h1>
        <span class="ai-status ${live ? '' : 'off'}"><i></i>${live ? `OpenAI connected · ${esc(HEALTH.model)}` : 'AI demo mode: numbers below come from rules and templates'}</span></div>

      <div class="hero-kpis">
        <div class="card hk ai"><div class="l">Customer updates sent</div><div class="v">${n(m.kci.sent)}</div><div class="s">${m.kci.by_openai ? `${n(m.kci.by_openai)} written by OpenAI` : 'Written by the KCI Writer, checked by the AI Reviewer'}</div></div>
        <div class="card hk"><div class="l">Agent time saved</div><div class="v">${(m.impact.agent_minutes_saved / 60).toFixed(1)} h</div><div class="s">${n(m.impact.agent_minutes_saved)} min at ${m.impact.manual_minutes_per_kci} min per hand-written update</div></div>
        <div class="card hk"><div class="l">Told before they had to chase</div><div class="v">${n(m.kci.early_warnings)}</div><div class="s">Delay, at-risk and incident updates · ${n(m.kci.proactive)} sent automatically</div></div>
        <div class="card hk"><div class="l">Caught by the AI Reviewer</div><div class="v">${n(caught)}</div><div class="s">${m.kci.fixed} fixed · ${m.kci.held} held for a human · ${m.agent_checks.stopped} agent emails or replies stopped</div></div>
      </div>

      <div class="sec-title"><h2>The ten AI agents</h2><span>Each card counts what that agent did</span></div>
      <div class="agents">
        ${agent('Plan Advisor', m.orders.with_needs, 'orders shaped by a chat', 'Needs captured before buying; prices always from code')}
        ${agent('AI Order Agent', m.orders.validated, 'orders validated', `${m.orders.flagged} flagged for a human review`, src(m.orders.validated_by_openai, m.orders.validated))}
        ${agent('KCI Decision Agent', m.decisions.total, 'decisions on at-risk and late tasks', `${plural(m.decisions.sent, 'update')} sent · ${m.decisions.held_back} held back · ${plural(m.decisions.visits_rebooked, 'visit')} rebooked`, src(m.decisions.by_openai, m.decisions.total))}
        ${agent('KCI Writer', m.kci.total, 'customer updates written', `${(m.kci.avg_latency_ms / 1000).toFixed(1)} s on average, draft + review`, src(m.kci.by_openai, m.kci.total))}
        ${agent('AI Reviewer', reviewed, 'messages checked before sending', `${m.kci.passed} passed · ${m.kci.fixed} fixed · ${m.kci.held + m.agent_checks.stopped} stopped`)}
        ${agent('Order Assistant', m.bot.questions, 'customer questions answered', `${m.bot.deflection_pct === null ? '—' : m.bot.deflection_pct + '%'} without an agent · ${plural(m.bot.self_service_reschedules, 'visit')} self-booked`)}
        ${agent('AI Triage Agent', m.triage.triaged, 'cases and requests triaged', `${m.triage.from_handover} from chat handovers · ${m.triage.requests} service requests`, src(m.triage.by_openai, m.triage.triaged))}
        ${agent('Photo Diagnosis', m.incidents.from_photo, 'incidents raised from photos', 'Router and installation photos read by vision')}
        ${agent('Insight Agent', upset, 'upset customers flagged', 'Sentiment and urgency of every customer message')}
        ${agent('Agent Assist', 'On every record', 'summary · copilot · email', 'Briefing, next best action, Write with AI')}
      </div>

      <div class="charts">
        <section class="card"><div class="card-h"><h3>Customer updates by milestone</h3><span class="pill grey">${n(m.kci.sent)} sent</span></div>
          <div class="chart-b">${bars}</div></section>
        <section class="card"><div class="card-h"><h3>Quality and promises kept</h3></div>
          <div class="chart-b">
            <div class="chart-sub" style="margin-top:0">AI Reviewer verdicts on customer updates</div>
            ${seg([{ label: 'Passed', n: m.kci.passed, c: '#12804A' }, { label: 'Fixed by the Reviewer', n: m.kci.fixed, c: '#6A4CF5' }, { label: 'Held for a human', n: m.kci.held, c: '#C2352B' }])}
            <div class="chart-sub">Finished SLAs</div>
            ${seg([{ label: 'Met', n: m.sla.met, c: '#12804A' }, { label: 'Breached', n: m.sla.breached_finished, c: '#C2352B' }])}
            <div class="chart-sub">Running SLAs now</div>
            ${seg([{ label: 'On track', n: m.sla.on_track, c: '#12804A' }, { label: 'At risk', n: m.sla.at_risk, c: '#E39200' }, { label: 'Breached', n: m.sla.breached, c: '#C2352B' }])}
          </div></section>
      </div>

      <section class="card foot-stats">
        <span>Orders <b>${n(m.orders.total)}</b> (${n(m.orders.completed)} completed)</span>
        <span>Incidents <b>${n(m.incidents.total)}</b> (${n(m.incidents.major)} major)</span>
        <span>Tokens used <b>${n(m.kci.tokens)}</b>${m.impact.cost_gbp !== null ? ` ≈ <b>£${m.impact.cost_gbp.toFixed(2)}</b>` : ''}</span>
        <span>Average update time <b>${(m.kci.avg_latency_ms / 1000).toFixed(1)} s</b></span>
        <span class="muted">Time saved assumes ${m.impact.manual_minutes_per_kci} min per hand-written update (MANUAL_KCI_MINUTES in .env).${m.impact.cost_gbp === null ? ' Set COST_PER_1K_TOKENS_GBP to show the AI cost.' : ''}</span>
      </section>
    </section>`;
  }

  // =====================================================================
  // RECORD (full page arrives in Step 3; for now a summary card)
  // =====================================================================
  async function renderRecord(page, type, id) {
    if (window.WS.renderRecord) return window.WS.renderRecord(page, type, id);   // full record pages: record.js
    page.innerHTML = `<section class="view"><div class="card" style="padding:22px"><div class="skel" style="height:26px;width:40%"></div></div></section>`;
    const url = { order: `/api/ws/orders/${id}`, case: `/api/ws/cases/${id}`, incident: `/api/incidents/${id}` }[type];
    const r = await api(url);
    const ref = r.order_number || r.case_number || r.incident_number;
    const back = { order: '#/list/orders/open', case: r.type === 'Service Request' ? '#/list/requests/new' : '#/list/cases/new', incident: '#/list/incidents/new' }[type];
    const rows = type === 'order'
      ? [['Customer', r.customer_name], ['Plan', r.product_name], ['Stage', `${r.current_stage} (${r.status})`], ['Postcode', r.pincode], ['Monthly', money(r.monthly_total_gbp)], ['Next step', r.can_advance ? `Ready to move to ${r.next_stage}` : r.advance_block]]
      : type === 'case'
        ? [['Customer', r.customer_name], ['Type', r.type], ['Title', r.short_description], ['Priority', r.priority], ['State', r.state], ['Team', r.assignment_group]]
        : [['Description', r.description], ['Priority', r.priority], ['State', r.state], ['Team', r.assignment_group], ['Affects', r.is_major ? `${r.children.length} customers at ${r.pincode}` : `${r.customer_name || ''} ${r.order_number || ''}`]];
    page.innerHTML = `<section class="view">
      <div class="crumbs"><a href="#/home">Home</a><span>/</span><a href="${back}">${esc(type === 'case' ? (r.type === 'Service Request' ? 'Service requests' : 'Cases') : type === 'order' ? 'Orders' : 'Incidents')}</a><span>/</span><span class="mono">${esc(ref)}</span></div>
      <section class="card" style="padding:22px">
        <h1 style="font-size:24px;margin-bottom:14px"><span class="mono num" style="font-size:15px">${esc(ref)}</span></h1>
        <dl style="display:grid;grid-template-columns:140px 1fr;gap:8px 14px;margin:0">${rows.map(([k, v]) => `<dt class="muted">${esc(k)}</dt><dd style="margin:0">${esc(v ?? '—')}</dd>`).join('')}</dl>
        <div class="ai-box" style="margin-top:18px"><b>Full record page arrives in Step 3:</b> stage bar, Move to next stage, activity timeline, task and SLA tabs, AI summary, Copilot and Draft email.</div>
      </section></section>`;
  }

  // =====================================================================
  // Ctrl+K SEARCH
  // =====================================================================
  let palItems = []; let palIndex = 0;
  const QUICK = [
    { label: 'Open orders', sub: 'Order management', href: '#/list/orders/open' },
    { label: 'New cases', sub: 'Service management', href: '#/list/cases/new' },
    { label: 'New service requests', sub: 'Service management', href: '#/list/requests/new' },
    { label: 'Open incidents', sub: 'Service management', href: '#/list/incidents/open' },
    { label: 'New case…', sub: 'Create', act: 'new-case' },
    { label: 'Raise major incident…', sub: 'Create', act: 'major' },
  ];
  function openPalette() {
    $('palIn').value = ''; showPal(QUICK.map((q) => ({ ...q, group: 'Go to' })));
    $('palette').showModal(); $('palIn').focus();
  }
  function showPal(items) {
    palItems = items; palIndex = 0;
    let html = ''; let group = null;
    items.forEach((it, i) => {
      if (it.group !== group) { group = it.group; html += `<div class="pal-grp">${esc(group)}</div>`; }
      html += `<div class="pal-item ${i === 0 ? 'on' : ''}" data-i="${i}">${it.num ? `<span class="mono num">${esc(it.num)}</span>` : ''}<b>${esc(it.label)}</b><span>${esc(it.sub || '')}</span></div>`;
    });
    $('palRes').innerHTML = html || '<div class="empty" style="padding:24px">No matches</div>';
  }
  function pickPal(i) {
    const it = palItems[i]; if (!it) return;
    $('palette').close();
    if (it.act) openAction(it.act); else go(it.href);
  }
  const searchPal = debounce(async (q) => {
    if (q.trim().length < 2) { showPal(QUICK.map((x) => ({ ...x, group: 'Go to' }))); return; }
    const p = `view=all&q=${encodeURIComponent(q.trim())}`;
    const [orders, cases, requests, incidents] = await Promise.all(['orders', 'cases', 'requests', 'incidents']
      .map((k) => api(`/api/ws/list/${k}?${p}`).catch(() => [])));
    if ($('palIn').value !== q) return;
    showPal([
      ...orders.slice(0, 5).map((r) => ({ group: 'Orders', num: r.order_number, label: r.customer_name, sub: `${r.product_name} · ${r.current_stage} · ${r.status}`, href: recordHash('order', r.id) })),
      ...cases.slice(0, 5).map((r) => ({ group: 'Cases', num: r.case_number, label: r.short_description, sub: `${r.customer_name} · ${r.state}`, href: recordHash('case', r.id) })),
      ...requests.slice(0, 5).map((r) => ({ group: 'Service requests', num: r.case_number, label: r.short_description, sub: `${r.customer_name} · ${r.state}`, href: recordHash('case', r.id) })),
      ...incidents.slice(0, 5).map((r) => ({ group: 'Incidents', num: r.incident_number, label: r.description, sub: `${r.customer_name || r.pincode || ''} · ${r.state}`, href: recordHash('incident', r.id) })),
    ]);
  }, 200);
  $('openPalette').onclick = openPalette;
  $('palIn').addEventListener('input', () => searchPal($('palIn').value));
  $('palIn').addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      palIndex = (palIndex + (e.key === 'ArrowDown' ? 1 : -1) + palItems.length) % Math.max(1, palItems.length);
      $('palRes').querySelectorAll('.pal-item').forEach((el) => el.classList.toggle('on', Number(el.dataset.i) === palIndex));
      $('palRes').querySelector('.pal-item.on')?.scrollIntoView({ block: 'nearest' });
    }
    if (e.key === 'Enter') { e.preventDefault(); pickPal(palIndex); }
  });
  $('palRes').addEventListener('click', (e) => { const it = e.target.closest('.pal-item'); if (it) pickPal(Number(it.dataset.i)); });
  $('palette').addEventListener('click', (e) => { if (e.target === $('palette')) $('palette').close(); });
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (!$('palette').open) openPalette(); }
    if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName) && !document.querySelector('dialog[open]')) { e.preventDefault(); openPalette(); }
  });

  // =====================================================================
  // NEW CASE (AI triage)
  // =====================================================================
  let custMode = 'order';
  async function openNewCase(prefill = {}) {
    if (!OPTIONS) OPTIONS = await api('/api/ws/case-options');
    const f = $('caseForm'); f.reset(); custMode = 'order'; setCustMode('order');
    fillSelect($('cPri'), OPTIONS.priorities); fillSelect($('cTeam'), OPTIONS.teams); fillCats('');
    f.querySelectorAll('.ai-filled').forEach((x) => x.classList.remove('ai-filled'));
    $('triageBox').hidden = true; $('caseErr').hidden = true;
    if (prefill.order_number) f.order_number.value = prefill.order_number;
    $('newCase').showModal(); (prefill.order_number ? f.description : f.order_number).focus();
  }
  const fillSelect = (sel, values) => { sel.innerHTML = '<option value="">Let AI decide</option>' + values.map((v) => `<option>${esc(v)}</option>`).join(''); };
  function fillCats(type) {
    const cats = type ? OPTIONS.categories[type] : [...OPTIONS.categories.Case, ...OPTIONS.categories['Service Request']];
    const cur = $('cCat').value; fillSelect($('cCat'), cats); if (cats.includes(cur)) $('cCat').value = cur;
  }
  function setCustMode(mode) {
    custMode = mode;
    $('custMode').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
    document.querySelectorAll('#caseForm [data-for]').forEach((el) => (el.hidden = el.dataset.for !== mode));
  }
  $('custMode').onclick = (e) => { const b = e.target.closest('button'); if (b) setCustMode(b.dataset.mode); };
  $('cType').onchange = () => fillCats($('cType').value);
  $('triageBtn').onclick = async () => {
    const text = $('caseForm').description.value.trim();
    if (!text) { $('caseErr').textContent = 'Describe what the customer needs first.'; $('caseErr').hidden = false; return; }
    const btn = $('triageBtn'); btn.disabled = true; btn.lastChild.textContent = 'Triaging…'; $('caseErr').hidden = true;
    try {
      const t = await api('/api/ws/triage', { text });
      $('cType').value = t.type; fillCats(t.type); $('cCat').value = t.category; $('cPri').value = t.priority; $('cTeam').value = t.assignment_group; $('cTitle').value = t.title;
      ['cType', 'cCat', 'cPri', 'cTeam', 'cTitle'].forEach((id) => $(id).closest('.f').classList.add('ai-filled'));
      $('triageBox').hidden = false;
      $('triageBox').innerHTML = `<b>${t.ai_source === 'openai' ? 'AI Triage Agent' : 'Triage (rules, AI demo mode)'}:</b> ${esc(t.type)} · ${esc(t.category)} · ${esc(t.priority)} · ${esc(t.assignment_group)}. ${esc(t.summary)} <span class="note">You can change anything before creating it.</span>`;
    } catch (e) { $('caseErr').textContent = e.message; $('caseErr').hidden = false; }
    finally { btn.disabled = false; btn.lastChild.textContent = 'Triage with AI'; }
  };
  $('caseForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target));
    if (custMode === 'order') { delete data.customer_name; delete data.customer_email; delete data.customer_phone; } else delete data.order_number;
    Object.keys(data).forEach((k) => { if (!String(data[k]).trim()) delete data[k]; });
    data.agent_name = AGENT.name;
    const btn = $('caseSubmit'); btn.disabled = true; btn.textContent = 'Creating…'; $('caseErr').hidden = true;
    try {
      const r = await api('/api/ws/cases', data);
      $('newCase').close();
      toast(`${r.case.case_number} created${r.kci ? ` · customer ${r.kci.status === 'Sent' ? 'told the reference' : 'update held for review'}` : ''}`);
      loadNav(); go(recordHash('case', r.case.id));
    } catch (ex) { $('caseErr').textContent = ex.message; $('caseErr').hidden = false; }
    finally { btn.disabled = false; btn.textContent = 'Create'; }
  });

  // =====================================================================
  // RAISE MAJOR INCIDENT
  // =====================================================================
  async function openMajor() {
    const [areas, teams] = await Promise.all([api('/api/coverage/areas'), OPTIONS ? Promise.resolve(OPTIONS.teams) : api('/api/ws/case-options').then((o) => (OPTIONS = o).teams)]);
    const countries = [...new Set(areas.map((a) => a.country))];
    $('mPostcode').innerHTML = '<option value="">Choose the affected postcode</option>' + countries.map((c) =>
      `<optgroup label="${esc(c)}">${areas.filter((a) => a.country === c).map((a) => `<option value="${esc(a.pincode)}">${esc(a.pincode)} · ${esc(a.area)}, ${esc(a.city)}</option>`).join('')}</optgroup>`).join('');
    $('mTeam').innerHTML = teams.map((t) => `<option ${t === 'Network Operations' ? 'selected' : ''}>${esc(t)}</option>`).join('');
    $('majorForm').reset(); $('mTeam').value = 'Network Operations'; $('majorErr').hidden = true;
    $('majorDlg').showModal();
  }
  $('majorForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('majorSubmit'); btn.disabled = true; btn.textContent = 'Raising and writing updates…'; $('majorErr').hidden = true;
    try {
      const r = await api('/api/major-incidents', Object.fromEntries(new FormData(e.target)));
      $('majorDlg').close();
      toast(`${r.incident.incident_number}: ${r.affected} orders linked · ${r.notified} customers informed${r.held ? ` · ${r.held} held for review` : ''}`);
      loadNav(); go(recordHash('incident', r.incident.id));
    } catch (ex) { $('majorErr').textContent = ex.message; $('majorErr').hidden = false; }
    finally { btn.disabled = false; btn.textContent = 'Raise and inform customers'; }
  });

  // ---------------- shared wiring ----------------
  async function resetDemo() {
    await window.WS.formDialog({ title: 'Reset demo data?', text: 'All orders, cases, incidents, tasks and updates are replaced with the demo set (James Carter and the others).',
      submit: 'Reset demo data', danger: true, note: 'Takes a few seconds; with the OpenAI key the demo updates are written by AI.',
      onSubmit: async () => { const r = await api('/api/admin/reset-demo', {}); toast(`Demo data reset: ${r.orders.length + r.neighbours} orders, ${r.cases} cases`); await loadNav(); go('#/home'); } });
  }
  function openAction(act) {
    (act === 'new-case' ? openNewCase() : act === 'reset' ? resetDemo() : openMajor()).catch((e) => toast(e.message, true));
  }
  document.addEventListener('click', async (e) => {
    const enq = e.target.closest('[data-enq]');
    if (enq) {
      const [id, status] = enq.dataset.enq.split(':'); enq.disabled = true;
      try { await api(`/api/enquiries/${id}/status`, { status }); toast(`Enquiry marked ${status.toLowerCase()}`); await loadNav(); await fillList(route.kind, route.view, listState[`${route.kind}/${route.view}`]); }
      catch (ex) { toast(ex.message, true); enq.disabled = false; }
      return;
    }
    const act = e.target.closest('[data-act]'); if (act) { e.preventDefault(); openAction(act.dataset.act); return; }
    const close = e.target.closest('[data-close]'); if (close) { close.closest('dialog').close(); return; }
    const row = e.target.closest('[data-href]'); if (row && !e.target.closest('a, button')) go(row.dataset.href);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches?.('tr[data-href]')) go(e.target.dataset.href);
  });
  window.addEventListener('hashchange', () => render());   // (not `render` directly: the event object would be read as "quiet")

  // Live: counts and the open page refresh every 15 s (not while a dialog is open or the agent is typing)
  setInterval(async () => {
    if (document.hidden || refreshing || document.querySelector('dialog[open]')) return;
    refreshing = true;
    try {
      await loadNav();
      if (route.name === 'home') await renderHome($('page'), true);
      if (route.name === 'impact') await renderImpact($('page'), true);
      if (route.name === 'list' && document.activeElement?.id !== 'listQ') await fillList(route.kind, route.view, listState[`${route.kind}/${route.view}`]);
      if (route.name === 'record' && window.WS.refreshRecord) await window.WS.refreshRecord();
    } catch { /* keep the last good screen */ } finally { refreshing = false; }
  }, 15000);

  // Shared with record.js (the record pages)
  window.WS = {
    AGENT, $, esc, api, toast, avatar, ago, day, money, debounce, SPARK, ICON, EVENT, eventName,
    statePill, stagePill, priPill, slaCell, go, recordHash, loadNav, render,
    openNewCase: (prefill) => openNewCase(prefill).catch((e) => toast(e.message, true)),
    caseOptions: async () => (OPTIONS ||= await api('/api/ws/case-options')),
    aiOn: () => HEALTH?.ai === 'openai',
  };

  $('me').textContent = AGENT.initials; $('me').title = AGENT.name;
  loadHealth(); loadNav().then(() => render());
})();
