// End-to-end smoke test of the running app. It RESETS the demo data first.
// Run (server must be running):  npm run test:smoke        (or BASE=http://localhost:3000 node scripts/smoke-test.mjs)
// Without an OpenAI key, the AI chat steps are reported as "skipped (no key)" instead of failing.

const BASE = (process.env.BASE || 'http://localhost:3000') + '/api';
let pass = 0, fail = 0, skip = 0;

async function call(method, path, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, data };
}

async function step(name, fn, { aiOnly = false } = {}) {
  try {
    await fn();
    pass++; console.log(`PASS  ${name}`);
  } catch (err) {
    if (aiOnly && /not connected|OPENAI_API_KEY/i.test(err.message)) { skip++; console.log(`SKIP  ${name} (no OpenAI key)`); return; }
    fail++; console.log(`FAIL  ${name}: ${err.message}`);
  }
}
const expect = (cond, msg) => { if (!cond) throw new Error(msg); };
const must = async (method, path, body) => {
  const r = await call(method, path, body);
  if (!r.ok) throw new Error(r.data.error || `HTTP ${r.status}`);
  return r.data;
};
const refused = async (method, path, body, pattern) => {
  const r = await call(method, path, body);
  expect(!r.ok, `${path} should have been refused`);
  expect(pattern.test(r.data.error || ''), `unexpected error: ${r.data.error}`);
};
const order = (id) => must('GET', `/ws/orders/${id}`);
const openTask = (o) => o.tasks.find((t) => ['Open', 'In Progress'].includes(t.state));
const act = async (orderId, action, extra = {}) => {
  const t = openTask(await order(orderId));
  expect(t, 'no open task');
  return must('POST', `/ws/order-tasks/${t.id}/action`, { action, ...extra });
};

// ---------------- demo data, catalogue, coverage ----------------
await step('Reset demo data (7 orders; 3 cases, none created by an order)', async () => {
  const r = await must('POST', '/admin/reset-demo', {});
  expect(r.orders?.length === 3 && r.neighbours === 4, 'unexpected demo data');
  const cases = await must('GET', '/cases');
  expect(cases.length === 3, `expected the 3 demo cases, found ${cases.length}`);
  const james = await order(1);
  expect(james.customer_name === 'James Carter' && james.current_stage === 'Fulfilment', 'James should be in Fulfilment');
  expect(james.kcis.every((k) => k.message.startsWith('Dear James,')), 'updates must greet by first name');
});

await step('Catalog has 9 plans in GBP', async () => {
  const cat = await must('GET', '/catalog');
  expect(cat.plans?.length >= 9 && cat.plans.every((p) => typeof p.price_gbp === 'number'), 'bad catalog');
});

await step('Coverage: M14 5RG (any spacing), TR19 7AA nothing, Berlin found; postcode list UK first', async () => {
  const a = await must('GET', '/coverage?q=m145rg');
  expect(a.found && a.services.broadband && a.pincode === 'M14 5RG', 'M14 5RG should have broadband');
  const b = await must('GET', '/coverage?q=TR19%207AA');
  expect(b.found && !b.services.broadband && !b.services.mobile, 'TR19 7AA should have no services');
  const c = await must('GET', '/coverage?q=Berlin');
  expect(c.found && c.country === 'Germany', 'Berlin should be in Germany');
  const areas = await must('GET', '/coverage/areas');
  expect(areas.length >= 16 && areas[0].country === 'United Kingdom', 'postcode list wrong');
});

await step('Price quote by code (FIBER100 + SPEED300 + MESH = £38.09); Belfast fiber refused', async () => {
  const q = await must('POST', '/quote', { product_code: 'FIBER100', addon_codes: ['SPEED300', 'MESH'] });
  expect(q.monthly_total_gbp === 38.09, `expected 38.09, got ${q.monthly_total_gbp}`);
  await refused('POST', '/orders', { customer_name: 'Test User', customer_email: 't@example.com', customer_phone: '07700 900099',
    product_id: 1, address: '1 Lisburn Road, Belfast', pincode: 'BT9 5AA' }, /not available/i);
});

// ---------------- the full order journey ----------------
let olivia;
await step('Order placed: no case, no update, AI validation done, tasks planned', async () => {
  const casesBefore = (await must('GET', '/cases')).length;
  const r = await must('POST', '/orders', { customer_name: 'Olivia Brown', customer_email: 'olivia.brown@example.com',
    customer_phone: '07700 900050', product_id: 1, address: '5 Burton Road, Didsbury, Manchester', pincode: 'm20 2rn',
    addon_codes: ['MESH'], customer_needs: 'Two-floor house, works from home' });
  expect(!r.case && (await must('GET', '/cases')).length === casesBefore, 'no case may be created for an order');
  olivia = await order(r.order.id);
  expect(olivia.pincode === 'M20 2RN', 'postcode not stored in standard form');
  expect(r.stage_decision?.moved && olivia.current_stage === 'Fulfilment', `AI Stage Agent did not move it on (stage ${olivia.current_stage})`);
  expect(olivia.kcis.length === 0, 'no customer update on order creation');
  expect(olivia.tasks.map((t) => t.task_type).join() === 'VALIDATION,CPE_DELIVERY,ENGINEER_VISIT,ACTIVATION', 'wrong task plan');
  expect(olivia.tasks[0].state === 'Closed', 'validation task should be closed (PASS)');
  expect(olivia.tasks[1].details.items.includes('Mesh Wi-Fi extender'), 'mesh missing from delivery');
  expect(olivia.order_sla?.state === 'In Progress', 'order SLA not running');
});

await step('AI Stage Agent moved it to Fulfilment (logged); next move locked until tasks are closed', async () => {
  expect(olivia.activities.some((a) => a.author_name === 'AI Stage Agent' && /Decided: MOVE to Fulfilment/.test(a.message)), 'Stage Agent decision not logged');
  expect(olivia.kcis.length === 0, 'Fulfilment is internal: no update');
  await refused('POST', `/ws/orders/${olivia.id}/advance`, {}, /Close the Equipment delivery/);
  await refused('POST', `/ws/order-tasks/${openTask(await order(olivia.id)).id}/action`, { action: 'deliver' }, /Schedule the delivery first/);
});

await step('Milestones send AI updates; the stage moves on only when its LAST task closes', async () => {
  const events = []; const moves = [];
  for (const [action, extra] of [['schedule', {}], ['deliver', {}], ['schedule', {}], ['complete', {}]]) {
    const r = await act(olivia.id, action, extra);
    expect(r.kci?.status === 'Sent', `${action}: update not sent (${r.kci?.status})`);
    events.push(r.kci.event); moves.push(r.stage_decision?.moved ? r.stage_decision.to : '-');
  }
  expect(events.join() === 'CPE_DELIVERY_SCHEDULED,CPE_DELIVERED,ENGINEER_APPOINTMENT_SCHEDULED,ENGINEER_VISIT_COMPLETED', events.join());
  expect(moves.join() === '-,-,-,Activation', `Stage Agent moved at the wrong time: ${moves.join()}`);
});

await step('Activation closes -> AI Stage Agent completes the order with the final update; SLAs stopped; order closed', async () => {
  const r = await act(olivia.id, 'activate');
  expect(r.kci.event === 'SERVICE_ACTIVATED', 'no activation update');
  expect(r.stage_decision?.to === 'Completed' && r.stage_decision.kci?.event === 'ORDER_COMPLETED', 'no automatic completion with the final update');
  const o = await order(olivia.id);
  expect(o.status === 'Completed' && o.slas.every((s) => s.state !== 'In Progress'), 'SLAs still running');
  expect(o.kcis.length === 6, `expected 6 updates, got ${o.kcis.length}`);
  expect((await must('POST', `/ws/orders/${olivia.id}/close`, {})).status === 'Closed', 'not closed');
});

await step('AI Stage Agent HOLDS an order when the engineer measured 30 Mbps on a 100 Mbps plan; a person moves it', async () => {
  const r = await must('POST', '/orders', { customer_name: 'Leo King', customer_email: 'leo.king@example.com',
    customer_phone: '07700 900052', product_id: 1, address: '9 Burton Road, Didsbury, Manchester', pincode: 'M20 2RN' });
  const id = r.order.id;
  for (const a of ['schedule', 'deliver', 'schedule']) await act(id, a);
  const done = await act(id, 'complete', { speed_mbps: 30 });
  expect(done.stage_decision && !done.stage_decision.moved && done.stage_decision.action === 'HOLD', `expected HOLD, got ${JSON.stringify(done.stage_decision)}`);
  let o = await order(id);
  expect(o.current_stage === 'Fulfilment' && o.needs_attention && o.can_advance, 'order should wait in Fulfilment, flagged, movable by a person');
  expect(o.activities.some((a) => a.author_name === 'AI Stage Agent' && a.entry_type === 'work_note'), 'no hold note for the agent');
  expect((await must('POST', `/ws/orders/${id}/advance`, {})).to === 'Activation', 'a person could not move it on');
  o = await order(id);
  expect(!o.needs_attention, 'flag not cleared after a person moved it');
});

await step('Cancel an open order: tasks and SLAs cancelled', async () => {
  const r = await must('POST', '/orders', { customer_name: 'Oscar Bell', customer_email: 'oscar.bell@example.com',
    customer_phone: '07700 900051', product_id: 2, address: '7 Queen Street, Cardiff', pincode: 'CF10 1EP' });
  const c = await must('POST', `/ws/orders/${r.order.id}/cancel`, { reason: 'Customer changed their mind' });
  expect(c.status === 'Cancelled', 'not cancelled');
  const o = await order(r.order.id);
  expect(o.tasks.every((t) => ['Closed', 'Cancelled'].includes(t.state)) && o.slas.every((s) => s.state !== 'In Progress'), 'left running');
});

// ---------------- task planning, dependencies, delays (Ankit's KCI-trigger design) ----------------
let grace;
await step('New order is planned: planned dates, dependency chain, customer impact', async () => {
  const r = await must('POST', '/orders', { customer_name: 'Grace Taylor', customer_email: 'grace.taylor@example.com',
    customer_phone: '07700 900070', product_id: 1, address: '12 Burton Road, Didsbury, Manchester', pincode: 'M20 2RN' });
  grace = await order(r.order.id);
  const [v, cpe, eng, act] = grace.tasks;
  expect(!v.customer_impact && cpe.customer_impact && eng.customer_impact && act.customer_impact, 'customer impact flags wrong');
  expect(cpe.planned_end && eng.planned_start && act.planned_end, 'tasks not planned');
  expect(eng.depends_on === cpe.id && act.depends_on === eng.id, 'dependency chain wrong');
  expect(new Date(eng.planned_start) > new Date(cpe.planned_end), 'engineer planned before the delivery');
  expect(grace.eta, 'no expected-ready date');
});

await step('Working calendar (config/business-rules.json): no planned date and no engineer slot on a non-working day', async () => {
  const s = await must('GET', '/ws/settings');
  const NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const ok = (d) => s.calendar_enabled === false || s.working_days.includes(NAMES[new Date(d).getDay()]);
  const t = (await order(grace.id)).tasks.filter((x) => x.customer_impact);
  expect(t.every((x) => ok(x.planned_start) && ok(x.planned_end)), `a planned date is on a non-working day (working days: ${s.working_days.join(' ')})`);
  const slots = await must('GET', '/ws/slots');
  expect(slots.length && slots.every((l) => s.calendar_enabled === false || s.working_days.includes(l.slice(0, 3))), 'an engineer slot is on a non-working day');
});

await step('Engineer can be booked once delivery is scheduled, but not before it arrives; visit needs the equipment', async () => {
  let o = await order(grace.id);
  const cpe = o.tasks.find((t) => t.task_type === 'CPE_DELIVERY');
  expect(o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT').state === 'Pending', 'engineer open too early');
  await must('POST', `/ws/order-tasks/${cpe.id}/action`, { action: 'schedule' });
  o = await order(grace.id);
  const eng = o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT');
  expect(eng.state === 'Open', 'engineer should open once the delivery is scheduled');
  const slots = await must('GET', `/ws/slots?order_id=${grace.id}`);
  const r = await must('POST', `/ws/order-tasks/${eng.id}/action`, { action: 'schedule', slot: slots[0] });
  expect(r.kci?.event === 'ENGINEER_APPOINTMENT_SCHEDULED', 'no engineer booked update');
  await refused('POST', `/ws/order-tasks/${eng.id}/action`, { action: 'complete' }, /needs the equipment/);
});

await step('Delivery delayed: revised ETA, engineer visit moved automatically, AI decision, ONE delay update', async () => {
  let o = await order(grace.id);
  const cpe = o.tasks.find((t) => t.task_type === 'CPE_DELIVERY');
  const engBefore = o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT');
  const kcisBefore = o.kcis.length;
  const r = await must('POST', `/ws/order-tasks/${cpe.id}/action`, { action: 'delay', days: 3, reason: 'Courier depot backlog (smoke test)' });
  expect(r.facts.new_date !== r.facts.old_date, 'no revised date');
  expect(r.facts.moved.some((m) => m.rebooked), 'engineer visit was not moved');
  expect(r.decision.action === 'SEND_UPDATE' && r.decision.update_type === 'DELAY', 'decision should be: send a delay update');
  expect(r.kci?.event === 'TASK_DELAYED' && r.kci.status === 'Sent', `delay update not sent (${r.kci?.status})`);
  expect(!r.kci.message.includes('backlog'), 'the internal reason leaked into the customer message');
  o = await order(grace.id);
  const eng = o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT');
  expect(eng.details.slot !== engBefore.details.slot && new Date(eng.planned_start) > new Date(o.tasks.find((t) => t.id === cpe.id).planned_end), 'visit not after the new delivery date');
  expect(o.kcis.length === kcisBefore + 1, 'exactly one update must be sent for the delay');
  expect(o.decisions.length >= 1 && o.tasks.find((t) => t.id === cpe.id).slipped, 'decision or slip not recorded');
  const customer = await must('GET', `/orders/${grace.id}`);
  expect(!JSON.stringify(customer).includes('backlog'), 'internal delay reason visible to the customer');
});

// Ankit's fallout scenario 2: the courier partner delays the delivery by 1 day
await step('Fallout 2: courier delay +1 day moves the engineer and the order ETA; the update gives the customer reason only', async () => {
  const s = await must('GET', '/ws/settings');
  expect(s.delay_customer_reason && s.delay_reasons.includes('Courier partner delay'), 'delay reasons list missing');
  const p = await must('POST', '/orders', { customer_name: 'Henry Clarke', customer_email: 'henry.clarke@example.com',
    customer_phone: '07700 900071', product_id: 1, address: '8 Wilmslow Road, Fallowfield, Manchester', pincode: 'M14 5RG' });
  let o = await order(p.order.id);
  const cpe = o.tasks.find((t) => t.task_type === 'CPE_DELIVERY');
  await must('POST', `/ws/order-tasks/${cpe.id}/action`, { action: 'schedule' });
  o = await order(p.order.id);
  const engBefore = o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT');
  const slots = await must('GET', `/ws/slots?order_id=${o.id}`);
  await must('POST', `/ws/order-tasks/${engBefore.id}/action`, { action: 'schedule', slot: slots[0] });
  o = await order(p.order.id);
  const before = { eng: o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT').planned_start, eta: o.eta };

  const r = await must('POST', `/ws/order-tasks/${cpe.id}/action`, { action: 'delay', days: 1,
    customer_reason: 'Courier partner delay', reason: 'Van 14 broke down at the depot (smoke test)' });
  expect(r.facts.delayed_by_working_days === 1 && r.facts.new_date !== r.facts.old_date, 'delivery not moved by 1 working day');
  expect(/courier partner/.test(r.facts.customer_reason || ''), 'customer reason not passed to the AI');
  o = await order(p.order.id);
  const eng = o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT');
  expect(new Date(eng.planned_start) > new Date(before.eng), 'engineer appointment did not move');
  expect(o.eta && o.eta !== before.eta, `order ETA not updated (${before.eta} -> ${o.eta})`);
  expect(r.kci?.event === 'TASK_DELAYED' && r.kci.status === 'Sent', `delay update not sent (${r.kci?.status})`);
  expect(/courier/i.test(r.kci.message), 'the customer was not told the reason');
  expect(!/van 14|broke down|depot/i.test(r.kci.message + r.kci.sms), 'the internal note leaked into the update');
});

// Ankit's fallout scenario 1: the engineer finds no free port at the hub
await step('Fallout 1: engineer can\'t complete (no free port): ticket, task + order On Hold, SLAs paused, revisit + ETA moved, ONE update; fix done resumes', async () => {
  const p = await must('POST', '/orders', { customer_name: 'Isla Morgan', customer_email: 'isla.morgan@example.com',
    customer_phone: '07700 900072', product_id: 1, address: '21 Ladybarn Lane, Fallowfield, Manchester', pincode: 'M14 5RG' });
  const id = p.order.id;
  let o = await order(id);
  const cpe = o.tasks.find((t) => t.task_type === 'CPE_DELIVERY');
  await must('POST', `/ws/order-tasks/${cpe.id}/action`, { action: 'schedule' });
  o = await order(id);
  const eng = o.tasks.find((t) => t.task_type === 'ENGINEER_VISIT');
  const slots = await must('GET', `/ws/slots?order_id=${id}`);
  await must('POST', `/ws/order-tasks/${eng.id}/action`, { action: 'schedule', slot: slots[0] });
  await must('POST', `/ws/order-tasks/${cpe.id}/action`, { action: 'deliver' });
  o = await order(id);
  const before = { slot: o.tasks.find((t) => t.id === eng.id).details.slot, act: o.tasks.find((t) => t.task_type === 'ACTIVATION').planned_end, eta: o.eta, kcis: o.kcis.length };

  const r = await must('POST', `/ws/order-tasks/${eng.id}/action`, { action: 'cant_complete', problem: 'No free port at the hub',
    fix_days: 2, reason: 'Hub M14-07: all 24 ports in use (smoke test)' });
  expect(r.incident?.assignment_group === 'Network Operations', 'no ticket for Network Operations');
  o = await order(id);
  const held = o.tasks.find((t) => t.id === eng.id);
  expect(o.status === 'On Hold' && held.state === 'On Hold', `order/task not on hold (${o.status} / ${held.state})`);
  expect(held.sla?.health === 'paused' && o.order_sla?.health === 'paused', 'SLA clocks not paused');
  expect(held.details.slot !== before.slot && new Date(held.planned_start) > new Date(o.tasks.find((t) => t.id === eng.id).original_planned_end || 0), `revisit not booked after the first visit (${before.slot} -> ${held.details.slot})`);
  expect(new Date(o.tasks.find((t) => t.task_type === 'ACTIVATION').planned_end) > new Date(before.act), 'activation not moved');
  expect(o.eta && o.eta !== before.eta, `order ETA not moved (${before.eta} -> ${o.eta})`);
  expect(r.kci?.event === 'ENGINEER_FALLOUT' && r.kci.status === 'Sent', `fallout update not sent (${r.kci?.status})`);
  expect(o.kcis.length === before.kcis + 1, 'exactly one update must be sent');
  expect(!/hub m14|24 ports|INC\d/i.test(r.kci.message + r.kci.sms), 'internal note or ticket number leaked');
  await refused('POST', `/ws/orders/${id}/advance`, {}, /incident|Close the/);

  const fixed = await must('POST', `/incidents/${r.incident.id}/resolve`, { resolution: 'Port card added at the hub' });
  expect(fixed.kci?.event === 'FALLOUT_CLEARED' && fixed.kci.status === 'Sent', `"fix done" update not sent (${fixed.kci?.event} ${fixed.kci?.status})`);
  o = await order(id);
  const back = o.tasks.find((t) => t.id === eng.id);
  expect(o.status === 'In Progress' && back.state === 'In Progress' && back.milestone === 'Scheduled', 'visit did not resume');
  expect(back.sla?.health !== 'paused' && o.order_sla?.health !== 'paused', 'SLA clocks not resumed');
  const done = await must('POST', `/ws/order-tasks/${eng.id}/action`, { action: 'complete' });
  expect(done.stage_decision?.to === 'Activation', 'Stage Agent did not move the order on after the revisit');
});

// ---------------- privacy ----------------
await step('Internal note stays internal (customer view)', async () => {
  await must('POST', '/ws/orders/1/notes', { message: 'Smoke test internal note', visibility: 'internal' });
  const o = await must('GET', '/orders/1');
  expect(!JSON.stringify(o).includes('Smoke test internal note'), 'internal note visible on the customer order page');
  expect(!JSON.stringify(o).includes('AI Order Agent'), 'internal validation visible to the customer');
});

// ---------------- incidents ----------------
await step('Incident on an order: New -> Open -> Resolved -> Closed; order On Hold until resolved', async () => {
  const { incident, kci } = await must('POST', '/ws/orders/3/incidents', { description: 'Courier van broke down', priority: 'P3', assignment_group: 'Logistics' });
  expect(incident.state === 'New' && kci?.event === 'INCIDENT_RAISED', 'incident should be New with a delay update');
  expect((await order(3)).status === 'On Hold', 'order not on hold');
  await refused('POST', `/ws/order-tasks/${openTask(await order(3)).id}/action`, { action: 'deliver' }, /on hold/i);
  await refused('POST', '/ws/orders/3/advance', {}, /Resolve incident/);
  expect((await must('POST', `/ws/incidents/${incident.id}/start`, {})).state === 'Open', 'not Open');
  await must('POST', `/incidents/${incident.id}/resolve`, { resolution: 'Replacement van dispatched' });
  expect((await order(3)).status === 'In Progress', 'order not back in progress');
  expect((await must('POST', `/ws/incidents/${incident.id}/close`, {})).state === 'Closed', 'not Closed');
});

// ---------------- service management ----------------
await step('Demo Service Request was opened by the Order Assistant and triaged', async () => {
  const srs = await must('GET', '/cases?type=Service%20Request');
  expect(srs.length === 1 && srs[0].case_number.startsWith('SR') && srs[0].origin === 'Order Assistant', 'no handover SR');
  expect(srs[0].category === 'Add a SIM' && srs[0].order_id === 2, `unexpected triage: ${srs[0].category}`);
});

let kase;
await step('Agent opens a case without an order: triaged, SLA running, customer told the reference', async () => {
  const r = await must('POST', '/ws/cases', { customer_name: 'Ava Johnson', customer_email: 'ava.johnson@example.com',
    customer_phone: '07700 900060', description: 'My internet keeps dropping every evening and I work from home.' });
  kase = await must('GET', `/ws/cases/${r.case.id}`);
  expect(kase.case_number.startsWith('CS') && kase.type === 'Case' && kase.state === 'New', 'bad case');
  expect(kase.category && kase.priority && kase.assignment_group, 'triage did not fill the case');
  expect(kase.case_sla?.state === 'In Progress', 'case SLA not running');
  const k = kase.kcis[0];
  expect(k?.event === 'CASE_OPENED' && k.status === 'Sent' && k.message.startsWith('Dear Ava,') && k.message.includes(kase.case_number),
    'no case-opened update with the reference');
});

await step('Case journey: task blocks resolve; customer-facing task and resolution send updates; closed', async () => {
  expect((await must('POST', `/ws/cases/${kase.id}/advance`, {})).to === 'Open', 'not Open');
  const t = await must('POST', `/ws/cases/${kase.id}/tasks`, { short_description: 'Line test from the exchange',
    assignment_group: 'Network Operations', customer_note: 'we tested your line and found no fault on our network' });
  expect(t.task_number.startsWith('CTK'), 'no task number');
  await refused('POST', `/ws/cases/${kase.id}/advance`, { resolution: 'x' }, /Close the open task/);
  const done = await must('POST', `/ws/case-tasks/${t.id}/state`, { state: 'Closed' });
  expect(done.kci?.event === 'CASE_TASK_COMPLETED', 'no progress update for the task');
  await refused('POST', `/ws/cases/${kase.id}/advance`, {}, /resolution/i);
  const res = await must('POST', `/ws/cases/${kase.id}/advance`, { resolution: 'Replaced the faulty router power supply' });
  expect(res.to === 'Resolved' && res.kci?.event === 'CASE_RESOLVED', 'no resolved update');
  expect((await must('POST', `/ws/cases/${kase.id}/advance`, {})).to === 'Closed', 'not closed');
  const c = await must('GET', `/ws/cases/${kase.id}`);
  expect(c.slas.every((s) => s.state !== 'In Progress'), 'SLAs still running');
});

await step('Cancel a case: tasks and SLAs cancelled, no customer update', async () => {
  const r = await must('POST', '/ws/cases', { customer_name: 'Ava Johnson', customer_email: 'ava.johnson@example.com',
    description: 'Wants to upgrade to the 1 Gbps plan', type: 'Service Request', category: 'Change plan', priority: 'P4',
    short_description: 'Upgrade to 1 Gbps', assignment_group: 'Provisioning' });
  expect(!r.triage, 'no triage needed when the agent filled everything');
  await must('POST', `/ws/cases/${r.case.id}/tasks`, { short_description: 'Check line supports 1 Gbps', assignment_group: 'Network Operations' });
  const c = await must('POST', `/ws/cases/${r.case.id}/cancel`, { reason: 'Customer withdrew the request' });
  const d = await must('GET', `/ws/cases/${r.case.id}`);
  expect(c.state === 'Cancelled' && d.tasks.every((t) => t.state === 'Cancelled') && d.slas.every((s) => s.state !== 'In Progress'), 'left running');
  expect(d.kcis.length === 1, 'cancelling must not send an update');
});

let major, task;
await step('Major incident at M14 5RG links every open order there', async () => {
  major = await must('POST', '/major-incidents', { pincode: 'm14 5rg', description: 'Smoke test: fiber cut' });
  expect(major.affected >= 5, `expected >= 5 linked orders, got ${major.affected}`);
});
await step('Incident task: resolve blocked while open; Done informs every customer', async () => {
  task = await must('POST', `/incidents/${major.incident.id}/tasks`,
    { short_description: 'Dispatch splice crew', customer_note: 'Repair crew on site', assignment_group: 'Network Operations' });
  const r = await call('POST', `/incidents/${major.incident.id}/resolve`, { resolution: 'x' });
  expect(!r.ok && /task/i.test(r.data.error || ''), 'resolve should be refused with an open task');
  const d = await must('POST', `/tasks/${task.id}/state`, { state: 'Done' });
  expect(d.notified + d.held >= 5, `only ${d.notified + d.held} customers informed`);
  const res = await must('POST', `/incidents/${major.incident.id}/resolve`, { resolution: 'Cable spliced' });
  expect(res.resolved >= 5, `only ${res.resolved} resolved`);
});

await step('Metrics endpoint answers', async () => {
  const m = await must('GET', '/metrics');
  expect(m.kci.sent > 0, 'no updates counted');
});

// ---------------- workspace data (step 1c) ----------------
await step('Menu counts match the lists (orders, cases, requests, incidents, tasks)', async () => {
  const nav = await must('GET', '/ws/nav');
  const len = async (kind, view) => (await must('GET', `/ws/list/${kind}?view=${view}`)).length;
  expect(nav.orders.open === await len('orders', 'open'), 'open orders');
  expect(nav.orders.closed === await len('orders', 'closed') && nav.orders.cancelled === await len('orders', 'cancelled'), 'closed/cancelled orders');
  expect(nav.cases.new === await len('cases', 'new') && nav.cases.closed === await len('cases', 'closed'), 'cases');
  expect(nav.requests.new + nav.requests.open === await len('requests', 'active'), 'service requests');
  expect(nav.incidents.resolved + nav.incidents.closed === await len('incidents', 'closed'), 'incidents');
  expect(nav.tasks.open === await len('tasks', 'open') && nav.tasks.closed === await len('tasks', 'closed'), 'tasks');
});

await step('Lists carry SLA, current task and last update; open lists sorted by SLA risk; search works', async () => {
  const rows = await must('GET', '/ws/list/orders?view=open');
  expect(rows.every((r) => r.sla && 'current_task' in r && 'last_update' in r), 'missing columns');
  const rank = { breached: 3, at_risk: 2, on_track: 1, paused: 1, met: 0 };
  expect(rows.every((r, i) => i === 0 || rank[rows[i - 1].sla.health] >= rank[r.sla.health]), 'not sorted by risk');
  const found = await must('GET', '/ws/list/orders?view=open&q=james');
  expect(found.length === 1 && found[0].customer_name === 'James Carter', 'search failed');
  const tasks = await must('GET', '/ws/list/tasks?view=open');
  expect(['order_task', 'case_task'].every((k) => tasks.some((t) => t.kind === k)), 'task list should mix order and case tasks');
});

await step('Landing page data and AI briefing (items point at real records)', async () => {
  const h = await must('GET', '/ws/home');
  expect(h.orders.open >= 1 && Array.isArray(h.orders.stages) && h.feed.length > 0 && h.sla_health, 'home data incomplete');
  const b = await must('GET', '/ws/briefing?refresh=1');
  expect(Array.isArray(b.items) && b.items.length <= 3, 'bad briefing');
  const path = { order: '/ws/orders/', case: '/ws/cases/', incident: '/incidents/' };
  for (const i of b.items) await must('GET', path[i.record_type] + i.record_id);
});

await step('AI summary + next best action for an order, a case and an incident', async () => {
  for (const [type, id] of [['order', 1], ['case', 2], ['incident', major.incident.id]]) {
    const s = await must('POST', `/ws/records/${type}/${id}/summary`, {});
    expect(s.summary && s.next_best_action && ['low', 'medium', 'high'].includes(s.risk_level), `${type} summary incomplete`);
  }
});

await step('Copilot answers about a record', async () => {
  const r = await must('POST', '/ws/records/order/1/copilot', { question: 'Why has this not moved to Activation?' });
  expect(r.answer?.length > 20, 'no copilot answer');
});

await step('Draft email with AI, then the AI Reviewer checks it: clean email sent, leaking email held', async () => {
  const d = await must('POST', '/ws/records/case/2/email/draft', {});
  expect(d.to[0] === 'thomas.wright@example.com' && /^Dear Thomas,/.test(d.body) && d.subject.includes('CS0001002'), 'bad draft');
  const ok = await must('POST', '/ws/records/case/2/email/send', { to: d.to, subject: d.subject, body: d.body });
  expect(ok.status === 'Sent', `clean email not sent: ${ok.issues}`);
  const bad = await must('POST', '/ws/records/order/1/email/send', { to: 'james.carter@example.com', subject: 'Update',
    body: 'Dear James, your fault is logged as INC0009999 with our network team.' });
  expect(bad.status === 'Held', 'an email with an incident number must be held');
  const act = (await must('GET', '/ws/cases/2')).activities;
  expect(act.some((a) => a.entry_type === 'email' && a.author_type === 'agent'), 'sent email not in the activity');
});

// ---------------- record pages (step 3) ----------------
await step('Reply to customer is checked by the AI Reviewer; internal note stays internal', async () => {
  const ok = await must('POST', '/ws/records/order/1/reply', { message: 'Dear James, your engineer visit is confirmed. Thank you for your patience.', agent_name: 'Smoke Agent' });
  expect(ok.status === 'Sent', 'clean reply should be sent');
  const bad = await must('POST', '/ws/records/order/1/reply', { message: 'Dear James, see INC0001234 for the details.' });
  expect(bad.status === 'Held', 'a reply with an incident number must be held');
  await must('POST', '/ws/records/order/1/note', { message: 'Smoke note for the team only', agent_name: 'Smoke Agent' });
  const customer = JSON.stringify(await must('GET', '/orders/1'));
  expect(customer.includes('your engineer visit is confirmed') && !customer.includes('Smoke note for the team only') && !customer.includes('INC0001234'), 'customer view wrong');
});

await step('Incident record: stages, activity and customer updates for a major incident', async () => {
  const i = await must('GET', `/ws/incidents/${major.incident.id}`);
  expect(i.stages.join() === 'New,Open,Resolved,Closed' && i.children.length >= 5, 'bad incident record');
  expect(i.activities.some((a) => /Major incident raised/.test(a.message)), 'major incident event missing');
  expect(i.kcis.length >= 5, 'customer updates of the linked orders missing');
});

// ---------------- AI chat (needs a key) ----------------
await step('Plan Advisor answers (AI)', async () => {
  const r = await must('POST', '/advisor/chat', { message: 'I work from home, two floors, postcode M14 5RG. Which plan?', history: [] });
  expect(r.answer, 'no advisor reply');
}, { aiOnly: true });

await step('Order Assistant answers (AI)', async () => {
  const r = await must('POST', '/orders/1/chat', { question: 'When is my engineer coming?' });
  expect(r, 'no bot reply');
}, { aiOnly: true });

await step('Order Assistant hands over: a case is opened and the customer gets the reference (AI)', async () => {
  const r = await must('POST', '/orders/1/chat', { question: 'This is taking far too long, I want to cancel my order and speak to a person.' });
  expect(r.needs_agent && r.case?.case_number && r.answer.message.includes(r.case.case_number), 'no handover case');
}, { aiOnly: true });

console.log(`\n${pass} passed, ${fail} failed, ${skip} skipped`);
process.exitCode = fail ? 1 : 0;
