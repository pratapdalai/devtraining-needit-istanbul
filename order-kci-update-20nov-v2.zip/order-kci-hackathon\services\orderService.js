import { query } from '../db/index.js';
import { nextNumber } from './serviceManager.js';
import { sendKci } from './kciService.js';
import { addEntry, logEvent, getActivities } from './journalService.js';
import { priceQuote } from './pricingService.js';
import { assertAvailable, findArea } from './coverageService.js';
import { validateOrder } from './orderAgent.js';
import { startSla, stopSla, slaView, pauseSla, resumeSla } from './slaService.js';
import { slotsFrom, slotDate, slotEnd, earliestVisitDate } from './visitService.js';
import { atTime, dayStart, dayEnd, readyBy, courierWindow, slotWindows } from './calendar.js';
import { decide, linkKci } from './kciDecisionAgent.js';
import { decideStage } from './stageAgent.js';
import { settings, customerReason, falloutReason } from './settings.js';
import { day, dayTime, nextWorkingDay, addWorkingDays, atHour, shortDay } from './format.js';

// ORDER JOURNEY (no case is created for an order):
//   Created -> Validation (AI Order Agent) -> Fulfilment (tasks) -> Activation (task) -> Completed
// Customer updates (KCI, AI-written) are sent only at task milestones and at completion.
// The AI Stage Agent moves the order to the next stage as soon as every task of the current stage is closed
// (or holds it for a person, who can still move it with "Move to ...").

const DONE = ['Closed', 'Cancelled'];
const ENDED = ['Completed', 'Closed', 'Cancelled'];

async function loadOrder(orderId) {
  const o = (await query(
    `SELECT o.*, p.name AS product_name, p.code AS product_code, p.category, p.stages, p.headline, p.unit
       FROM orders o JOIN products p ON p.id = o.product_id WHERE o.id = $1`, [orderId]
  )).rows[0];
  if (!o) throw new Error('Order not found');
  return o;
}
const tasksOf = async (orderId) => (await query(`SELECT * FROM order_tasks WHERE order_id = $1 ORDER BY seq`, [orderId])).rows;
const openIncidentOf = async (orderId) =>
  (await query(`SELECT * FROM incidents WHERE order_id = $1 AND state IN ('New', 'Open') LIMIT 1`, [orderId])).rows[0] || null;

// ---------------- TASKS ----------------

async function openTask(task) {
  const t = (await query(
    `UPDATE order_tasks SET state = 'Open', opened_at = now() WHERE id = $1 RETURNING *`, [task.id]
  )).rows[0];
  await startSla('order_task', t.id, { VALIDATION: 'TASK_VALIDATION', CPE_DELIVERY: 'TASK_CPE', ENGINEER_VISIT: 'TASK_ENGINEER', ACTIVATION: 'TASK_ACTIVATION' }[t.task_type], t.order_id);
  await logEvent({ orderId: t.order_id }, `Task ${t.task_number} ${t.name} opened for ${t.assignment_group}.`);
  return t;
}

// Close a task, stop its SLA, and open the next task of the same stage (tasks are worked in order)
async function closeTask(task, milestone, extraDetails = {}) {
  const t = (await query(
    `UPDATE order_tasks SET state = 'Closed', closed_at = now(), milestone = $2, details = details || $3::jsonb
      WHERE id = $1 RETURNING *`, [task.id, milestone, JSON.stringify(extraDetails)]
  )).rows[0];
  await stopSla('order_task', t.id, 'Completed');
  await logEvent({ orderId: t.order_id }, `Task ${t.task_number} ${t.name} closed (${milestone}).`);
  await cascade(t, new Date(t.closed_at));                       // the next tasks re-plan from the ACTUAL completion
  const next = (await query(
    `SELECT * FROM order_tasks WHERE order_id = $1 AND stage = $2 AND state = 'Pending' ORDER BY seq LIMIT 1`, [t.order_id, t.stage]
  )).rows[0];
  if (next) await openTask(next);
  return t;
}

// A milestone inside a task (e.g. "Scheduled"): the task is now In Progress
async function markMilestone(task, milestone, details) {
  return (await query(
    `UPDATE order_tasks SET state = 'In Progress', milestone = $2, details = details || $3::jsonb WHERE id = $1 RETURNING *`,
    [task.id, milestone, JSON.stringify(details)]
  )).rows[0];
}

// The speed an engineer measures on the day (about 95% of the line speed)
function measuredSpeed(o) {
  if (o.product_code === 'FIBER1G') return 940;
  const base = (o.addons || []).some((a) => a.code === 'SPEED300') ? 300 : Number(o.headline);
  return Math.round(base * settings.demoSpeedShare);
}

// ---------------- PLAN AND DEPENDENCIES ----------------
// Every customer-impacting task has a plan (planned start/end). A task can DEPEND ON another one:
// the engineer visit depends on the equipment delivery; activation depends on the visit (or on the delivery).

// Re-plan the tasks that depend on `task` from its (new) end date.
//  - A BOOKED engineer visit (agreed with the customer) never moves earlier; if it is now too early it is rebooked
//    to the first free slot after the new date.
//  - Unbooked tasks simply follow the task before them (later or earlier).
// Returns what moved.
async function cascade(task, newEnd, moved = []) {
  const deps = (await query(
    `SELECT * FROM order_tasks WHERE depends_on = $1 AND state NOT IN ('Closed', 'Cancelled')`, [task.id]
  )).rows;
  for (const d of deps) {
    // the engineer comes the working day after the equipment arrives; activation can start as soon as the visit is done
    const earliest = d.task_type === 'ENGINEER_VISIT' ? atTime(nextWorkingDay(newEnd), slotWindows()[0].start) : new Date(newEnd);
    if (d.task_type === 'ENGINEER_VISIT' && d.details?.slot) {
      const at = slotDate(d.details.slot);
      if (at && at >= atHour(earliest, 0)) continue;             // the booked slot still works: keep it
      const slot = slotsFrom(atHour(earliest, 0), 1)[0];
      const start = slotDate(slot); const end = slotEnd(slot);
      const t = (await query(
        `UPDATE order_tasks SET planned_start = $2, planned_end = $3, details = details || $4::jsonb WHERE id = $1 RETURNING *`,
        [d.id, start, end, JSON.stringify({ slot })]
      )).rows[0];
      await query(`UPDATE orders SET visit_slot = $2, updated_at = now() WHERE id = $1`, [d.order_id, slot]);
      moved.push({ task: d.name, from: d.details.slot, to: slot, rebooked: true });
      await cascade(t, end, moved);
      continue;
    }
    const start = d.planned_start ? new Date(d.planned_start) : null;
    if (start && Math.abs(start - earliest) < 60000) continue;  // already follows the task before it
    const shift = start ? earliest - start : 0;
    // activation is done by its ready-by time on the next working day; other tasks keep their length
    const end = d.task_type === 'ACTIVATION' ? readyBy(nextWorkingDay(earliest))
      : d.planned_end ? new Date(new Date(d.planned_end).getTime() + shift) : dayEnd(earliest);
    const t = (await query(`UPDATE order_tasks SET planned_start = $2, planned_end = $3 WHERE id = $1 RETURNING *`, [d.id, earliest, end])).rows[0];
    if (shift > 0) moved.push({ task: d.name, from: d.planned_end ? shortDay(d.planned_end) : null, to: shortDay(end) });
    await cascade(t, end, moved);
  }
  return moved;
}

// When a date is AGREED (delivery scheduled, visit booked), the current plan becomes the baseline for tasks that
// have not been delayed: "was 22 Nov" is only shown after a real delay.
async function rebaseline(orderId) {
  await query(
    `UPDATE order_tasks SET original_planned_end = planned_end
      WHERE order_id = $1 AND delayed_at IS NULL AND state NOT IN ('Closed', 'Cancelled')`, [orderId]
  );
}

// The date the whole order is now expected to be ready (the latest planned end of the remaining work)
async function orderEta(orderId) {
  const r = (await query(
    `SELECT max(planned_end) AS eta FROM order_tasks WHERE order_id = $1 AND state NOT IN ('Closed', 'Cancelled')`, [orderId]
  )).rows[0];
  return r.eta ? shortDay(r.eta) : null;
}

// A task is late (reported by an agent, or its SLA breached). Code calculates the revised dates and moves the
// dependent tasks; the AI KCI Decision Agent decides what the customer must hear; the KCI Writer writes ONE update.
// customer_reason: a reason from the list (Fallout scenario 2), customer_reason_text: optional words for the customer.
// Both may be shown to the customer; "reason" is the internal note and never is.
export async function reportDelay(taskId, { days, reason, customer_reason, customer_reason_text, trigger = 'agent', by = 'agent' } = {}) {
  const task = (await query(`SELECT * FROM order_tasks WHERE id = $1`, [taskId])).rows[0];
  if (!task) throw new Error('Task not found');
  const o = await loadOrder(task.order_id);
  if (o.status !== 'In Progress') throw new Error(`The order is ${o.status.toLowerCase()}`);
  if (!['Open', 'In Progress', 'Pending'].includes(task.state)) throw new Error('This task is already closed');
  if (!task.customer_impact) throw new Error('This is an internal task: delays are handled without a customer update');
  if (!reason?.trim()) throw new Error('Give the reason for the delay (internal)');
  const n = Math.min(settings.delayMaxDays, Math.max(1, Math.round(Number(days) || 1)));

  const now = new Date();
  const oldEnd = task.planned_end ? new Date(task.planned_end) : now;
  let newEnd = dayEnd(addWorkingDays(oldEnd > now ? oldEnd : now, n));
  const extra = {};
  const facts = { task: task.name, old_date: shortDay(oldEnd), new_date: shortDay(newEnd), delayed_by_working_days: n };
  const shareable = customerReason(customer_reason, customer_reason_text);
  if (shareable) { facts.customer_reason = shareable; extra.customer_reason = shareable; }
  if (task.task_type === 'CPE_DELIVERY' && task.milestone === 'Scheduled') extra.delivery_date = day(newEnd);
  if (task.task_type === 'ENGINEER_VISIT' && task.details?.slot) {
    const slot = slotsFrom(atHour(newEnd, 0), 1)[0];
    newEnd = slotEnd(slot);
    Object.assign(facts, { old_date: task.details.slot, new_date: slot });
    extra.slot = slot;
    await query(`UPDATE orders SET visit_slot = $2, updated_at = now() WHERE id = $1`, [o.id, slot]);
  }
  const t = (await query(
    `UPDATE order_tasks SET planned_end = $2, original_planned_end = COALESCE(original_planned_end, $3),
            delay_reason = $4, delayed_at = now(), details = details || $5::jsonb WHERE id = $1 RETURNING *`,
    [task.id, newEnd, task.planned_end, reason.trim(), JSON.stringify(extra)]
  )).rows[0];
  const moved = await cascade(t, newEnd);
  Object.assign(facts, { moved, order_eta: await orderEta(o.id) });
  await logEvent({ orderId: o.id }, `Task ${t.task_number} ${t.name} delayed by ${n} working day${n > 1 ? 's' : ''} (${by}): ${reason.trim()}. ` +
    (shareable ? `Reason for the customer: ${shareable}. ` : '') +
    `New date ${facts.new_date} (was ${facts.old_date}).${moved.length ? ` Moved: ${moved.map((m) => `${m.task} ${m.from || ''} → ${m.to}`).join('; ')}.` : ''}`);

  // The AI decides what the customer must hear (a delay is always told: guardrail in code)
  const sla = (await query(`SELECT * FROM slas WHERE record_type = 'order_task' AND record_id = $1 ORDER BY id DESC LIMIT 1`, [t.id])).rows[0];
  const decision = await decide({ situation: 'DELAYED', trigger, order: o,
    task: { ...t, sla_pct_used: sla ? slaView(sla).pct_used : null }, facts: { ...facts, internal_reason: reason.trim() } });
  await logEvent({ orderId: o.id }, `Decided: ${decision.action} (${decision.update_type}). ${decision.reason}`, 'AI KCI Decision Agent');
  const kci = await sendKci({ orderId: o.id }, 'TASK_DELAYED', { orderTask: t, facts, decision });
  await linkKci(decision.id, kci.id);
  return { task: t, facts, decision, kci };
}

// Book (or move) the engineer visit -> AI update to the customer. Used by agents and by the Order Assistant.
export async function bookEngineer(orderId, slot, { by = 'agent' } = {}) {
  const o = await loadOrder(orderId);
  const task = (await query(
    `SELECT * FROM order_tasks WHERE order_id = $1 AND task_type = 'ENGINEER_VISIT' AND state IN ('Open', 'In Progress')`, [o.id]
  )).rows[0];
  if (!task) throw new Error('There is no engineer visit to book yet: it can be booked once the equipment delivery is scheduled.');
  const at = slotDate(slot);
  if (!at) throw new Error('That slot is not available. Please choose one of the offered slots.');
  const earliest = await earliestVisitDate(o.id);
  if (at < earliest) throw new Error(`The engineer can come from ${shortDay(earliest)}, after your equipment arrives. Please choose a later slot.`);
  const moving = task.milestone === 'Scheduled';
  const mesh = (o.addons || []).some((a) => a.code === 'MESH') || o.product_code === 'FIBER1G';
  const end = slotEnd(slot);
  await query(`UPDATE order_tasks SET planned_start = $2, planned_end = $3 WHERE id = $1`, [task.id, at, end]);
  const t = await markMilestone(task, 'Scheduled', {
    slot, duration: 'about 90 minutes',
    work: `connect your fibre line and set up your router${mesh ? ' and Mesh Wi-Fi extender' : ''}`,
  });
  await query(`UPDATE orders SET visit_slot = $2, updated_at = now() WHERE id = $1`, [o.id, slot]);
  await cascade(t, end);                                         // activation follows the visit
  if (!moving) await rebaseline(o.id);                           // the booked slot IS the plan (not a delay)
  await logEvent({ orderId: o.id }, `Engineer visit ${moving ? 'moved' : 'booked'} to ${slot} by ${by}.`);
  const kci = await sendKci({ orderId: o.id }, moving ? 'VISIT_RESCHEDULED' : 'ENGINEER_APPOINTMENT_SCHEDULED', { orderTask: t });
  return { task: t, kci };
}

// ---------------- FALLOUT SCENARIO 1 (Ankit): the engineer cannot complete the visit ----------------
// e.g. no free port at the hub. CODE raises the ticket, puts the task and the order On Hold, pauses the SLA clocks
// and calculates the new dates (fix date -> engineer revisit -> activation -> order ETA). The AI KCI Decision Agent
// decides what the customer must hear, the KCI Writer writes ONE update, the Reviewer checks it.
async function engineerFallout(task, o, { problem, customer_reason_text, reason, fix_days } = {}) {
  if (!settings.engineerFallout) throw new Error('"Can\'t complete" is switched off (fallout.enabled in config/business-rules.json)');
  if (task.milestone !== 'Scheduled') throw new Error('Book the engineer visit first');
  if (!reason?.trim()) throw new Error('Write the internal note: what the engineer found');
  const n = Math.min(30, Math.max(1, Math.round(Number(fix_days) || settings.falloutFixDays)));
  const shareable = falloutReason(problem, customer_reason_text);
  const what = problem && !/^Other/.test(problem) ? problem : 'Engineer could not complete the visit';

  // 1. The ticket for the fix (no update from it: this flow sends one combined update below)
  const { raiseIncident } = await import('./incidentService.js');
  // The engineer found the problem ON the visit day: the fix time counts from the visit (or from now, if later)
  const visitAt = task.planned_start ? new Date(task.planned_start) : new Date();
  const fixAt = dayEnd(addWorkingDays(visitAt > new Date() ? visitAt : new Date(), n));
  const { incident } = await raiseIncident(o.id, `${what}: ${reason.trim()}`, {
    priority: settings.falloutPriority, assignment_group: settings.falloutTeam, notify: false,
  });
  await query(`UPDATE incidents SET order_task_id = $2, expected_fix_at = $3 WHERE id = $1`, [incident.id, task.id, fixAt]);

  // 2. New dates: the engineer comes back the working day after the fix, in the first free slot
  const slot = slotsFrom(atHour(nextWorkingDay(fixAt), 0), 1)[0];
  const start = slotDate(slot); const end = slotEnd(slot);
  const t = (await query(
    `UPDATE order_tasks SET state = 'On Hold', milestone = 'On hold', planned_start = $2, planned_end = $3,
            original_planned_end = COALESCE(original_planned_end, planned_end), delay_reason = $4, delayed_at = now(),
            details = details || $5::jsonb
      WHERE id = $1 RETURNING *`,
    [task.id, start, end, `${what}: ${reason.trim()}`, JSON.stringify({ slot, customer_reason: shareable, fix_by: shortDay(fixAt), problem: what })]
  )).rows[0];
  await query(`UPDATE orders SET visit_slot = $2, updated_at = now() WHERE id = $1`, [o.id, slot]);
  const moved = await cascade(t, end);                            // activation follows the revisit

  // 3. SLA clocks pause while we wait for the fix (no false "late" alarms)
  if (settings.falloutPauseSla) { await pauseSla('order_task', t.id); await pauseSla('order', o.id); }

  const facts = { task: t.name, customer_reason: shareable, fix_by: shortDay(fixAt), old_date: task.details?.slot,
    new_date: slot, moved, order_eta: await orderEta(o.id) };
  await logEvent({ orderId: o.id, incidentId: incident.id },
    `${t.name} could not be completed: ${what}. Ticket ${incident.incident_number} for ${settings.falloutTeam}, fix expected ${facts.fix_by}. ` +
    `Task and order On Hold${settings.falloutPauseSla ? ', SLA clocks paused' : ''}. Revisit ${slot}; ready by ${facts.order_eta}.`);

  // 4. The AI decides what the customer must hear; ONE update
  const decision = await decide({ situation: 'DELAYED', trigger: 'engineer', order: o, task: t, facts: { ...facts, internal_reason: reason.trim() } });
  await logEvent({ orderId: o.id }, `Decided: ${decision.action} (${decision.update_type}). ${decision.reason}`, 'AI KCI Decision Agent');
  const kci = await sendKci({ orderId: o.id }, 'ENGINEER_FALLOUT', { orderTask: t, facts, decision });
  await linkKci(decision.id, kci.id);
  return { task: t, incident, facts, decision, kci };
}

// The fallout ticket is resolved: the engineer task and the order continue, the SLA clocks resume, and the
// customer is told the revisit is confirmed. Called by resolveIncident. Returns the update, or null if not a fallout.
export async function resumeFallout(incident) {
  if (!incident.order_task_id) return null;
  const task = (await query(`SELECT * FROM order_tasks WHERE id = $1 AND state = 'On Hold'`, [incident.order_task_id])).rows[0];
  if (!task) return null;
  const o = await loadOrder(task.order_id);
  // the fix took longer than planned and the revisit slot has passed: first free slot from the next working day
  let slot = task.details?.slot;
  if (!slot || !slotDate(slot) || slotDate(slot) < new Date()) slot = slotsFrom(atHour(nextWorkingDay(), 0), 1)[0];
  const start = slotDate(slot); const end = slotEnd(slot);
  const t = (await query(
    `UPDATE order_tasks SET state = 'In Progress', milestone = 'Scheduled', planned_start = $2, planned_end = $3,
            details = details || $4::jsonb WHERE id = $1 RETURNING *`,
    [task.id, start, end, JSON.stringify({ slot })]
  )).rows[0];
  await query(`UPDATE orders SET visit_slot = $2, updated_at = now() WHERE id = $1`, [o.id, slot]);
  await cascade(t, end);
  await resumeSla('order_task', t.id); await resumeSla('order', o.id);
  const facts = { task: t.name, slot, order_eta: await orderEta(o.id) };
  await logEvent({ orderId: o.id, incidentId: incident.id }, `Fix done: ${t.name} back in progress, revisit ${slot}, SLA clocks resumed. Ready by ${facts.order_eta}.`);
  return sendKci({ orderId: o.id }, 'FALLOUT_CLEARED', { orderTask: t, facts });
}

// Agent works a task: each milestone sends an AI-written update to the customer
//   CPE_DELIVERY:   schedule -> deliver        ENGINEER_VISIT: schedule -> complete
//   ACTIVATION:     activate                   VALIDATION:     approve (when the AI asked for a human review)
export async function taskAction(taskId, input = {}) {
  const r = await workTask(taskId, input);
  // a task closed -> the stage may be finished: the AI Stage Agent decides whether the order moves on
  if (r.task?.state === 'Closed') r.stage_decision = await autoAdvance(r.task.order_id, `${r.task.name} closed`);
  return r;
}

async function workTask(taskId, { action, date, slot, speed_mbps, days, reason, customer_reason, customer_reason_text, problem, fix_days } = {}) {
  const task =(await query(`SELECT * FROM order_tasks WHERE id = $1`, [taskId])).rows[0];
  if (!task) throw new Error('Task not found');
  const o = await loadOrder(task.order_id);
  if (ENDED.includes(o.status)) throw new Error(`This order is ${o.status.toLowerCase()}`);
  if (o.status === 'On Hold') throw new Error('The order is on hold: resolve the open incident first');
  if (action === 'delay') return reportDelay(task.id, { days, reason, customer_reason, customer_reason_text, trigger: 'agent', by: 'agent' });
  if (task.state === 'Pending') throw new Error('This task starts when the task it depends on is scheduled or closed');
  if (DONE.includes(task.state)) throw new Error('This task is already closed');
  const target = { orderId: o.id };

  switch (`${task.task_type}:${action}`) {
    case 'VALIDATION:approve': {
      const t = await closeTask(task, 'Approved by agent');
      await query(`UPDATE orders SET needs_attention = false WHERE id = $1`, [o.id]);
      return { task: t, kci: null };
    }
    case 'CPE_DELIVERY:schedule': {
      if (task.milestone) throw new Error('The delivery is already scheduled');
      // default: the planned delivery day (or the next working day if the plan is already in the past)
      const planned = task.planned_end && new Date(task.planned_end) > new Date() ? new Date(task.planned_end) : nextWorkingDay();
      const when = date ? new Date(date) : planned;
      if (Number.isNaN(when.getTime())) throw new Error('Choose a valid delivery date');
      const end = dayEnd(when);
      await query(`UPDATE order_tasks SET planned_end = $2 WHERE id = $1`, [task.id, end]);
      const t = await markMilestone(task, 'Scheduled', {
        delivery_date: day(when), delivery_window: courierWindow(), courier: 'NovaTel Courier',
        tracking_ref: `NVT${String(48213900 + task.id * 37).padStart(8, '0')}`,
      });
      await cascade(t, end);
      if (!task.delayed_at) await rebaseline(o.id);              // the agreed delivery day IS the plan (not a delay)
      // the engineer visit can now be booked (it depends on this delivery)
      const dep = (await query(`SELECT * FROM order_tasks WHERE depends_on = $1 AND state = 'Pending' AND stage = $2`, [t.id, t.stage])).rows[0];
      if (dep) await openTask(dep);
      return { task: t, kci: await sendKci(target, 'CPE_DELIVERY_SCHEDULED', { orderTask: t }) };
    }
    case 'CPE_DELIVERY:deliver': {
      if (task.milestone !== 'Scheduled') throw new Error('Schedule the delivery first');
      const t = await closeTask(task, 'Delivered', { delivered_at: dayTime(new Date()) });
      return { task: t, kci: await sendKci(target, 'CPE_DELIVERED', { orderTask: t }) };
    }
    case 'ENGINEER_VISIT:schedule':
      return bookEngineer(o.id, slot || slotsFrom(await earliestVisitDate(o.id), 1)[0]);
    case 'ENGINEER_VISIT:cant_complete':
      return engineerFallout(task, o, { problem, customer_reason_text, reason, fix_days });
    case 'ENGINEER_VISIT:complete': {
      if (task.milestone !== 'Scheduled') throw new Error('Book the engineer visit first');
      const dep = task.depends_on && (await query(`SELECT * FROM order_tasks WHERE id = $1`, [task.depends_on])).rows[0];
      if (dep && dep.state !== 'Closed') throw new Error(`Mark the ${dep.name.toLowerCase()} done first: the engineer needs the equipment`);
      const t = await closeTask(task, 'Visit completed', { speed_mbps: Number(speed_mbps) || measuredSpeed(o) });
      return { task: t, kci: await sendKci(target, 'ENGINEER_VISIT_COMPLETED', { orderTask: t }) };
    }
    case 'ACTIVATION:activate': {
      const t = await closeTask(task, 'Activated', { activated_at: dayTime(new Date()) });
      return { task: t, kci: await sendKci(target, 'SERVICE_ACTIVATED', { orderTask: t }) };
    }
    default:
      throw new Error(`"${action}" is not a valid action for ${task.name}`);
  }
}

// ---------------- VALIDATION (AI Order Agent) ----------------

async function runValidation(order, { useAi = true } = {}) {
  await query(`UPDATE orders SET current_stage = 'Validation', stage_entered_at = now() WHERE id = $1`, [order.id]);
  await query(`INSERT INTO order_stage_history (order_id, from_stage, to_stage, note) VALUES ($1, 'Created', 'Validation', 'Automatic')`, [order.id]);

  const o = await loadOrder(order.id);
  const v = await validateOrder(o, { code: o.product_code, category: o.category }, { useAi });
  await query(`UPDATE orders SET validation = $2 WHERE id = $1`, [o.id, JSON.stringify(v)]);

  // the validation task (owned by the AI Order Agent, internal: no customer impact)
  const now = new Date();
  const vt = (await query(
    `INSERT INTO order_tasks (task_number, order_id, seq, task_type, stage, name, assignment_group, assigned_to, work_notes,
                              planned_start, planned_end, original_planned_end, customer_impact)
     VALUES ($1, $2, 1, 'VALIDATION', 'Validation', 'Order validation', 'Order Validation', 'AI Order Agent', $3, $4, $5, $5, false) RETURNING *`,
    [await nextNumber('order_tasks', 'OTK'), o.id, v.issues.join(' | ') || null, now, new Date(now.getTime() + 4 * 3600000)]
  )).rows[0];

  // THE PLAN (code): delivery in the area's usual time, the engineer the working day after, activation after that.
  // Each task depends on the one before it.
  const area = await findArea(o.pincode);
  const deliveryDays = Math.max(1, area?.install_days || 2);
  let prev = null;
  for (const [i, t] of v.plan.entries()) {
    let start; let end;
    // dates from the working calendar (config/business-rules.json)
    const firstSlot = slotWindows()[0];
    if (t.task_type === 'CPE_DELIVERY') { start = dayStart(nextWorkingDay(now)); end = dayEnd(addWorkingDays(now, deliveryDays)); }
    else if (t.task_type === 'ENGINEER_VISIT') { start = atTime(nextWorkingDay(prev.end), firstSlot.start); end = atTime(start, firstSlot.end); }
    else { start = new Date(prev.end); end = readyBy(nextWorkingDay(prev.end)); }        // ACTIVATION
    const notes = t.task_type === 'ENGINEER_VISIT' ? v.engineer_note : t.task_type === 'CPE_DELIVERY' ? v.delivery_note : '';
    const row = (await query(
      `INSERT INTO order_tasks (task_number, order_id, seq, task_type, stage, name, assignment_group, details, work_notes,
                                planned_start, planned_end, original_planned_end, customer_impact, depends_on)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $11, true, $12) RETURNING id`,
      [await nextNumber('order_tasks', 'OTK'), o.id, i + 2, t.task_type, t.stage, t.name, t.group, JSON.stringify(t.details),
       notes || null, start, end, prev?.id ?? null]
    )).rows[0];
    prev = { id: row.id, end };
  }
  await openTask(vt);

  const checks = v.checks.map((c) => `${c.name} ${c.ok ? '✓' : '✗'}`).join(' · ');
  if (v.verdict === 'PASS') {
    await closeTask(vt, 'Validated');
    await logEvent({ orderId: o.id }, `Order validated by AI Order Agent: ${checks}. Planned: ${v.plan.map((t) => t.name).join(' → ')}. Expected ready by ${shortDay(prev.end)}.`, 'AI Order Agent');
  } else {
    await query(`UPDATE orders SET needs_attention = true WHERE id = $1`, [o.id]);
    await addEntry({ orderId: o.id }, {
      author_type: 'bot', author_name: 'AI Order Agent', entry_type: 'work_note', visibility: 'internal', channel: 'System',
      message: `Needs review before fulfilment. ${v.summary} Issues: ${v.issues.join('; ')}`,
    });
  }
  if (v.engineer_note) {
    await addEntry({ orderId: o.id }, {
      author_type: 'bot', author_name: 'AI Order Agent', entry_type: 'work_note', visibility: 'internal', channel: 'System',
      message: `Note for the engineer: ${v.engineer_note}`,
    });
  }
  return v;
}

// ---------------- ORDER ----------------

// 1. Customer places an order -> order (no case) -> AI validation -> tasks planned. No customer update for this event.
//    useAi = false: rule-based validation (used for quick demo data)
export async function placeOrder(input, { useAi = true } = {}) {
  const { customer_name, customer_email, customer_phone, address, pincode, language, product_id, addon_codes, customer_needs } = input;
  if (!customer_name || !customer_email || !product_id) {
    throw new Error('customer_name, customer_email and product_id are required');
  }
  const product = (await query(`SELECT * FROM products WHERE id = $1`, [product_id])).rows[0];
  if (!product) throw new Error('Product not found');

  // Real-world rule: we only accept orders for services we can deliver at this postcode
  const area = await assertAvailable(pincode, product.category);
  // The price is always calculated by our code (base plan + add-ons - discount)
  const quote = await priceQuote(product.code, addon_codes || []);

  const n = (await query(`SELECT COALESCE(MAX(id), 0) + 1 AS n FROM orders`)).rows[0].n;
  const order = (await query(
    `INSERT INTO orders (order_number, customer_name, customer_email, customer_phone, address, language, product_id,
                         current_stage, addons, monthly_total_gbp, customer_needs, pincode)
     VALUES ($1,$2,$3,$4,$5,$6,$7,'Created',$8,$9,$10,$11) RETURNING *`,
    [`ORD-${1000 + Number(n)}`, customer_name.trim(), customer_email.trim(), customer_phone?.trim() || null,
     address?.trim() || null, language || 'English', product.id, JSON.stringify(quote.addons), quote.monthly_total_gbp,
     customer_needs ? String(customer_needs).slice(0, 500) : null, area?.pincode ?? null]
  )).rows[0];

  await query(`INSERT INTO order_stage_history (order_id, from_stage, to_stage, note) VALUES ($1, NULL, 'Created', 'Order submitted by customer')`, [order.id]);
  await logEvent({ orderId: order.id }, 'Order created by the customer on the website. No customer update for this event.');
  await startSla('order', order.id, 'ORDER_COMPLETE', order.id);

  const validation = await runValidation(order, { useAi });
  // validation passed -> the AI Stage Agent moves the order to Fulfilment (a failed one waits for a person)
  const stage_decision = validation.verdict === 'PASS' ? await autoAdvance(order.id, 'Order validation passed', { useAi }) : null;
  return { order: await loadOrder(order.id), validation, stage_decision };
}

// AI Stage Agent: when code allows the move (stage work done, no open incident), the AI decides MOVE or HOLD.
// Returns the decision, or null when the order cannot move yet.
async function autoAdvance(orderId, trigger, { useAi = true } = {}) {
  const o = await loadOrder(orderId);
  const tasks = await tasksOf(o.id);
  if (advanceBlock(o, tasks, await openIncidentOf(o.id))) return null;
  const to = o.stages[o.stages.indexOf(o.current_stage) + 1];
  const d = await decideStage({ order: o, tasks, from: o.current_stage, to, trigger, useAi });
  await logEvent({ orderId: o.id }, `${o.current_stage} work done (${trigger}). Decided: ${d.action}${d.action === 'MOVE' ? ` to ${to}` : ''}. ${d.reason}`, 'AI Stage Agent');
  if (d.action === 'HOLD') {
    await query(`UPDATE orders SET needs_attention = true WHERE id = $1`, [o.id]);
    await addEntry({ orderId: o.id }, {
      author_type: 'bot', author_name: 'AI Stage Agent', entry_type: 'work_note', visibility: 'internal', channel: 'System',
      message: `Held in ${o.current_stage}: ${d.reason} Check it, then use "Move to ${to}".`,
    });
    return { ...d, moved: false };
  }
  const moved = await advanceOrder(o.id, { by: 'AI Stage Agent' });
  return { ...d, moved: true, kci: moved.kci };
}

// Why the order cannot move on yet (null = it can)
function advanceBlock(o, tasks, openIncident) {
  if (ENDED.includes(o.status)) return `This order is ${o.status.toLowerCase()}`;
  if (openIncident) return `Resolve incident ${openIncident.incident_number} first`;
  if (o.current_stage === 'Created') return 'The order is being validated';
  const open = tasks.filter((t) => t.stage === o.current_stage && !DONE.includes(t.state));
  if (open.length) return `Close the ${open.map((t) => t.name).join(' and ')} task${open.length > 1 ? 's' : ''} first`;
  return null;
}

// 2. Move the order to its next stage (only when the current stage's tasks are closed).
//    Normally the AI Stage Agent does this; a person can too (e.g. after the agent held the order).
export async function advanceOrder(orderId, { by = 'agent' } = {}) {
  const o = await loadOrder(orderId);
  const block = advanceBlock(o, await tasksOf(o.id), await openIncidentOf(o.id));
  if (block) throw new Error(block);

  const from = o.current_stage;
  const to = o.stages[o.stages.indexOf(from) + 1];
  const completed = to === 'Completed';
  await query(
    `UPDATE orders SET current_stage = $2, status = $3, stage_entered_at = now(), updated_at = now(),
            completed_at = CASE WHEN $4 THEN now() ELSE completed_at END WHERE id = $1`,
    [o.id, to, completed ? 'Completed' : o.status, completed]
  );
  await query(`INSERT INTO order_stage_history (order_id, from_stage, to_stage, note) VALUES ($1, $2, $3, $4)`,
    [o.id, from, to, by === 'agent' ? null : 'Automatic']);           // the customer sees this history: no agent names
  if (by === 'agent') await query(`UPDATE orders SET needs_attention = false WHERE id = $1`, [o.id]);   // a person has checked it
  await logEvent({ orderId: o.id }, `Order moved from ${from} to ${to} by ${by}.`, by === 'agent' ? 'System' : by);

  let kci = null;
  if (completed) {
    await stopSla('order', o.id, 'Completed');
    kci = await sendKci({ orderId: o.id }, 'ORDER_COMPLETED', { previousStage: from });
  } else {
    const first = (await query(
      `SELECT * FROM order_tasks WHERE order_id = $1 AND stage = $2 AND state = 'Pending' ORDER BY seq LIMIT 1`, [o.id, to]
    )).rows[0];
    if (first) await openTask(first);
  }
  return { order_id: o.id, from, to, kci };
}

// 3. Cancel an open order: open tasks and SLAs are cancelled
export async function cancelOrder(orderId, reason) {
  const o = await loadOrder(orderId);
  if (ENDED.includes(o.status)) throw new Error(`This order is already ${o.status.toLowerCase()}`);
  if (!reason?.trim()) throw new Error('Give a reason for the cancellation');
  await query(`UPDATE orders SET status = 'Cancelled', cancelled_at = now(), cancel_reason = $2, updated_at = now() WHERE id = $1`, [o.id, reason.trim()]);
  for (const t of (await tasksOf(o.id)).filter((x) => !DONE.includes(x.state))) {
    await query(`UPDATE order_tasks SET state = 'Cancelled', closed_at = now() WHERE id = $1`, [t.id]);
    await stopSla('order_task', t.id, 'Cancelled');
  }
  await stopSla('order', o.id, 'Cancelled');
  await logEvent({ orderId: o.id }, `Order cancelled by agent: ${reason.trim()}`);
  return loadOrder(o.id);
}

// 4. Close a completed order (end of its life)
export async function closeOrder(orderId) {
  const o = await loadOrder(orderId);
  if (o.status !== 'Completed') throw new Error('Only a completed order can be closed');
  await query(`UPDATE orders SET status = 'Closed', closed_at = now(), updated_at = now() WHERE id = $1`, [o.id]);
  await logEvent({ orderId: o.id }, 'Order closed by agent.');
  return loadOrder(o.id);
}

// 5. Save: the fields an agent may correct
export async function saveOrder(orderId, { customer_email, customer_phone, address } = {}) {
  const o = await loadOrder(orderId);
  const email = customer_email?.trim() ?? o.customer_email;
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Enter a valid email address');
  if (address !== undefined && !address.trim()) throw new Error('The address cannot be empty');
  await query(
    `UPDATE orders SET customer_email = $2, customer_phone = $3, address = $4, updated_at = now() WHERE id = $1`,
    [o.id, email, customer_phone?.trim() ?? o.customer_phone, address?.trim() ?? o.address]
  );
  await logEvent({ orderId: o.id }, 'Customer details updated by agent.');
  return loadOrder(o.id);
}

// 6. Customer tracking page: public data only
export async function getOrder(orderId) {
  const o = await loadOrder(orderId).catch(() => null);
  if (!o) return null;
  o.history = (await query(`SELECT * FROM order_stage_history WHERE order_id = $1 ORDER BY id`, [o.id])).rows;
  o.kcis = (await query(
    `SELECT id, event, stage, mode, subject, message, next_update_by, created_at FROM kci_communications
      WHERE (order_id = $1 OR case_id IN (SELECT id FROM cases WHERE order_id = $1)) AND status = 'Sent' ORDER BY id DESC`, [o.id]
  )).rows; // order updates + updates about requests on this order; held updates are NOT shown to the customer
  // The customer sees each step with only customer-safe facts (never work notes, teams or staff)
  const SAFE = ['items', 'delivery_date', 'delivery_window', 'courier', 'tracking_ref', 'delivered_at', 'slot', 'duration', 'speed_mbps', 'activated_at'];
  o.steps = (await query(
    `SELECT task_type, name, stage, state, milestone, details, closed_at, planned_start, planned_end, original_planned_end FROM order_tasks
      WHERE order_id = $1 AND task_type <> 'VALIDATION' ORDER BY seq`, [o.id]
  )).rows.map((t) => ({ ...t, details: Object.fromEntries(Object.entries(t.details || {}).filter(([k]) => SAFE.includes(k))) }));
  o.eta = ['In Progress', 'On Hold'].includes(o.status) ? await orderEta(o.id) : null;   // expected ready date (the plan)
  o.requests = (await query(
    `SELECT case_number, type, category, state, created_at FROM cases WHERE order_id = $1 ORDER BY id DESC`, [o.id]
  )).rows;
  for (const k of ['validation', 'needs_attention', 'customer_needs', 'jeopardy_sent_stage', 'cancel_reason']) delete o[k];
  // CUSTOMER sees public entries only (filtered in SQL); no email/SMS copies on the portal
  o.journal = (await getActivities({ orderId: o.id }, { publicOnly: true })).filter((j) => !['email', 'sms'].includes(j.entry_type));
  return o;
}

// Customers find their order by its number (ORD-1001) on the tracking page
export async function findOrderId(number) {
  const r = (await query(`SELECT id FROM orders WHERE upper(order_number) = upper($1)`, [String(number || '').trim()])).rows[0];
  if (!r) throw new Error('We could not find that order number. It looks like ORD-1001.');
  return { id: r.id };
}

// 7. Agent workspace: everything about one order
export async function getOrderDetail(orderId) {
  const o = await loadOrder(orderId);
  const tasks = await tasksOf(o.id);
  const slas = (await query(`SELECT * FROM slas WHERE order_id = $1 ORDER BY id`, [o.id])).rows.map(slaView);
  const openIncident = await openIncidentOf(o.id);
  for (const t of tasks) {
    t.sla = slas.find((s) => s.record_type === 'order_task' && s.record_id === t.id) || null;
    const dep = tasks.find((x) => x.id === t.depends_on);
    t.depends_on_number = dep?.task_number || null; t.depends_on_name = dep?.name || null;
    t.slipped = !!(t.original_planned_end && t.planned_end && new Date(t.planned_end) - new Date(t.original_planned_end) > 3600000);
  }
  const block = advanceBlock(o, tasks, openIncident);
  return {
    ...o,
    tasks,
    slas,
    order_sla: slas.find((s) => s.record_type === 'order') || null,
    incidents: (await query(`SELECT * FROM incidents WHERE order_id = $1 ORDER BY id DESC`, [o.id])).rows,
    cases: (await query(`SELECT * FROM cases WHERE order_id = $1 ORDER BY id DESC`, [o.id])).rows,
    kcis: (await query(`SELECT * FROM kci_communications WHERE order_id = $1 ORDER BY id DESC`, [o.id])).rows,
    activities: await getActivities({ orderId: o.id }, { publicOnly: false }),
    history: (await query(`SELECT * FROM order_stage_history WHERE order_id = $1 ORDER BY id`, [o.id])).rows,
    decisions: (await query(`SELECT * FROM kci_decisions WHERE order_id = $1 ORDER BY id DESC`, [o.id])).rows,
    eta: await orderEta(o.id),
    can_advance: !block,
    advance_block: block,
    next_stage: ENDED.includes(o.status) ? null : o.stages[o.stages.indexOf(o.current_stage) + 1] || null,
  };
}
