// Small shared helpers for how we write names, dates and money to customers (UK style).

// Customers are addressed by first name in every message ("Dear James," not "Dear James Carter,").
export function firstName(fullName) {
  return String(fullName ?? '').trim().split(/\s+/)[0] || 'Customer';
}

// "Friday 20 November"
export const day = (d) => new Date(d).toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });

// "20 Nov, 4:32 pm"
export const dayTime = (d) => new Date(d).toLocaleString('en-GB',
  { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit', hour12: true });

// "£38.09"
export const gbp = (n) => '£' + Number(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// Working days come from the working calendar (config/business-rules.json)
export { nextWorkingDay, addWorkingDays } from './calendar.js';

// The same calendar day at a given hour (plans use 9:00 for starts and 18:00 for ends)
export function atHour(date, hour) {
  const d = new Date(date); d.setHours(hour, 0, 0, 0); return d;
}

// Whole calendar days between two dates (b - a)
export const daysBetween = (a, b) => Math.round((atHour(b, 12) - atHour(a, 12)) / 86400000);

// "Fri 20 Nov"
export const shortDay = (d) => new Date(d).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });
