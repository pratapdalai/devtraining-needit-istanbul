import { Router } from 'express';
import { getOrderDetail, advanceOrder, cancelOrder, closeOrder, saveOrder, taskAction } from '../services/orderService.js';
import { raiseIncident, startIncident, closeIncident } from '../services/incidentService.js';
import { createCase, getCaseDetail, advanceCase, cancelCase, saveCase, addCaseTask, setCaseTaskState } from '../services/caseService.js';
import { triage, CATEGORIES, TEAMS } from '../services/triageAgent.js';
import { agentEntry } from '../services/journalService.js';
import { availableSlots, availableSlotsForOrder } from '../services/visitService.js';
import { navCounts, listRecords, homeData } from '../services/workspaceService.js';
import { summarizeRecord, copilot, draftEmail, sendEmail, getBriefing, postReply, postNote } from '../services/assistAgent.js';
import { getIncidentDetail } from '../services/incidentService.js';
import { formSettings } from '../services/settings.js';

// Agent workspace API (prefix /api/ws)
const router = Router();

const handle = (fn, status = 200) => async (req, res) => {
  try {
    res.status(status).json(await fn(req));
  } catch (err) {
    console.error(err.message);
    res.status(400).json({ error: err.message });
  }
};
const id = (req) => Number(req.params.id);

// ---------------- WORKSPACE: menu counts, lists, landing page ----------------
router.get('/nav', handle(() => navCounts()));
router.get('/home', handle(() => homeData()));
router.get('/briefing', handle((req) => getBriefing({ refresh: req.query.refresh === '1' })));
// kind: orders | cases | requests | incidents | tasks;  ?view=open|new|resolved|closed|cancelled|completed|active &q= &stage=
router.get('/list/:kind', handle((req) => listRecords(req.params.kind, req.query)));

// ---------------- AI for every record: type = order | case | incident ----------------
router.post('/records/:type/:id/summary', handle((req) => summarizeRecord(req.params.type, id(req))));
router.post('/records/:type/:id/copilot', handle((req) => copilot(req.params.type, id(req), req.body)));
router.post('/records/:type/:id/email/draft', handle((req) => draftEmail(req.params.type, id(req), req.body)));
router.post('/records/:type/:id/email/send', handle((req) => sendEmail(req.params.type, id(req), req.body)));
router.post('/records/:type/:id/reply', handle((req) => postReply(req.params.type, id(req), req.body)));   // public, Reviewer-checked
router.post('/records/:type/:id/note', handle((req) => postNote(req.params.type, id(req), req.body), 201)); // internal

// ---------------- ORDER MANAGEMENT ----------------
router.get('/orders/:id', handle((req) => getOrderDetail(id(req))));
router.patch('/orders/:id', handle((req) => saveOrder(id(req), req.body)));                 // Save
router.post('/orders/:id/advance', handle((req) => advanceOrder(id(req))));                 // Move to next stage
router.post('/orders/:id/cancel', handle((req) => cancelOrder(id(req), req.body.reason)));
router.post('/orders/:id/close', handle((req) => closeOrder(id(req))));
router.post('/orders/:id/notes', handle((req) => agentEntry({ orderId: id(req) }, req.body), 201)); // reply or internal note
router.post('/orders/:id/incidents', handle((req) => raiseIncident(id(req), req.body.description, {
  testLeak: !!req.body.testLeak,
  priority: req.body.priority || 'P3',
  assignment_group: req.body.assignment_group || 'Field Engineering',
}), 201));

// Order task milestones: { action: schedule | deliver | complete | activate | approve, date?, slot?, speed_mbps? }
router.post('/order-tasks/:id/action', handle((req) => taskAction(id(req), req.body)));
router.get('/slots', handle((req) => (req.query.order_id ? availableSlotsForOrder(Number(req.query.order_id)) : availableSlots())));
// Switches from .env that the workspace forms need (e.g. the delay reasons list)
router.get('/settings', handle(() => formSettings()));

// ---------------- SERVICE MANAGEMENT ----------------
// Reference lists for forms
router.get('/case-options', handle(() => ({ categories: CATEGORIES, teams: TEAMS, priorities: ['P1', 'P2', 'P3', 'P4'] })));
// AI Triage Agent preview for the "New case" form: { text, order_id? }
router.post('/triage', handle((req) => triage(req.body.text)));

// Cases and Service Requests
router.post('/cases', handle((req) => createCase({ ...req.body, origin: 'Agent' }), 201));
router.get('/cases/:id', handle((req) => getCaseDetail(id(req))));
router.patch('/cases/:id', handle((req) => saveCase(id(req), req.body)));                    // Save
router.post('/cases/:id/advance', handle((req) => advanceCase(id(req), req.body)));          // Move to next stage { resolution? }
router.post('/cases/:id/cancel', handle((req) => cancelCase(id(req), req.body.reason)));
router.post('/cases/:id/notes', handle((req) => agentEntry({ caseId: id(req) }, req.body), 201));
router.post('/cases/:id/tasks', handle((req) => addCaseTask(id(req), req.body), 201));
router.post('/case-tasks/:id/state', handle((req) => setCaseTaskState(id(req), req.body.state)));

// Incidents (raise on an order above; tasks, resolve and major incidents under /api)
router.get('/incidents/:id', handle((req) => getIncidentDetail(id(req))));
router.post('/incidents/:id/start', handle((req) => startIncident(id(req), req.body.agent_name)));
router.post('/incidents/:id/close', handle((req) => closeIncident(id(req))));

export default router;
