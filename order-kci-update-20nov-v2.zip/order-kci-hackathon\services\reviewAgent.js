import { client, askJson } from './openaiClient.js';

// AI Reviewer: a second agent that checks every KCI draft BEFORE the customer sees it.
const REVIEW_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    verdict: { type: 'string', enum: ['PASS', 'FIXED', 'HOLD'] },
    issues: { type: 'array', items: { type: 'string' } },
    message: { type: 'string' },
    sms: { type: 'string' },
  },
  required: ['verdict', 'issues', 'message', 'sms'],
};

const INSTRUCTIONS = `
You are a strict quality reviewer for customer messages (KCI) of a telecom operator.
You receive a DRAFT (message + sms) and the CONTEXT it was written from.

Check the draft against these rules:
1. It must NOT reveal anything from "internal_notes" (staff, teams, escalations, shortages, systems,
   internal reasons) and must NOT contain incident numbers (like INC0001001). Case and request references
   (CS..., SR...) and order numbers (ORD-...) are FOR the customer: they are fine.
   "milestone.customer_reason" is NOT internal: our staff approved it for the customer, so the draft may and
   should say it (do not remove or soften it).
2. It must NOT invent dates, times, prices or causes that are not in the context.
3. It must be written in English (British spelling), polite and clear; sms at most 160 characters.
4. Only if "required_facts" is given and not empty: "message" must contain every value in it exactly as given
   (e.g. a tracking or case reference). Otherwise ignore this rule.
An empty "sms" means this message has no SMS (e.g. an agent's reply or email): that is fine, never an issue.
Judge only what the draft says; do not ask for facts it does not claim (a short, polite reply is fine).

Decide:
- PASS: the draft follows all rules. Return message and sms unchanged, issues = [].
- FIXED: you corrected the problems yourself (wording, spelling, length, a missing required fact). Return the
  corrected message and sms, and list the issues you fixed.
- HOLD: it cannot be fixed safely without a human (e.g. facts missing or contradictory). Return the draft unchanged
  and list the issues. If the draft reveals ANYTHING from "internal_notes" or an incident number, the verdict is
  always HOLD, never FIXED: the writer made a safety mistake and a person must see it.
`.trim();

// Simple rule-based guard that ALWAYS runs (also when there is no API key)
function ruleCheck(text, context) {
  const issues = [];
  if (/\bINC\d{4,}/i.test(text)) issues.push('Contains an internal incident number');
  for (const note of context.internal_notes || []) {
    const words = note.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').split(/\s+/).filter(Boolean);
    // any 4 words in a row from a note (ignoring dates/times, which may be shared) = a leak
    const clean = text.toLowerCase().replace(/[^a-z0-9\s-]/g, ' ').replace(/\s+/g, ' ');
    for (let i = 0; i + 4 <= words.length; i++) {
      const window = words.slice(i, i + 4);
      if (window.some((w) => /\d/.test(w))) continue;
      const phrase = window.join(' ');
      if (clean.includes(phrase)) {
        issues.push(`Repeats internal note text: "${phrase}"`);
        break;
      }
    }
  }
  return issues;
}

export async function reviewKci(draft, context) {
  let result = { verdict: 'PASS', issues: [], message: draft.message, sms: draft.sms };

  if (client) {
    try {
      const r = await askJson({
        instructions: INSTRUCTIONS,
        input: { draft: { message: draft.message, sms: draft.sms }, context },
        name: 'kci_review',
        schema: REVIEW_SCHEMA,
      });
      result = r.data;
    } catch (err) {
      console.error('OpenAI review failed, using rule check only:', err.message);
    }
  }

  // Safety net 1 (code, whatever the AI said): a draft that leaked internal text is ALWAYS held for a human,
  // even if the reviewer quietly removed the leak, and so is a final text that still breaks a hard rule.
  const draftLeak = ruleCheck(`${draft.message} ${draft.sms}`, context);
  const leftover = ruleCheck(`${result.message} ${result.sms}`, context);
  if (draftLeak.length || leftover.length) {
    const issues = [...new Set([...result.issues, ...draftLeak, ...leftover])];
    return { verdict: 'HOLD', issues, message: draft.message, sms: draft.sms };
  }

  // Safety net 2 (code): every required fact (tracking / case reference) must be in the message
  const missing = (context.required_facts || []).filter((f) => !result.message.includes(f.value));
  if (missing.length) {
    const added = missing.map((f) => `Your ${f.label} is ${f.value}.`).join(' ');
    result = {
      ...result,
      verdict: result.verdict === 'PASS' ? 'FIXED' : result.verdict,
      issues: [...result.issues, ...missing.map((f) => `Added the missing ${f.label}`)],
      message: `${result.message.trim()} ${added}`,
    };
  }
  return result;
}
