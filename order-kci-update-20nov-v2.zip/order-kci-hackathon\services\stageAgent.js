import { query } from '../db/index.js';
import { client, MODEL, askJson } from './openaiClient.js';
import { settings } from './settings.js';

// AI Stage Agent (Ankit's review: "moving the order to the next stage should be done by an AI agent").
// When the current stage's work is done, it decides: MOVE the order on now, or HOLD it for a person.
//   CODE decides whether a move is ALLOWED (every task of the stage closed, no open incident) - the AI is only
//   asked when it is, so it can never skip work. The AI judges what code cannot read: internal notes, customer
//   comments, open requests, a measured speed far below the plan. HOLD = flag for an agent (who can still move it).

const SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    action: { type: 'string', enum: ['MOVE', 'HOLD'] },
    reason: { type: 'string' },
  },
  required: ['action', 'reason'],
};

// The speed rule comes from config/business-rules.json (stage_agent.hold_below_speed_percent)
const pct = () => Math.round(settings.holdBelowSpeed * 100);
const INSTRUCTIONS = () => `
You are the Stage Agent of NovaTel, a telecom operator. An order has finished all the work of its current stage.
Code has already checked that every task of the stage is closed and no incident is open. You decide whether the
order moves to the next stage now (MOVE) or a person must look first (HOLD). Your output is INTERNAL.

MOVE is the normal answer: the work is done, so keep the order flowing. Choose HOLD only for a concrete reason
found in the input, for example:
- the engineer measured a speed well below the plan (measured_speed_mbps under ${pct()}% of plan_speed_mbps);
- an internal note or customer comment asks to wait, pause, change or cancel before the next step;
- an open request (case) on this order would change what the next stage does (e.g. a plan change or cancellation).
NOT reasons to hold: a thank-you, a general question, an old resolved request, or an instruction for work that
happens in a LATER stage (e.g. "confirm where the mesh goes" is for the engineer visit: moving on is how it gets done).
If you are unsure, MOVE: a person is told about every later delay anyway.
reason: one or two sentences for the agent's audit log, citing the fact you used.
`.trim();

// The line speed the customer pays for (broadband only)
function planSpeed(o) {
  if (o.category !== 'broadband') return null;
  if (o.product_code === 'FIBER1G') return 1000;
  if ((o.addons || []).some((a) => a.code === 'SPEED300')) return 300;
  return Number(o.headline) || null;
}

function ruleDecision(input) {
  const { measured_speed_mbps: m, plan_speed_mbps: p } = input.facts;
  if (m && p && m < p * settings.holdBelowSpeed) return { action: 'HOLD', reason: `Measured ${m} Mbps is below ${pct()}% of the ${p} Mbps plan: check the line before moving on.` };
  return { action: 'MOVE', reason: `All ${input.order.stage} work is done.` };
}

// order: loaded order (with product fields); tasks: its tasks; useAi = false for fast demo data
export async function decideStage({ order, tasks, from, to, trigger, useAi = true }) {
  const started = Date.now();
  const stageTasks = tasks.filter((t) => t.stage === from);
  const visit = tasks.find((t) => t.task_type === 'ENGINEER_VISIT' && t.state === 'Closed');
  const journal = (await query(
    `SELECT author_type, visibility, message FROM case_journal
      WHERE order_id = $1 AND entry_type IN ('comment', 'work_note') AND created_at >= $2 ORDER BY id DESC LIMIT 8`,
    [order.id, order.stage_entered_at || order.created_at]
  )).rows;
  const openCases = (await query(
    `SELECT case_number, type, category, short_description FROM cases
      WHERE order_id = $1 AND state NOT IN ('Resolved', 'Closed', 'Cancelled')`, [order.id]
  )).rows;

  const input = {
    trigger,
    order: { reference: order.order_number, plan: order.product_name, stage: from, next_stage: to, customer_needs: order.customer_needs },
    completed_tasks: stageTasks.map((t) => ({ name: t.name, result: t.milestone || t.state })),
    facts: {
      plan_speed_mbps: planSpeed(order),
      measured_speed_mbps: visit?.details?.speed_mbps ?? null,
    },
    // notes written by PEOPLE (agents); the AI agents' own notes, e.g. "Note for the engineer", are work instructions
    internal_notes: journal.filter((j) => j.visibility === 'internal' && j.author_type === 'agent').map((j) => j.message),
    customer_comments: journal.filter((j) => j.author_type === 'customer').map((j) => j.message),
    open_requests: openCases.map((c) => `${c.case_number} ${c.type} (${c.category || 'uncategorised'}): ${c.short_description}`),
  };

  let d = null; let ai = null;
  if (client && useAi) {
    try {
      const r = await askJson({ instructions: INSTRUCTIONS(), input, name: 'stage_decision', schema: SCHEMA });
      d = r.data; ai = { model: MODEL, latency_ms: r.latency_ms, total_tokens: r.total_tokens };
    } catch (err) { console.error('OpenAI stage decision failed, using rules:', err.message); }
  }
  d ||= ruleDecision(input);
  return { ...d, from, to, ai_source: ai ? 'openai' : 'rules', model: ai?.model ?? null,
    latency_ms: ai?.latency_ms ?? Date.now() - started, total_tokens: ai?.total_tokens ?? null };
}
