-- Migration 011: fallout scenario 1 (Ankit) - the engineer cannot complete the visit (e.g. no free port at the hub).
-- The engineer task goes On Hold, a ticket (incident) is raised for the fix, SLA clocks pause while on hold.
-- Safe to re-run.

-- 1. Order tasks can be On Hold
ALTER TABLE order_tasks DROP CONSTRAINT IF EXISTS order_tasks_state_check;
ALTER TABLE order_tasks ADD CONSTRAINT order_tasks_state_check
  CHECK (state IN ('Pending', 'Open', 'In Progress', 'On Hold', 'Closed', 'Cancelled'));

-- 2. SLA clocks can pause (the paused time is given back when they resume)
ALTER TABLE slas ADD COLUMN IF NOT EXISTS paused_at TIMESTAMPTZ;

-- 3. A fallout ticket knows the task it holds and when the fix is expected
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS order_task_id   INT REFERENCES order_tasks(id) ON DELETE SET NULL;
ALTER TABLE incidents ADD COLUMN IF NOT EXISTS expected_fix_at TIMESTAMPTZ;
