import { query } from '../db/index.js';
import { client, MODEL, askJson } from './openaiClient.js';

// AI KCI Decision Agent (Ankit's design): watches every order task's plan and SLA and decides what to tell the customer.
//   AT_RISK  (task close to missing its SLA): send a proactive update now, or wait?
//   DELAYED  (SLA breached, or an agent reported a delay): an update MUST be sent; the agent decides what it must cover.
// CODE calculates the facts (revised dates, the moved engineer visit, the new order ETA) and enforces the guardrails;
// the AI decides and explains. Every decision is stored in kci_decisions and shown in the order's activity.

const SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    action: { type: 'string', enum: ['SEND_UPDATE', 'NO_UPDATE'] },
    update_type: { type: 'string', enum: ['PROACTIVE', 'DELAY', 'NONE'] },
    reason: { type: 'string' },
    key_points: { type: 'array', items: { type: 'string' } },
  },
  required: ['action', 'update_type', 'reason', 'key_points'],
};

const INSTRUCTIONS = `
You are the KCI Decision Agent of NovaTel, a telecom operator. You watch one order task (with its plan, SLA,
customer impact and dependent tasks) and decide whether and how to update the customer. Your output is INTERNAL.

situation = AT_RISK: the task has used most of its SLA time but is not late yet.
  - SEND_UPDATE + PROACTIVE when telling the customer now helps them: no date has been given to them for this step
    yet, or the date they were given looks unlikely to hold, or they have been waiting a long time without news.
  - NO_UPDATE when the customer already has a date that still holds and was updated recently: a "running late"
    message would only worry them. Explain why.
situation = DELAYED: the task is late (SLA breached or reported delayed). Code has calculated the revised dates.
  - Always SEND_UPDATE + DELAY. key_points must cover: which step is late (in plain words), the new expected date,
    any other appointment that moved because of it (e.g. the engineer visit), the new date for the whole order if
    it changed, a short apology, and whether the customer needs to do anything.
  - If facts.customer_reason is given, it is the reason our staff chose to share with the customer: key_points must
    include it, in plain words. facts.internal_reason is PRIVATE and is never a key point.
Rules: use only facts from the input; never invent dates, causes or compensation; never mention internal reasons,
teams, staff or systems in key_points (they are passed to the writer of the customer message).
reason: one or two sentences for the agent's audit log. key_points: 2-5 short bullet points ([] for NO_UPDATE).
`.trim();

function ruleDecision({ situation, task, recent_updates, facts }) {
  if (situation === 'DELAYED') {
    return { action: 'SEND_UPDATE', update_type: 'DELAY', reason: 'The task is late: the customer must be told the revised date.',
      key_points: ['which step is late', ...(facts?.customer_reason ? [`why: ${facts.customer_reason}`] : []),
        'the new expected date', 'any appointment that moved', 'a short apology'] };
  }
  const recent = recent_updates.find((u) => u.hours_ago < 12);
  if (task.customer_date_given && recent) {
    return { action: 'NO_UPDATE', update_type: 'NONE', reason: `The customer already has a date for ${task.name.toLowerCase()} and was updated ${recent.hours_ago} h ago.`, key_points: [] };
  }
  return { action: 'SEND_UPDATE', update_type: 'PROACTIVE', reason: `${task.name} has used ${task.sla_pct_used}% of its SLA; a short reassurance avoids a chasing call.`,
    key_points: ['the step is taking a little longer than planned', 'we are on it', 'we will update them when it moves'] };
}

// facts: what code calculated; returns the decision (saved) with its id
export async function decide({ situation, trigger, order, task, facts = null }) {
  const started = Date.now();
  const recent_updates = (await query(
    `SELECT event, round(extract(epoch FROM now() - created_at) / 3600)::int AS hours_ago FROM kci_communications
      WHERE order_id = $1 AND status = 'Sent' ORDER BY id DESC LIMIT 3`, [order.id]
  )).rows;
  const input = {
    situation, trigger,
    order: { reference: order.order_number, plan: order.product_name, stage: order.current_stage, customer_needs: order.customer_needs },
    task: {
      name: task.name, state: task.state, milestone: task.milestone, customer_impact: task.customer_impact,
      planned_end: task.planned_end, original_planned_end: task.original_planned_end, sla_pct_used: task.sla_pct_used,
      customer_date_given: !!(task.details?.delivery_date || task.details?.slot),
    },
    facts, recent_updates,
  };

  let d = null; let ai = null;
  if (client) {
    try {
      const r = await askJson({ instructions: INSTRUCTIONS, input, name: 'kci_decision', schema: SCHEMA });
      d = r.data; ai = { model: MODEL, latency_ms: r.latency_ms, total_tokens: r.total_tokens };
    } catch (err) { console.error('OpenAI KCI decision failed, using rules:', err.message); }
  }
  d ||= ruleDecision({ situation, task: input.task, recent_updates, facts });

  // Guardrails (code wins): a delay is always told; internal work never is
  if (situation === 'DELAYED') { d.action = 'SEND_UPDATE'; d.update_type = 'DELAY'; }
  if (!task.customer_impact) { d.action = 'NO_UPDATE'; d.update_type = 'NONE'; d.reason = `Internal task (no customer impact). ${d.reason}`; }
  if (d.action === 'NO_UPDATE') d.key_points = [];

  const saved = (await query(
    `INSERT INTO kci_decisions (order_id, order_task_id, situation, trigger, action, update_type, reason, key_points, facts,
                                ai_source, model, latency_ms, total_tokens)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
    [order.id, task.id, situation, trigger, d.action, d.update_type === 'NONE' ? null : d.update_type, d.reason,
     JSON.stringify(d.key_points || []), facts ? JSON.stringify(facts) : null, ai ? 'openai' : 'rules',
     ai?.model ?? null, ai?.latency_ms ?? Date.now() - started, ai?.total_tokens ?? null]
  )).rows[0];
  return saved;
}

export async function linkKci(decisionId, kciId) {
  await query(`UPDATE kci_decisions SET kci_id = $2 WHERE id = $1`, [decisionId, kciId]);
}
