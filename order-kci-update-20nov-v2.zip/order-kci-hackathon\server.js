import express from 'express';
import 'dotenv/config';
import orderRoutes from './routes/orders.js';
import serviceRoutes from './routes/service.js';
import workspaceRoutes from './routes/workspace.js';
import { startSlaWatcher } from './services/slaService.js';
import { checkRules } from './services/settings.js';

// Business rules (config/business-rules.json): a wrong value stops the server here with a clear message
let rulesLine;
try { rulesLine = checkRules(); } catch (err) { console.error(err.message); process.exit(1); }

const app = express();
app.use(express.json({ limit: '10mb' })); // 10 MB so customers can send photos
app.use(express.static('public'));

// Fonts and charts served from our own server (no internet needed during the live demo)
app.use('/vendor/bricolage', express.static('node_modules/@fontsource-variable/bricolage-grotesque'));
app.use('/vendor/hind', express.static('node_modules/@fontsource/hind'));
app.use('/vendor/inter', express.static('node_modules/@fontsource-variable/inter'));
app.use('/vendor/mono', express.static('node_modules/@fontsource-variable/jetbrains-mono'));
app.use('/vendor/chartjs', express.static('node_modules/chart.js/dist'));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', ai: process.env.OPENAI_API_KEY ? 'openai' : 'demo-template', model: process.env.OPENAI_MODEL || 'gpt-5.6' });
});

app.use('/api', orderRoutes);
app.use('/api', serviceRoutes);
app.use('/api/ws', workspaceRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(rulesLine);
  startSlaWatcher();
});
