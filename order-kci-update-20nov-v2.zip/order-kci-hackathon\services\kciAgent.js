import { client, MODEL, askJson } from './openaiClient.js';

// The exact JSON shape the model must return (Structured Outputs)
const KCI_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    mode: { type: 'string', enum: ['PROGRESS', 'PROACTIVE', 'DELAY', 'RESOLVED', 'COMPLETED'] },
    subject: { type: 'string' },
    message: { type: 'string' },
    sms: { type: 'string' },
    next_update_by: { type: 'string' },
  },
  required: ['mode', 'subject', 'message', 'sms', 'next_update_by'],
};

const INSTRUCTIONS = `
You are the customer communications assistant of a telecom operator.
Write ONE "Keep Customer Informed" (KCI) update for the customer, using ONLY the JSON context you receive.

Rules:
- Write in English (British spelling).
- "message": start with "Dear <customer>," using exactly the first name given in "customer" (never add a surname),
  and keep it to 2-4 short sentences.
  Say clearly what has happened and what happens next.
- "sms": the same update in at most 160 characters, no greeting.
- Use only facts from the context. Never invent dates, prices, causes or promises.
- "customer_comments" are what the customer told us; acknowledge them where relevant.
- "internal_notes" are PRIVATE work notes. Use them only to understand the situation.
  NEVER quote them and NEVER mention staff, teams, escalations, shortages, systems,
  internal reasons or incident numbers. Share only customer-relevant facts such as
  new dates, time slots and next steps.
- If "previous_kci" is given, do not repeat it word for word; say what is new.
- "milestone" holds the exact facts of this order milestone (items, dates, time windows, courier, tracking
  reference, visit slot, measured speed, monthly total, first bill date, next_step). Use them exactly as given.
- What each event must say (mode PROGRESS unless stated):
  CPE_DELIVERY_SCHEDULED: which items are coming, the delivery date and time window, the courier and tracking
    reference, that someone aged 18+ must be in to sign (if "signature" is true), and how to change the date
    (the chat on their tracking page).
  CPE_DELIVERED: what was delivered and when; for broadband, keep the equipment boxed because the engineer will set it
    up; for a SIM, they can insert it now; then the next step ("next_step").
  ENGINEER_APPOINTMENT_SCHEDULED / VISIT_RESCHEDULED: the visit date and slot, what the engineer will do and how long
    it takes, how to prepare (personalise it from "customer_needs", e.g. access to the first floor for a mesh
    extender), and that they can change it in the chat on their tracking page.
  ENGINEER_VISIT_COMPLETED: the work done, the speed measured on the day ("speed_mbps"), and that the service will be
    activated next.
  SERVICE_ACTIVATED: the service is live ("service"), add-ons are active, one practical tip, and one personal line
    linked to "customer_needs" if relevant.
  ORDER_COMPLETED (mode COMPLETED, the final update): plan and add-ons, the monthly total, the first bill date, where
    to get help ("help"), and one short question asking how we did.
  JEOPARDY (mode PROACTIVE): "milestone.task" is taking longer than planned. Reassure the customer that we are on it,
    without inventing reasons or new dates.
  TASK_DELAYED (mode DELAY): "milestone.task" is late. Give the new expected date ("milestone.new_date", it was
    "milestone.old_date"), every other appointment that moved because of it ("milestone.moved": e.g. the engineer
    visit, with its new slot; say they can change it in the chat on their tracking page), and the new date for the
    whole order ("milestone.order_eta") if given. Apologise briefly. If "milestone.customer_reason" is given, it is
    the reason we chose to share: say it in plain words. Otherwise never give a cause: say only that the step is
    running late. Combine everything into ONE clear message.
  ENGINEER_FALLOUT (mode DELAY): our engineer visited but could not finish. Say why in plain words, using only
    "milestone.customer_reason"; that we are fixing it, expected by "milestone.fix_by"; the new engineer visit
    ("milestone.new_date"; the visit was "milestone.old_date"); the new date the service should be live
    ("milestone.order_eta"); that they can change the visit in the chat on their tracking page; and that they do
    not need to do anything else. Apologise briefly. ONE clear message.
  FALLOUT_CLEARED (mode RESOLVED): good news, the problem our engineer found is fixed. Confirm the engineer visit
    ("milestone.slot") and when the service should be live ("milestone.order_eta").
- If "must_cover" is given (from our KCI Decision Agent), the message must cover every point in it.
- "required_facts" lists values the customer needs (tracking reference, case reference): put every "value" in the
  message exactly as written.
  INCIDENT_RAISED (mode DELAY), INCIDENT_RESOLVED (mode RESOLVED), TASK_COMPLETED (incident fix progress).
- Case and service request events use "case" (reference, type, category, title, resolution). The reference
  (e.g. CS0001002 or SR0001001) is for the customer, so always include it:
  CASE_OPENED: we have received their request (say what it is about in plain words), the reference, and that our
    team will be in touch; for a Service Request, say we will confirm when it is done. Never promise a time.
  CASE_TASK_COMPLETED: "task_done" is a step our team has just finished; tell them, and that we are continuing.
  CASE_RESOLVED (mode RESOLVED): what we did ("resolution", in customer-friendly words), the reference, and that
    they can reply if anything is still not right.
- If event is TASK_COMPLETED (mode PROGRESS): "task_done" is one step of the fix that our team has just finished.
  Tell the customer this good news in plain words (rephrase it; never name teams or staff), and say the rest of the fix
  is continuing. If "open_steps" is 0, say the issue should be fully fixed very soon. Never promise a date that is not in the context.
- If "area_outage" is true, the issue affects the network in the customer's whole area, not just their order.
  Say so simply, so the customer knows it is not about them personally. Never mention other customers' details.
- If "visit_slot" is given, mention the booked visit/delivery slot when it is relevant.
- If "customer_needs" is given (what the customer told our Plan Advisor before buying, e.g. works from home),
  you may add ONE short, natural personal touch linked to it when relevant. Never list their needs back.
- If "addons" are given, you may mention them when relevant (e.g. at activation: "your Mesh Wi-Fi extender").
- next_update_by: a short phrase such as "within 24 hours", or "" if no further update is needed.
`.trim();

export async function draftKci(context) {
  const started = Date.now();

  if (client) {
    try {
      const r = await askJson({ instructions: INSTRUCTIONS, input: context, name: 'kci', schema: KCI_SCHEMA });
      return { ...r.data, ai_source: 'openai', model: MODEL, latency_ms: r.latency_ms, total_tokens: r.total_tokens };
    } catch (err) {
      console.error('OpenAI call failed, using template KCI:', err.message);
    }
  }

  const t = templateKci(context);
  // SMS: the template's own short text, or the message without the greeting; never over 160 characters
  let sms = t.sms || `NovaTel: ${t.message.replace(/^Dear [^,]+, /, '')}`;
  sms = sms.charAt(0).toUpperCase() + sms.slice(1);
  if (sms.length > 160) sms = sms.slice(0, 157).replace(/\s+\S*$/, '') + '...';
  return {
    ...t,
    sms,
    ai_source: 'demo-template',
    model: null,
    latency_ms: Date.now() - started,
    total_tokens: null,
  };
}

// Fallback KCI used when there is no API key or the API call fails
const lc1 = (s) => s.charAt(0).toLowerCase() + s.slice(1);   // "Replaced the router" -> "replaced the router"
const list = (items = []) => items.length <= 1 ? (items[0] || 'your equipment')
  : `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;

function templateKci(c) {
  const hi = `Dear ${c.customer},`;
  const m = c.milestone || {};
  switch (c.event) {
    case 'CPE_DELIVERY_SCHEDULED':
      return {
        mode: 'PROGRESS',
        subject: `Your ${list(m.items)} ${m.items?.length > 1 ? 'are' : 'is'} on the way`,
        message: `${hi} your ${list(m.items)} will be delivered on ${m.delivery_date}, ${m.delivery_window}, by ${m.courier} (tracking reference ${m.tracking_ref}).${m.signature ? ' Someone aged 18 or over will need to sign for it.' : ''} Need a different day? Just ask in the chat on your tracking page.`,
        sms: `NovaTel: your equipment arrives ${m.delivery_date}, 8AM-6PM. Tracking ${m.tracking_ref}.${m.signature ? ' Signature needed (18+).' : ''}`,
        next_update_by: 'when it is delivered',
      };
    case 'CPE_DELIVERED':
      return {
        mode: 'PROGRESS',
        subject: 'Your NovaTel equipment has arrived',
        message: `${hi} your ${list(m.items)} ${m.items?.length > 1 ? 'were' : 'was'} delivered on ${m.delivered_at}. ${m.next_step === 'Engineer visit' ? 'Please keep everything boxed: your engineer will set it up.' : 'You can set it up now.'} Next step: ${String(m.next_step).toLowerCase()}.`,
        sms: `NovaTel: your equipment was delivered ${m.delivered_at}. ${m.next_step === 'Engineer visit' ? 'Please keep it boxed for your engineer.' : 'You can set it up now.'}`,
        next_update_by: 'at the next step',
      };
    case 'ENGINEER_APPOINTMENT_SCHEDULED':
    case 'VISIT_RESCHEDULED':
      return {
        mode: 'PROGRESS',
        subject: `Your engineer visit is booked: ${m.slot}`,
        message: `${hi} your engineer visit is booked for ${m.slot}. It takes ${m.duration}: the engineer will ${m.work}. Need a different time? Just ask in the chat on your tracking page.`,
        sms: `NovaTel: engineer visit booked ${m.slot} (${m.duration}). Need another time? Use the chat on your tracking page.`,
        next_update_by: 'after the visit',
      };
    case 'ENGINEER_VISIT_COMPLETED':
      return {
        mode: 'PROGRESS',
        subject: 'Your engineer visit is complete',
        message: `${hi} your engineer has finished the installation. We measured ${m.speed_mbps} Mbps on the day. Next, we will activate your service.`,
        sms: `NovaTel: installation complete, ${m.speed_mbps} Mbps measured. We'll activate your service next.`,
        next_update_by: 'when your service is live',
      };
    case 'SERVICE_ACTIVATED':
      return {
        mode: 'PROGRESS',
        subject: `Your ${c.product} is live`,
        message: `${hi} your ${c.product} is now active: ${m.service}.${c.addons?.length ? ` Your ${list(c.addons)} ${c.addons.length > 1 ? 'are' : 'is'} active too.` : ''} Enjoy your new service.`,
        sms: `NovaTel: your ${c.product} is now live (${m.service}). Enjoy!`,
        next_update_by: 'with your order summary',
      };
    case 'INCIDENT_RAISED':
      return {
        mode: 'DELAY',
        subject: `Update on your ${c.product} order`,
        message: `${hi} there is a delay at the ${c.current_stage} stage of your order: ${c.incident}. Our team is working on it and no action is needed from you.`,
        next_update_by: 'within 24 hours',
      };
    case 'INCIDENT_RESOLVED':
      return {
        mode: 'RESOLVED',
        subject: 'The issue with your order is resolved',
        message: `${hi} the issue at the ${c.current_stage} stage has been resolved and your order is moving again.`,
        next_update_by: 'at the next stage',
      };
    case 'ENGINEER_FALLOUT': {
      const live = m.order_eta ? ` Your service should now be live by ${m.order_eta}.` : '';
      return {
        mode: 'DELAY',
        subject: `New engineer visit: ${m.new_date}`,
        message: `${hi} we are sorry: our engineer could not finish connecting you today because ${m.customer_reason}. We expect this to be fixed by ${m.fix_by}, and we have booked your engineer to come back on ${m.new_date}.${live} If that time does not suit you, change it in the chat on your tracking page. You do not need to do anything else.`,
        sms: `NovaTel: sorry, your connection needs a fix first. Engineer rebooked for ${m.new_date}.${m.order_eta ? ` Live by ${m.order_eta}.` : ''}`,
        next_update_by: 'when the fix is done',
      };
    }
    case 'FALLOUT_CLEARED':
      return {
        mode: 'RESOLVED',
        subject: `Your engineer visit is confirmed: ${m.slot}`,
        message: `${hi} good news: the problem our engineer found has been fixed. Your engineer visit is confirmed for ${m.slot}${m.order_eta ? `, and your service should be live by ${m.order_eta}` : ''}. If that time does not suit you, change it in the chat on your tracking page.`,
        sms: `NovaTel: good news, the fix is done. Engineer confirmed for ${m.slot}.`,
        next_update_by: 'after the engineer visit',
      };
    case 'TASK_COMPLETED':
      return {
        mode: 'PROGRESS',
        subject: 'Progress on fixing your order',
        message: `${hi} good news: one more step to fix the issue with your order is complete. ${c.open_steps ? 'Our team is finishing the remaining work' : 'The issue should be fully fixed very soon'}, and we will keep you updated.`,
        next_update_by: 'within 24 hours',
      };
    case 'TASK_DELAYED': {
      const visit = (m.moved || []).find((x) => x.rebooked);
      const others = (m.moved || []).filter((x) => !x.rebooked);
      return {
        mode: 'DELAY',
        subject: `New date for your ${String(m.task).toLowerCase()}: ${m.new_date}`,
        message: `${hi} we are sorry: your ${String(m.task).toLowerCase()} is running late${m.customer_reason ? ` because ${m.customer_reason}` : ''}. The new expected date is ${m.new_date} (it was ${m.old_date}).`
          + (visit ? ` Because of this, we have moved your engineer visit to ${visit.to}. If that time does not suit you, change it in the chat on your tracking page.` : '')
          + (m.order_eta ? ` Your service should now be ready by ${m.order_eta}.`
            : others.length ? ` ${others.map((x) => `${x.task} is now planned for ${x.to}`).join('; ')}.` : '')
          + ' We will keep you updated.',
        sms: `NovaTel: sorry, your ${String(m.task).toLowerCase()} is delayed to ${m.new_date}.`
          + (visit ? ` Engineer moved to ${visit.to}; change it in the chat on your tracking page.` : m.order_eta ? ` Service ready by ${m.order_eta}.` : ' We will keep you updated.'),
        next_update_by: 'when it moves',
      };
    }
    case 'CASE_OPENED': {
      const k = c.case || {};
      const sr = k.type === 'Service Request';
      return {
        mode: 'PROGRESS',
        subject: `We've received your ${sr ? 'request' : 'query'} (${k.reference})`,
        message: sr
          ? `${hi} thank you for your request (${lc1(String(k.category || 'service request'))}). Your reference is ${k.reference}. Our team will take care of it and confirm when it is done.`
          : `${hi} thank you for getting in touch. We have opened a case for you (${lc1(String(k.category || 'enquiry'))}) with reference ${k.reference}. Our team is looking into it and will be in touch.`,
        sms: `NovaTel: we've received your ${sr ? 'request' : 'query'}, ref ${k.reference}. ${sr ? "We'll confirm when it's done." : "We'll be in touch."}`,
        next_update_by: 'when we have an update',
      };
    }
    case 'CASE_TASK_COMPLETED': {
      const k = c.case || {};
      return {
        mode: 'PROGRESS',
        subject: `Progress on ${k.reference}`,
        message: `${hi} good news on ${k.reference}: ${String(c.task_done || 'one more step is complete').replace(/[.!?]+$/, '')}. We are continuing and will update you.`,
        sms: `NovaTel: progress on ${k.reference}: ${String(c.task_done || 'a step is complete').replace(/[.!?]+$/, '')}.`,
        next_update_by: 'at the next step',
      };
    }
    case 'CASE_RESOLVED': {
      const k = c.case || {};
      return {
        mode: 'RESOLVED',
        subject: `${k.reference} is resolved`,
        message: `${hi} we have resolved ${k.reference}: ${lc1(String(k.resolution || 'your request is complete').replace(/[.!?]+$/, ''))}. If anything is still not right, just reply and we will pick it up.`,
        sms: `NovaTel: ${k.reference} is resolved. Anything not right? Just reply.`,
        next_update_by: '',
      };
    }
    case 'JEOPARDY':
      return {
        mode: 'PROACTIVE',
        subject: `Your ${c.product} order is still in progress`,
        message: `${hi} the ${String(m.task || c.current_stage).toLowerCase()} step of your order is taking a little longer than planned${m.delivery_date || m.slot ? `, but we are still working to the date we gave you (${m.delivery_date || m.slot})` : ''}. We are on it and will update you as soon as it moves.`,
        sms: `NovaTel: your ${String(m.task || 'order').toLowerCase()} is taking a little longer than planned. We're on it and will update you soon.`,
        next_update_by: 'within 24 hours',
      };
    case 'ORDER_COMPLETED':
      return {
        mode: 'COMPLETED',
        subject: `Your ${c.product} order is complete`,
        message: `${hi} your order ${c.order_number} is complete: ${c.product}${c.addons?.length ? ` with ${list(c.addons)}` : ''} for ${m.monthly_total} a month. Your first bill will be on ${m.first_bill_date}. If you need help, use ${m.help}. How did we do? Reply with a score from 1 to 5.`,
        sms: `NovaTel: order ${c.order_number} complete. ${m.monthly_total}/month, first bill ${m.first_bill_date}. How did we do? Reply 1-5.`,
        next_update_by: '',
      };
    default:
      return {
        mode: 'PROGRESS',
        subject: `An update on your ${c.product} order`,
        message: `${hi} your ${c.product} order is progressing at the ${c.current_stage} stage. We will keep you updated.`,
        next_update_by: 'at the next step',
      };
  }
}
