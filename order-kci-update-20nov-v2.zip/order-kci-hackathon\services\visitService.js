import { query } from '../db/index.js';
import { atHour, nextWorkingDay } from './format.js';
import { isWorkingDay, atTime, slotWindows, slotDaysAhead } from './calendar.js';

// Engineer visit slots: the windows of the working calendar on every working day (config/business-rules.json),
// labelled like "Fri 20 Nov, 10 AM-12 PM".
const label = (d) => d.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' });

// Every slot in the booking horizon, with its start and end
function allSlots(days = slotDaysAhead()) {
  const out = [];
  const windows = slotWindows();
  for (let i = 1; i <= days; i++) {
    const d = new Date(Date.now() + i * 86400000);
    if (!isWorkingDay(d)) continue;
    for (const w of windows) {
      const at = atTime(d, w.start);
      out.push({ label: `${label(d)}, ${w.label}`, at, end: new Date(at.getTime() + w.minutes * 60000) });
    }
  }
  return out;
}

// The first `count` slots on or after a date
export function slotsFrom(fromDate, count = 6) {
  const from = atHour(fromDate || new Date(), 0);
  return allSlots().filter((s) => s.at >= from).slice(0, count).map((s) => s.label);
}
// The date and time of a slot label (null if it is not a real slot)
export const slotDate = (slotLabel) => allSlots().find((s) => s.label === slotLabel)?.at || null;
// When a slot ends (its window length, e.g. 2 hours)
export const slotEnd = (slotLabel) => allSlots().find((s) => s.label === slotLabel)?.end || null;

// Slots from tomorrow (used when no order is known)
export const availableSlots = () => slotsFrom(new Date(Date.now() + 86400000));

// The earliest day an engineer can come for this order: the working day after the equipment arrives
// (the engineer visit DEPENDS ON the equipment delivery task)
export async function earliestVisitDate(orderId) {
  const t = (await query(
    `SELECT d.planned_end AS dep_end, d.closed_at AS dep_closed
       FROM order_tasks e LEFT JOIN order_tasks d ON d.id = e.depends_on
      WHERE e.order_id = $1 AND e.task_type = 'ENGINEER_VISIT'`, [orderId]
  )).rows[0];
  const tomorrow = atHour(new Date(Date.now() + 86400000), 0);
  if (!t) return tomorrow;
  const ready = t.dep_closed ? new Date() : t.dep_end ? new Date(t.dep_end) : new Date();
  const d = atHour(nextWorkingDay(ready), 0);
  return d > tomorrow ? d : tomorrow;
}
export async function availableSlotsForOrder(orderId, count = 6) {
  return slotsFrom(await earliestVisitDate(orderId), count);
}

// The customer books or moves the engineer visit -> same milestone as an agent booking (AI update to the customer)
export async function rescheduleVisit(orderId, slot) {
  const { bookEngineer } = await import('./orderService.js');
  try {
    const r = await bookEngineer(orderId, slot, { by: 'customer via Order Assistant' });
    return { ok: true, slot: r.task.details.slot };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}
